package com.nero.speedforce.entity;

import com.nero.speedforce.SpeedForceMod;
import com.nero.speedforce.data.SpeedData;
import com.nero.speedforce.data.SpeedMath;
import com.nero.speedforce.network.FxPayload;
import com.nero.speedforce.registry.ModAttachments;
import com.nero.speedforce.registry.ModEntities;
import com.nero.speedforce.server.ServerFx;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import java.util.UUID;

/**
 * Rival speedsters (Reverse-Flash, Zoom, Godspeed) and speed clones.
 * Hand-written combat AI: orbits the target at speed, dashes through walls, throws lightning,
 * dodges hits, and uses a signature power per variant.
 */
public class SpeedsterEntity extends Monster {
    public enum Variant {
        REVERSE_FLASH(0xFF2424, BossEvent.BossBarColor.RED, true, 1.15, 2.4),
        ZOOM(0x2F8BFF, BossEvent.BossBarColor.BLUE, true, 1.35, 2.8),
        GODSPEED(0xF4F4F4, BossEvent.BossBarColor.WHITE, true, 1.5, 3.0),
        SAVITAR(0x9FE8FF, BossEvent.BossBarColor.GREEN, true, 0.9, 2.2),
        BLACK_FLASH(0x7A1FD0, BossEvent.BossBarColor.PURPLE, true, 1.7, 3.3),
        CLONE(0xF4F4F4, BossEvent.BossBarColor.WHITE, false, 1.0, 2.0);

        public final int color;
        public final BossEvent.BossBarColor bar;
        public final boolean boss;
        public final double orbitSpeed;
        public final double dashSpeed;

        Variant(int color, BossEvent.BossBarColor bar, boolean boss, double orbitSpeed, double dashSpeed) {
            this.color = color;
            this.bar = bar;
            this.boss = boss;
            this.orbitSpeed = orbitSpeed;
            this.dashSpeed = dashSpeed;
        }
    }

    private enum Phase { CIRCLE, DASH, THROW, SPECIAL, RECOVER, FLANK }

    private static final EntityDataAccessor<Boolean> DATA_ALLY = SynchedEntityData.defineId(SpeedsterEntity.class, EntityDataSerializers.BOOLEAN);

    public final Variant variant;
    @Nullable private final ServerBossEvent bossEvent;
    private Phase phase = Phase.CIRCLE;
    private int phaseTicks;
    private int phaseLength = 50;
    private int throwsLeft;
    private int dodgeCooldown;
    private double orbitAngle;
    private double orbitDir = 1.0;
    private int stage;
    private int dashChain;
    private boolean chained;
    private Phase lastPhase = Phase.CIRCLE;
    private int blindTicks;
    private Vec3 lastTargetPos = Vec3.ZERO;
    private boolean hasLastTargetPos;
    private Vec3 targetVel = Vec3.ZERO;
    @Nullable private Vec3 flankDest;
    private int life = -1;
    @Nullable private UUID owner;

    public SpeedsterEntity(EntityType<? extends SpeedsterEntity> type, Level level, Variant variant) {
        super(type, level);
        this.variant = variant;
        this.bossEvent = variant.boss ? new ServerBossEvent(type.getDescription(), variant.bar, BossEvent.BossBarOverlay.NOTCHED_10) : null;
        this.xpReward = variant.boss ? 150 : 0;
        if (variant.boss) setPersistenceRequired();
    }

    public static AttributeSupplier.Builder attributes(double health, double damage) {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, health)
                .add(Attributes.ATTACK_DAMAGE, damage)
                .add(Attributes.MOVEMENT_SPEED, 0.35)
                .add(Attributes.FOLLOW_RANGE, 48.0)
                .add(Attributes.ARMOR, 8.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6)
                .add(Attributes.STEP_HEIGHT, 1.5);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_ALLY, false);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(9, new LookAtPlayerGoal(this, Player.class, 24f));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false, e -> !isAlly()));
        targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, Monster.class, 10, false, false,
                e -> isAlly() && !(e instanceof SpeedsterEntity s && s.isAlly())));
    }

    // ------------------------------------------------------------------ ally / clone helpers

    public boolean isAlly() {
        return entityData.get(DATA_ALLY);
    }

    public void makeAllyOf(Player player, int lifetime) {
        entityData.set(DATA_ALLY, true);
        owner = player.getUUID();
        life = lifetime;
    }

    public void setLife(int ticks) {
        life = ticks;
    }

    @Override
    public void setTarget(@Nullable LivingEntity target) {
        if (target != null && owner != null && target.getUUID().equals(owner)) return;
        if (target instanceof SpeedsterEntity other && other.isAlly() == isAlly()) return;
        super.setTarget(target);
    }

    @Override
    public boolean isAlliedTo(Entity other) {
        if (isAlly()) {
            if (owner != null && other.getUUID().equals(owner)) return true;
            if (other instanceof SpeedsterEntity s && s.isAlly()) return true;
        } else if (other instanceof SpeedsterEntity s && !s.isAlly()) {
            return true;
        }
        return super.isAlliedTo(other);
    }

    // ------------------------------------------------------------------ AI

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (bossEvent != null) bossEvent.setProgress(getHealth() / getMaxHealth());
        if (life > 0 && --life == 0) {
            poof();
            discard();
            return;
        }
        if (dodgeCooldown > 0) dodgeCooldown--;
        if (variant.boss) updateStage();

        LivingEntity target = getTarget();
        if (target == null || !target.isAlive() || target.level() != level()) {
            if (noPhysics) endPhase();
            hasLastTargetPos = false;
            targetVel = Vec3.ZERO;
            return;
        }

        // Players move client-side, so their deltaMovement lies; measure real velocity from positions instead.
        Vec3 now = target.position();
        if (hasLastTargetPos) {
            Vec3 raw = now.subtract(lastTargetPos);
            if (raw.length() > 4.0) raw = raw.normalize().scale(4.0);
            targetVel = targetVel.scale(0.5).add(raw.scale(0.5));
        }
        lastTargetPos = now;
        hasLastTargetPos = true;

        getLookControl().setLookAt(target, 60f, 60f);
        if (variant.boss && phase != Phase.DASH && phase != Phase.FLANK && dodgeCooldown <= 0 && tickCount % 2 == 0) {
            avoidProjectiles();
        }
        blindTicks = hasLineOfSight(target) ? 0 : blindTicks + 1;

        phaseTicks++;
        switch (phase) {
            case CIRCLE -> circle(target);
            case DASH -> dash(target);
            case THROW -> throwLightning(target);
            case SPECIAL -> special(target);
            case FLANK -> flank(target);
            case RECOVER -> {
                Vec3 v = getDeltaMovement();
                setDeltaMovement(v.x * 0.5, v.y, v.z * 0.5);
                if (phaseTicks > Math.max(5, 13 - 3 * stage)) setPhase(Phase.CIRCLE);
            }
        }
    }

    // ---- stages: bosses get faster, harder and meaner as they lose health

    private void updateStage() {
        int s = getHealth() < getMaxHealth() * 0.25f ? 2 : getHealth() < getMaxHealth() * 0.55f ? 1 : 0;
        if (s > stage) {
            stage = s;
            onStageUp();
        }
    }

    private void onStageUp() {
        AttributeInstance dmg = getAttribute(Attributes.ATTACK_DAMAGE);
        if (dmg != null) {
            dmg.addOrReplacePermanentModifier(new AttributeModifier(SpeedForceMod.rl("stage_rage"), 0.25 * stage, AttributeModifier.Operation.ADD_MULTIPLIED_BASE));
        }
        if (!(level() instanceof ServerLevel sl)) return;
        ServerFx.ring(sl, position().add(0, 0.3, 0), 10, variant.color, 80);
        ServerFx.burst(sl, position().add(0, 1, 0), variant.color, 40);
        sl.playSound(null, getX(), getY(), getZ(), SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 1.2f, 1.8f);
        ServerFx.shakeNearby(sl, position(), 24, 4f);
        for (ServerPlayer sp : sl.getEntitiesOfClass(ServerPlayer.class, getBoundingBox().inflate(40))) {
            sp.displayClientMessage(Component.translatable(stage == 1 ? "message.speedforce.boss_enraged" : "message.speedforce.boss_final",
                    getDisplayName()).withStyle(ChatFormatting.RED), true);
        }
        if (variant == Variant.GODSPEED) summonClones(sl, getTarget(), stage == 1 ? 2 : 4);
        setPhase(Phase.RECOVER);
    }

    private double stageSpeed() {
        return 1.0 + 0.18 * stage;
    }

    // ---- phase selection: weighted by distance, how fast the target moves, line of sight, and what we just did

    private void setPhase(Phase next) {
        if (phase != Phase.CIRCLE && phase != Phase.RECOVER) lastPhase = phase;
        phase = next;
        phaseTicks = 0;
        if (next == Phase.CIRCLE) {
            LivingEntity t = getTarget();
            if (t != null) orbitAngle = Math.atan2(getZ() - t.getZ(), getX() - t.getX());
            phaseLength = Math.max(18, 38 + random.nextInt(36) - 8 * stage);
            if (random.nextBoolean()) orbitDir = -orbitDir;
        }
        if (next == Phase.THROW) throwsLeft = variant == Variant.CLONE ? 1 : 1 + random.nextInt(2 + stage);
    }

    private void chooseNext(LivingEntity target) {
        if (variant == Variant.CLONE) {
            chained = false;
            setPhase(random.nextFloat() < 0.8f ? Phase.DASH : Phase.THROW);
            return;
        }
        double dist = distanceTo(target);
        double tSpeed = targetVel.horizontalDistance();
        double wDash = 3, wThrow = 3, wSpecial = 1.5 + stage, wFlank = 1.5 + stage * 0.8;
        if (dist > 12) { wDash += 4; wFlank += 2; wThrow += 1; }
        if (dist < 5) { wSpecial += 3; wThrow -= 1.5; }
        if (tSpeed > 0.9) { wThrow *= 0.4; wSpecial += 2; wFlank += 2; } // fast targets dodge bolts: use area attacks and flanks
        else if (tSpeed < 0.1) wThrow += 3;                              // sitting duck: snipe
        if (blindTicks > 15) { wDash += 6; wFlank += 3; wThrow = 0; }    // no line of sight: phase through the wall
        if (target.getHealth() < target.getMaxHealth() * 0.3f) wDash += 3;
        switch (lastPhase) {
            case DASH -> wDash *= 0.4;
            case THROW -> wThrow *= 0.4;
            case SPECIAL -> wSpecial *= 0.2;
            case FLANK -> wFlank *= 0.4;
            default -> { }
        }
        wThrow = Math.max(0, wThrow);
        double r = random.nextDouble() * (wDash + wThrow + wSpecial + wFlank);
        Phase next;
        if (r < wDash) next = Phase.DASH;
        else if ((r -= wDash) < wThrow) next = Phase.THROW;
        else if ((r -= wThrow) < wSpecial) next = Phase.SPECIAL;
        else next = Phase.FLANK;
        chained = false;
        if (next == Phase.DASH) dashChain = stage + random.nextInt(2);
        setPhase(next);
    }

    private void circle(LivingEntity target) {
        double radius = variant == Variant.CLONE ? 3.5 : (stage >= 2 ? 4.5 : 6.0);
        double speed = variant.orbitSpeed * stageSpeed();
        if (phaseTicks % 20 == 0 && random.nextFloat() < 0.35f) orbitDir = -orbitDir; // strafe reversals make us hard to read
        orbitAngle += orbitDir * speed / radius;
        Vec3 goal = target.position().add(Math.cos(orbitAngle) * radius, 0, Math.sin(orbitAngle) * radius);
        Vec3 to = goal.subtract(position());
        Vec3 flat = new Vec3(to.x, 0, to.z);
        double len = flat.length();
        Vec3 vel = len > speed * 1.8 ? flat.scale(speed * 1.8 / len) : flat;
        double dy = getDeltaMovement().y;
        if (horizontalCollision && onGround()) dy = 0.55;
        setDeltaMovement(vel.x, dy, vel.z);

        if (phaseTicks > phaseLength) chooseNext(target);
    }

    private void dash(LivingEntity target) {
        int windup = chained ? 0 : Math.max(2, 6 - 2 * stage);
        if (phaseTicks <= windup) {
            // telegraph: crouch and flare so a sharp player can react
            setDeltaMovement(getDeltaMovement().multiply(0.1, 1, 0.1));
            if (level() instanceof ServerLevel sl) {
                sl.sendParticles(ServerFx.dust(variant.color, 1.3f), getX(), getY() + 1, getZ(), 6, 0.4, 0.8, 0.4, 0);
            }
            return;
        }
        if (phaseTicks == windup + 1) {
            noPhysics = true;
            level().playSound(null, getX(), getY(), getZ(), SoundEvents.ILLUSIONER_MIRROR_MOVE, SoundSource.HOSTILE, 1.0f, 1.6f);
        }
        double speed = variant.dashSpeed * stageSpeed();
        Vec3 center = target.position().add(0, target.getBbHeight() * 0.4, 0);
        double t = Math.min(6.0, center.distanceTo(position()) / speed);
        Vec3 lead = new Vec3(targetVel.x, 0, targetVel.z).scale(t * 0.6); // aim where they are going, not where they were
        Vec3 to = center.add(lead).subtract(position());
        setDeltaMovement(to.normalize().scale(speed));
        if (distanceTo(target) < 1.9) {
            strike(target);
            endPhase();
            if (dashChain > 0) {
                dashChain--;
                chained = true;
                setPhase(Phase.DASH);
            } else {
                setPhase(Phase.RECOVER);
            }
        } else if (phaseTicks > windup + 24) {
            endPhase();
            dashChain = 0;
            setPhase(Phase.CIRCLE);
        }
    }

    private void flank(LivingEntity target) {
        setDeltaMovement(getDeltaMovement().multiply(0.2, 1, 0.2));
        if (phaseTicks == 1) {
            Vec3 look = target.getLookAngle().multiply(1, 0, 1);
            look = look.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : look.normalize();
            Vec3 d = target.position().add(look.scale(-2.4)).add(targetVel.x * 4, 0, targetVel.z * 4);
            flankDest = new Vec3(d.x, target.getY(), d.z);
        }
        if (flankDest == null) {
            setPhase(Phase.CIRCLE);
            return;
        }
        if (phaseTicks < 8 && level() instanceof ServerLevel sl) {
            sl.sendParticles(ServerFx.dust(variant.color, 1.2f), flankDest.x, flankDest.y + 1, flankDest.z, 6, 0.3, 0.7, 0.3, 0);
        }
        if (phaseTicks == 8) {
            Vec3 shift = flankDest.subtract(position());
            if (level().noCollision(this, getBoundingBox().move(shift))) {
                if (level() instanceof ServerLevel sl) ServerFx.burst(sl, position().add(0, 1, 0), variant.color, 12);
                teleportTo(flankDest.x, flankDest.y, flankDest.z);
                level().playSound(null, getX(), getY(), getZ(), SoundEvents.ILLUSIONER_MIRROR_MOVE, SoundSource.HOSTILE, 1.0f, 2.0f);
            } else {
                setPhase(Phase.RECOVER);
                return;
            }
        }
        if (phaseTicks == 13 && distanceTo(target) < 3.2) strike(target);
        if (phaseTicks > 16) setPhase(Phase.RECOVER);
    }

    private void strike(LivingEntity target) {
        float dmg = (float) getAttributeValue(Attributes.ATTACK_DAMAGE);
        if (target.hurt(damageSources().mobAttack(this), dmg)) {
            Vec3 dir = target.position().subtract(position()).multiply(1, 0, 1).normalize();
            target.knockback(1.6, -dir.x, -dir.z);
            target.hurtMarked = true;
            if (level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.FLASH, target.getX(), target.getY() + 1, target.getZ(), 1, 0, 0, 0, 0);
                ServerFx.burst(sl, target.position().add(0, 1, 0), variant.color, 18);
            }
            level().playSound(null, getX(), getY(), getZ(), SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.HOSTILE, 1.2f, 0.7f);
            if (target instanceof ServerPlayer sp) {
                PacketDistributor.sendToPlayer(sp, new FxPayload(FxPayload.SHAKE, sp.getId(), 3f));
                if (variant == Variant.REVERSE_FLASH) drainSpeedster(sp, 15f);
                if (variant == Variant.BLACK_FLASH) drainSpeedster(sp, 10f);
            }
        }
    }

    private void endPhase() {
        noPhysics = false;
        int tries = 0;
        while (!level().noCollision(this) && tries++ < 8) setPos(getX(), getY() + 1, getZ());
    }

    private void throwLightning(LivingEntity target) {
        Vec3 v = getDeltaMovement();
        setDeltaMovement(v.x * 0.3, v.y, v.z * 0.3);
        if (level() instanceof ServerLevel sl && phaseTicks % 4 == 0) {
            sl.sendParticles(ServerFx.dust(variant.color, 0.8f), getX(), getY() + 1.4, getZ(), 4, 0.3, 0.3, 0.3, 0);
        }
        int interval = Math.max(7, 12 - 2 * stage);
        if (phaseTicks % interval == interval - 4) {
            Vec3 eye = getEyePosition();
            Vec3 center = target.position().add(0, target.getBbHeight() * 0.5, 0);
            double t = Math.min(12.0, center.distanceTo(eye) / 2.6);
            Vec3 lead = new Vec3(targetVel.x, 0, targetVel.z).scale(t);
            if (lead.length() > 8.0) lead = lead.normalize().scale(8.0);
            Vec3 aim = center.add(lead).subtract(eye);
            fireBolt(aim);
            if (stage >= 2 && variant != Variant.CLONE) {
                fireBolt(aim.yRot(0.21f));
                fireBolt(aim.yRot(-0.21f));
            }
            level().playSound(null, getX(), getY(), getZ(), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.HOSTILE, 0.8f, 1.8f);
            if (--throwsLeft <= 0) setPhase(Phase.CIRCLE);
        }
    }

    private void fireBolt(Vec3 aim) {
        LightningThrowEntity bolt = new LightningThrowEntity(level(), this, variant.color, variant == Variant.CLONE ? 3f : 7f, 2f);
        bolt.shoot(aim.x, aim.y, aim.z, 2.6f, 0.6f);
        level().addFreshEntity(bolt);
    }

    private void summonClones(ServerLevel sl, @Nullable LivingEntity target, int count) {
        for (int i = 0; i < count; i++) {
            SpeedsterEntity clone = ModEntities.SPEED_CLONE.get().create(sl);
            if (clone == null) continue;
            Vec3 c = target != null ? target.position() : position();
            double a = i * (Math.PI * 2 / count);
            clone.moveTo(c.x + Math.cos(a) * 4, c.y, c.z + Math.sin(a) * 4, getYRot(), 0);
            clone.setLife(300);
            if (target != null) clone.setTarget(target);
            sl.addFreshEntity(clone);
            ServerFx.burst(sl, clone.position().add(0, 1, 0), variant.color, 16);
        }
    }

    private void special(LivingEntity target) {
        boolean leap = variant == Variant.SAVITAR;
        if (leap) {
            if (phaseTicks == 1) setDeltaMovement(0, 0.95, 0);
            else if (phaseTicks == 11) setDeltaMovement(0, -1.6, 0);
            else setDeltaMovement(0, getDeltaMovement().y, 0);
        } else {
            setDeltaMovement(0, getDeltaMovement().y, 0);
        }
        int fire = leap ? 15 : 10;
        if (phaseTicks != fire || !(level() instanceof ServerLevel sl)) {
            if (phaseTicks > fire + 10) setPhase(Phase.RECOVER);
            return;
        }
        switch (variant) {
            case REVERSE_FLASH -> {
                target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 3));
                target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 80, 0));
                if (target instanceof ServerPlayer sp) drainSpeedster(sp, 35f);
                heal(10f);
                ServerFx.arc(sl, target.position().add(0, 1, 0), position().add(0, 1, 0), variant.color);
                ServerFx.arc(sl, target.position().add(0, 1.3, 0), position().add(0, 1.2, 0), variant.color);
                sl.playSound(null, getX(), getY(), getZ(), SoundEvents.WARDEN_HEARTBEAT, SoundSource.HOSTILE, 2f, 1.5f);
            }
            case ZOOM -> {
                for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(8), e -> e != this && !e.isAlliedTo(this))) {
                    e.hurt(damageSources().mobAttack(this), 8f);
                    Vec3 dir = e.position().subtract(position()).multiply(1, 0, 1).normalize();
                    e.knockback(2.0, -dir.x, -dir.z);
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 4));
                    e.hurtMarked = true;
                }
                ServerFx.ring(sl, position().add(0, 0.3, 0), 8, variant.color, 60);
                sl.sendParticles(ParticleTypes.SONIC_BOOM, getX(), getY() + 1, getZ(), 1, 0, 0, 0, 0);
                sl.playSound(null, getX(), getY(), getZ(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.HOSTILE, 2f, 0.8f);
                ServerFx.shakeNearby(sl, position(), 16, 5f);
            }
            case GODSPEED -> {
                summonClones(sl, target, 3);
                sl.playSound(null, getX(), getY(), getZ(), SoundEvents.ILLUSIONER_PREPARE_MIRROR, SoundSource.HOSTILE, 2f, 1.2f);
            }
            case SAVITAR -> {
                for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(7, 2, 7), e -> e != this && !e.isAlliedTo(this))) {
                    e.hurt(damageSources().mobAttack(this), 11f);
                    Vec3 dir = e.position().subtract(position()).multiply(1, 0, 1).normalize();
                    e.knockback(1.4, -dir.x, -dir.z);
                    e.push(0, 1.0, 0);
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1));
                    e.hurtMarked = true;
                }
                ServerFx.ring(sl, position().add(0, 0.3, 0), 7, variant.color, 70);
                sl.sendParticles(ParticleTypes.SONIC_BOOM, getX(), getY() + 1, getZ(), 1, 0, 0, 0, 0);
                sl.playSound(null, getX(), getY(), getZ(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.HOSTILE, 2f, 0.6f);
                ServerFx.shakeNearby(sl, position(), 20, 6f);
                if (stage >= 1 && random.nextFloat() < 0.6f) {
                    for (int i = 0; i < 2; i++) {
                        TimeWraithEntity wraith = ModEntities.TIME_WRAITH.get().create(sl);
                        if (wraith == null) continue;
                        wraith.moveTo(getX() + (i == 0 ? 3 : -3), getY(), getZ(), getYRot(), 0);
                        wraith.setTarget(target);
                        sl.addFreshEntity(wraith);
                        ServerFx.burst(sl, wraith.position().add(0, 1, 0), 0x5AD1FF, 14);
                    }
                }
            }
            case BLACK_FLASH -> {
                Vec3 look = target.getLookAngle().multiply(1, 0, 1);
                look = look.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : look.normalize();
                Vec3 behind = target.position().add(look.scale(-1.6));
                Vec3 shift = behind.subtract(position());
                if (level().noCollision(this, getBoundingBox().move(shift))) {
                    ServerFx.burst(sl, position().add(0, 1, 0), variant.color, 14);
                    teleportTo(behind.x, target.getY(), behind.z);
                }
                target.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 0));
                target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 2));
                if (target instanceof ServerPlayer sp) drainSpeedster(sp, 50f);
                heal(15f);
                ServerFx.arc(sl, target.position().add(0, 1, 0), position().add(0, 1, 0), variant.color);
                sl.playSound(null, getX(), getY(), getZ(), SoundEvents.WARDEN_HEARTBEAT, SoundSource.HOSTILE, 2f, 0.6f);
            }
            case CLONE -> { }
        }
    }

    // ---- reactive defence

    private void avoidProjectiles() {
        for (Projectile proj : level().getEntitiesOfClass(Projectile.class, getBoundingBox().inflate(6.0),
                pr -> pr.getOwner() != null && pr.getOwner() != this)) {
            Vec3 v = proj.getDeltaMovement();
            if (v.lengthSqr() < 0.04) continue;
            Vec3 toMe = position().add(0, 1, 0).subtract(proj.position());
            if (toMe.lengthSqr() < 1.0E-4) continue;
            if (toMe.normalize().dot(v.normalize()) > 0.85 && random.nextFloat() < 0.6f && sidestep(v)) return;
        }
    }

    /** Teleport sideways, perpendicular to an incoming direction. */
    private boolean sidestep(Vec3 incoming) {
        Vec3 flat = new Vec3(incoming.x, 0, incoming.z);
        if (flat.lengthSqr() < 1.0E-4) return false;
        flat = flat.normalize();
        double sign = random.nextBoolean() ? 3.2 : -3.2;
        for (int i = 0; i < 2; i++) {
            Vec3 side = new Vec3(-flat.z, 0, flat.x).scale(sign);
            if (level().noCollision(this, getBoundingBox().move(side))) {
                if (level() instanceof ServerLevel sl) {
                    sl.sendParticles(ServerFx.dust(variant.color, 1.0f), getX(), getY() + 1, getZ(), 16, 0.3, 0.8, 0.3, 0);
                }
                teleportTo(getX() + side.x, getY(), getZ() + side.z);
                level().playSound(null, getX(), getY(), getZ(), SoundEvents.ILLUSIONER_MIRROR_MOVE, SoundSource.HOSTILE, 1.0f, 1.9f);
                dodgeCooldown = Math.max(12, 28 - 6 * stage);
                return true;
            }
            sign = -sign;
        }
        return false;
    }

    private static void drainSpeedster(ServerPlayer sp, float amount) {
        SpeedData d = sp.getData(ModAttachments.SPEED);
        if (!d.isPowered()) return;
        d.energy = Math.max(0f, d.energy - amount);
        d.markDirty();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!level().isClientSide && variant == Variant.SAVITAR && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            amount *= 0.65f; // time-forged armour
        }
        float dodgeChance = 0.3f + 0.1f * stage + (variant == Variant.BLACK_FLASH ? 0.15f : 0f);
        if (!level().isClientSide && variant.boss && variant != Variant.SAVITAR && dodgeCooldown <= 0
                && phase != Phase.RECOVER && phase != Phase.DASH
                && source.getEntity() instanceof LivingEntity attacker && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)
                && random.nextFloat() < dodgeChance && dodge(attacker)) {
            return false;
        }
        return super.hurt(source, amount);
    }

    private boolean dodge(LivingEntity attacker) {
        Vec3 away = position().subtract(attacker.position()).multiply(1, 0, 1).normalize();
        Vec3 side = new Vec3(-away.z, 0, away.x).scale(random.nextBoolean() ? 3.0 : -3.0);
        Vec3 dest = position().add(side);
        if (!level().noCollision(this, getBoundingBox().move(side))) return false;
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(ServerFx.dust(variant.color, 1.0f), getX(), getY() + 1, getZ(), 20, 0.3, 0.8, 0.3, 0);
        }
        teleportTo(dest.x, dest.y, dest.z);
        level().playSound(null, getX(), getY(), getZ(), SoundEvents.ILLUSIONER_MIRROR_MOVE, SoundSource.HOSTILE, 1.0f, 1.8f);
        dodgeCooldown = Math.max(20, 50 - 10 * stage);
        return true;
    }

    private void poof() {
        if (level() instanceof ServerLevel sl) ServerFx.burst(sl, position().add(0, 1, 0), variant.color, 20);
    }

    // ------------------------------------------------------------------ client visuals

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            double speed = Math.hypot(getX() - xo, getZ() - zo);
            if (speed > 0.15 || random.nextInt(4) == 0) {
                float[] c = SpeedMath.rgb(variant.color);
                DustParticleOptions dust = new DustParticleOptions(new Vector3f(c[0], c[1], c[2]), 0.7f);
                int n = 2 + (int) Math.min(12, speed * 5);
                for (int i = 0; i < n; i++) {
                    double t = random.nextDouble();
                    level().addParticle(dust, xo + (getX() - xo) * t + (random.nextDouble() - 0.5) * 0.4,
                            getY() + 0.1 + random.nextDouble() * 1.7,
                            zo + (getZ() - zo) * t + (random.nextDouble() - 0.5) * 0.4, 0, 0, 0);
                }
                if (random.nextInt(3) == 0) level().addParticle(ParticleTypes.ELECTRIC_SPARK, getRandomX(0.5), getRandomY(), getRandomZ(0.5), 0, 0, 0);
            }
        }
    }

    // ------------------------------------------------------------------ misc overrides

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        if (bossEvent != null) bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        if (bossEvent != null) bossEvent.removePlayer(player);
    }

    @Override
    public boolean causeFallDamage(float fallDistance, float multiplier, DamageSource source) {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return !variant.boss && life < 0 && !isAlly();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Ally", isAlly());
        tag.putInt("Life", life);
        tag.putInt("Stage", stage);
        if (owner != null) tag.putUUID("Owner", owner);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        entityData.set(DATA_ALLY, tag.getBoolean("Ally"));
        life = tag.contains("Life") ? tag.getInt("Life") : -1;
        stage = tag.getInt("Stage");
        if (tag.hasUUID("Owner")) owner = tag.getUUID("Owner");
        if (bossEvent != null && hasCustomName()) bossEvent.setName(getDisplayName());
    }
}
