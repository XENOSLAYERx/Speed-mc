package com.nero.speedforce.client;

import net.neoforged.neoforge.common.ModConfigSpec;

public final class ClientConfig {
    private static final ModConfigSpec.Builder B = new ModConfigSpec.Builder();

    public static final ModConfigSpec.BooleanValue HUD_ENABLED;
    public static final ModConfigSpec.BooleanValue HUD_AUTO_HIDE;
    public static final ModConfigSpec.IntValue HUD_X;
    public static final ModConfigSpec.IntValue HUD_Y;
    public static final ModConfigSpec.DoubleValue HUD_SCALE;
    public static final ModConfigSpec.BooleanValue DYNAMIC_FOV;
    public static final ModConfigSpec.DoubleValue FOV_STRENGTH;
    public static final ModConfigSpec.BooleanValue CAMERA_SHAKE;
    public static final ModConfigSpec.BooleanValue WALL_RUN_TILT;
    public static final ModConfigSpec.DoubleValue PARTICLES;
    public static final ModConfigSpec.BooleanValue WIND_SOUND;
    public static final ModConfigSpec SPEC;

    static {
        B.push("hud");
        HUD_ENABLED = B.comment("Show the Speed Force HUD.").define("hudEnabled", true);
        HUD_AUTO_HIDE = B.comment("Hide the HUD when you are not using your powers.").define("hudAutoHide", true);
        HUD_X = B.defineInRange("hudX", 6, 0, 4000);
        HUD_Y = B.defineInRange("hudY", 6, 0, 4000);
        HUD_SCALE = B.defineInRange("hudScale", 1.0, 0.5, 3.0);
        B.pop();

        B.push("camera");
        DYNAMIC_FOV = B.comment("FOV widens as you accelerate.").define("dynamicFov", true);
        FOV_STRENGTH = B.defineInRange("fovStrength", 1.0, 0.0, 2.0);
        CAMERA_SHAKE = B.comment("Screen shake on impacts, sonic booms and supersonic punches.").define("cameraShake", true);
        WALL_RUN_TILT = B.comment("Camera tilts while wall running.").define("wallRunTilt", true);
        B.pop();

        B.push("effects");
        PARTICLES = B.comment("Particle density for lightning and trails (0 = off).").defineInRange("particleDensity", 1.0, 0.0, 3.0);
        WIND_SOUND = B.comment("Wind roar that scales with your speed.").define("windSound", true);
        B.pop();

        SPEC = B.build();
    }

    private ClientConfig() {}
}
