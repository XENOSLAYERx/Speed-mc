package com.nero.speedforce.server;

import com.nero.speedforce.data.SpeedData;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * Races: cross gate 0 to start, pass checkpoints 1..N in order, cross gate 0 again to finish.
 * Crossings are detected along the path travelled each tick, so gates can't be skipped at 350 m/s.
 */
public final class RaceManager {
    private static final double GATE_RADIUS = 2.4;
    private static final long TIMEOUT = 20L * 60 * 10;

    private RaceManager() {}

    public static void tick(ServerPlayer p, SpeedData d, Vec3 prev, Vec3 cur) {
        ServerLevel level = p.serverLevel();
        long now = level.getGameTime();
        if (d.raceStart >= 0 && now - d.raceStart > TIMEOUT) {
            d.raceStart = -1;
            d.markDirty();
            AbilityHandler.bar(p, "Race timed out", ChatFormatting.GRAY);
        }
        RaceData data = RaceData.get(level);
        if (data.gates.isEmpty()) return;
        Vec3 a = prev.add(0, 0.9, 0);
        Vec3 b = cur.add(0, 0.9, 0);
        for (Map.Entry<BlockPos, Integer> g : data.gates.entrySet()) {
            BlockPos gp = g.getKey();
            Vec3 c = Vec3.atCenterOf(gp);
            if (distToSegmentSqr(c, a, b) > GATE_RADIUS * GATE_RADIUS) continue;
            if (d.lastGate == gp.asLong() && now - d.lastGateTime < 20) continue;
            d.lastGate = gp.asLong();
            d.lastGateTime = now;
            cross(p, d, data, gp, g.getValue(), now);
        }
    }

    private static void cross(ServerPlayer p, SpeedData d, RaceData data, BlockPos gate, int index, long now) {
        ServerLevel level = p.serverLevel();
        if (index == 0) {
            if (d.raceStart >= 0 && d.raceOrigin == gate.asLong() && now - d.raceStart > 20) {
                int max = data.maxIndexNear(gate);
                if (d.raceNext > max) {
                    finish(p, d, data, gate, (int) (now - d.raceStart));
                    return;
                }
                AbilityHandler.bar(p, "Missed checkpoint " + d.raceNext + "!", ChatFormatting.RED);
                return;
            }
            d.raceStart = now;
            d.raceNext = 1;
            d.raceOrigin = gate.asLong();
            d.markDirty();
            AbilityHandler.bar(p, "\u26A1 RACE STARTED", ChatFormatting.GOLD);
            level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.NOTE_BLOCK_PLING.value(), SoundSource.PLAYERS, 1.0f, 2.0f);
        } else if (d.raceStart >= 0 && index == d.raceNext) {
            d.raceNext++;
            d.markDirty();
            AbilityHandler.bar(p, "Checkpoint " + index + "  " + format((int) (now - d.raceStart)), ChatFormatting.YELLOW);
            level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.NOTE_BLOCK_PLING.value(), SoundSource.PLAYERS, 1.0f, 1.5f);
        }
    }

    private static void finish(ServerPlayer p, SpeedData d, RaceData data, BlockPos gate, int ticks) {
        d.raceStart = -1;
        d.markDirty();
        String name = p.getGameProfile().getName();
        List<RaceData.Entry> board = data.boards.computeIfAbsent(gate.asLong(), k -> new ArrayList<>());
        RaceData.Entry existing = null;
        for (RaceData.Entry e : board) if (e.name().equals(name)) existing = e;
        boolean best = existing == null || ticks < existing.ticks();
        if (best) {
            if (existing != null) board.remove(existing);
            board.add(new RaceData.Entry(name, ticks));
            board.sort(Comparator.comparingInt(RaceData.Entry::ticks));
            while (board.size() > 10) board.remove(board.size() - 1);
            data.setDirty();
        }
        p.sendSystemMessage(Component.literal("\u26A1 FINISH  " + format(ticks) + (best ? "  (personal best!)" : ""))
                .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1.0f, 1.2f);
        showLeaderboard(p.serverLevel(), gate, p);
    }

    public static void showLeaderboard(ServerLevel level, BlockPos gate, Player viewer) {
        List<RaceData.Entry> board = RaceData.get(level).boards.get(gate.asLong());
        viewer.sendSystemMessage(Component.literal("\u26A1 RACE LEADERBOARD").withStyle(ChatFormatting.GOLD));
        if (board == null || board.isEmpty()) {
            viewer.sendSystemMessage(Component.literal(" No times yet. Cross this gate to start!").withStyle(ChatFormatting.GRAY));
            return;
        }
        for (int i = 0; i < Math.min(5, board.size()); i++) {
            RaceData.Entry e = board.get(i);
            viewer.sendSystemMessage(Component.literal(" " + (i + 1) + ". " + e.name() + " \u2014 " + format(e.ticks()))
                    .withStyle(i == 0 ? ChatFormatting.YELLOW : ChatFormatting.WHITE));
        }
    }

    public static String format(int ticks) {
        double seconds = ticks / 20.0;
        int min = (int) (seconds / 60);
        return String.format("%02d:%05.2f", min, seconds - min * 60);
    }

    private static double distToSegmentSqr(Vec3 c, Vec3 a, Vec3 b) {
        Vec3 ab = b.subtract(a);
        double len2 = ab.lengthSqr();
        if (len2 < 1e-9) return c.distanceToSqr(a);
        double t = Math.max(0, Math.min(1, c.subtract(a).dot(ab) / len2));
        return c.distanceToSqr(a.add(ab.scale(t)));
    }
}
