package com.nero.speedforce.network;

import com.nero.speedforce.client.ClientPayloadHandler;
import com.nero.speedforce.server.AbilityHandler;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public final class ModNetwork {
    private ModNetwork() {}

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");

        registrar.playToServer(AbilityPayload.TYPE, AbilityPayload.STREAM_CODEC, (payload, context) ->
                context.enqueueWork(() -> {
                    if (context.player() instanceof ServerPlayer player) {
                        AbilityHandler.handle(player, payload.ability(), payload.arg());
                    }
                }));

        // Lambdas (not method refs) so client classes are only resolved on the client.
        registrar.playToClient(SyncPayload.TYPE, SyncPayload.STREAM_CODEC, (payload, context) ->
                context.enqueueWork(() -> ClientPayloadHandler.handleSync(payload)));

        registrar.playToClient(FxPayload.TYPE, FxPayload.STREAM_CODEC, (payload, context) ->
                context.enqueueWork(() -> ClientPayloadHandler.handleFx(payload)));
    }
}
