package com.nero.speedforce.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.nero.speedforce.SpeedForceHooks;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

/**
 * Dedicated servers kick players for "moving too quickly". Speedsters are expected to, so the check is
 * skipped for players with an active Speed Force (the same way it is skipped for the singleplayer host).
 */
@Mixin(ServerGamePacketListenerImpl.class)
public abstract class ServerGamePacketListenerImplMixin {
    @Shadow
    public ServerPlayer player;

    @ModifyExpressionValue(method = "handleMovePlayer",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerGamePacketListenerImpl;isSingleplayerOwner()Z"))
    private boolean speedforce$trustSpeedsters(boolean original) {
        return original || SpeedForceHooks.bypassMovementCheck(this.player);
    }
}
