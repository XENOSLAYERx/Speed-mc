package com.nero.speedforce.entity;

import com.nero.speedforce.data.SpeedData;
import com.nero.speedforce.registry.ModAttachments;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Vex;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Hunts speedsters who abuse the Speed Force. Flies through walls, blinks behind its prey
 * when outrun, and drains Speed Force energy on hit.
 */
public class TimeWraithEntity extends Vex {
    private int blinkCooldown = 60;
    private int lifeTicks = 2400;
    private int idleTicks;

    public TimeWraithEntity(EntityType<? extends Vex> type, Level level) {
        super(type, level);
        this.xpReward = 25;
    }

    public static AttributeSupplier.Builder createWraithAttributes() {
        return Vex.createAttributes()
                .add(Attributes.MAX_HEALTH, 40.0)
                .add(Attributes.ATTACK_DAMAGE, 7.0)
                .add(Attributes.FOLLOW_RANGE, 64.0);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            if (random.nextInt(2) == 0) {
                level().addParticle(ParticleTypes.SOUL, getRandomX(0.6), getRandomY(), getRandomZ(0.6), 0, 0.02, 0);
            }
            level().addParticle(ParticleTypes.SMOKE, getRandomX(0.5), getRandomY(), getRandomZ(0.5), 0, 0, 0);
            return;
        }
        if (--lifeTicks <= 0) {
            vanish();
            return;
        }
        LivingEntity target = getTarget();
        if (target == null) {
            if (++idleTicks > 400) vanish();
            return;
        }
        idleTicks = 0;
        if (--blinkCooldown <= 0 && distanceTo(target) > 10) {
            Vec3 behind = target.position().subtract(target.getLookAngle().multiply(1, 0, 1).normalize().scale(3)).add(0, 1, 0);
            ((ServerLevel) level()).sendParticles(ParticleTypes.REVERSE_PORTAL, getX(), getY() + 1, getZ(), 30, 0.4, 0.8, 0.4, 0.1);
            teleportTo(behind.x, behind.y, behind.z);
            level().playSound(null, getX(), getY(), getZ(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 1.0f, 0.5f);
            blinkCooldown = 80;
        }
    }

    private void vanish() {
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.SOUL, getX(), getY() + 1, getZ(), 30, 0.4, 0.8, 0.4, 0.05);
        }
        discard();
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hit = super.doHurtTarget(target);
        if (hit && target instanceof ServerPlayer sp) {
            SpeedData d = sp.getData(ModAttachments.SPEED);
            d.energy = Math.max(0f, d.energy - 25f);
            d.markDirty();
            sp.addEffect(new MobEffectInstance(MobEffects.WITHER, 60, 0));
            sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1));
        }
        return hit;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }
}
