package com.nero.speedforce.block;

import com.mojang.serialization.MapCodec;
import com.nero.speedforce.registry.ModBlockEntities;
import com.nero.speedforce.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * Multiblock controller. Structure (one layer, controller in the middle):
 *   R C R
 *   C A C     A = accelerator, C = any copper block, R = redstone block
 *   R C R     plus a lightning rod on top of the accelerator.
 * Insert a Dark-Matter Vial to start the Speed Force Storm.
 */
public class ParticleAcceleratorBlock extends BaseEntityBlock {
    public static final IntegerProperty POWER = IntegerProperty.create("power", 0, 2);
    public static final MapCodec<ParticleAcceleratorBlock> CODEC = simpleCodec(ParticleAcceleratorBlock::new);

    public ParticleAcceleratorBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(POWER, 0));
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(POWER);
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new AcceleratorBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide ? null : createTickerHelper(type, ModBlockEntities.ACCELERATOR.get(), AcceleratorBlockEntity::serverTick);
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player,
                                              InteractionHand hand, BlockHitResult hit) {
        if (!stack.is(ModItems.DARK_MATTER_VIAL.get())) return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        if (level.isClientSide) return ItemInteractionResult.SUCCESS;
        if (!(level.getBlockEntity(pos) instanceof AcceleratorBlockEntity be)) return ItemInteractionResult.FAIL;
        if (be.isRunning()) {
            player.displayClientMessage(Component.translatable("message.speedforce.accelerator_running").withStyle(ChatFormatting.YELLOW), true);
            return ItemInteractionResult.CONSUME;
        }
        List<String> missing = checkStructure(level, pos);
        if (!missing.isEmpty()) {
            player.sendSystemMessage(Component.translatable("message.speedforce.accelerator_incomplete").withStyle(ChatFormatting.RED));
            for (String m : missing) player.sendSystemMessage(Component.literal(" - " + m).withStyle(ChatFormatting.GRAY));
            return ItemInteractionResult.CONSUME;
        }
        if (!player.getAbilities().instabuild) stack.shrink(1);
        be.start();
        player.sendSystemMessage(Component.translatable("message.speedforce.accelerator_online").withStyle(ChatFormatting.GOLD));
        return ItemInteractionResult.CONSUME;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        List<String> missing = checkStructure(level, pos);
        if (missing.isEmpty()) {
            player.displayClientMessage(Component.translatable("message.speedforce.accelerator_ready").withStyle(ChatFormatting.GREEN), true);
        } else {
            player.sendSystemMessage(Component.translatable("message.speedforce.accelerator_structure").withStyle(ChatFormatting.GOLD));
            for (String m : missing) player.sendSystemMessage(Component.literal(" - " + m).withStyle(ChatFormatting.GRAY));
        }
        return InteractionResult.CONSUME;
    }

    public static List<String> checkStructure(Level level, BlockPos pos) {
        List<String> missing = new ArrayList<>();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                BlockPos p = pos.offset(dx, 0, dz);
                BlockState s = level.getBlockState(p);
                boolean corner = dx != 0 && dz != 0;
                if (corner && !s.is(Blocks.REDSTONE_BLOCK)) {
                    missing.add("Redstone Block at " + p.toShortString());
                } else if (!corner && !isCopper(s)) {
                    missing.add("Copper Block at " + p.toShortString());
                }
            }
        }
        if (!level.getBlockState(pos.above()).is(Blocks.LIGHTNING_ROD)) {
            missing.add("Lightning Rod on top of the accelerator");
        }
        return missing;
    }

    private static boolean isCopper(BlockState state) {
        String path = BuiltInRegistries.BLOCK.getKey(state.getBlock()).getPath();
        if (!path.contains("copper")) return false;
        for (String bad : new String[]{"stairs", "slab", "door", "bulb", "grate", "ore"}) {
            if (path.contains(bad)) return false;
        }
        return true;
    }
}
