package com.nero.speedforce.client;

import com.nero.speedforce.network.FxPayload;
import com.nero.speedforce.network.SyncPayload;
import com.nero.speedforce.registry.ModAttachments;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

public final class ClientPayloadHandler {
    private ClientPayloadHandler() {}

    public static void handleSync(SyncPayload payload) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        Entity e = mc.level.getEntity(payload.entityId());
        if (e instanceof Player p) {
            p.getData(ModAttachments.SPEED).deserializeNBT(mc.level.registryAccess(), payload.tag());
        }
    }

    public static void handleFx(FxPayload payload) {
        switch (payload.kind()) {
            case FxPayload.ACTIVATE -> ClientFx.activate((int) payload.value());
            case FxPayload.SHAKE -> ClientFx.addShake(payload.value());
            case FxPayload.FLASH -> ClientFx.flash((int) payload.value());
            case FxPayload.BOOM -> {
                ClientFx.addShake(6f);
                ClientFx.flash(6);
            }
            default -> { }
        }
    }
}
