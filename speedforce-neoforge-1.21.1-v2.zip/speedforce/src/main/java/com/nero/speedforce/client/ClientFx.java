package com.nero.speedforce.client;

import com.nero.speedforce.data.SpeedData;
import com.nero.speedforce.data.SpeedForceType;
import com.nero.speedforce.data.SpeedMath;
import com.nero.speedforce.registry.ModAttachments;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** Client-side visuals: lightning trails and arcs for every speedster, screen shake, flash, FOV, wind. */
public final class ClientFx {
    public static float shake;
    public static int flashTicks;
    public static int flashMax = 1;
    public static int activationTicks;
    public static final int ACTIVATION_LENGTH = 70;
    public static int activationColor = 0xFFD21F;
    public static String activationTitle = "SPEED FORCE ONLINE";
    public static int hudTicks;
    public static double hudSpeed;
    public static float fovFactor = 1f;
    private static SpeedWindSound wind;

    private ClientFx() {}

    public static void activate(int typeOrdinal) {
        SpeedForceType[] types = SpeedForceType.values();
        SpeedForceType type = typeOrdinal >= 0 && typeOrdinal < types.length ? types[typeOrdinal] : SpeedForceType.SPEED;
        activationColor = type.color;
        activationTitle = switch (type) {
            case NEGATIVE -> "NEGATIVE SPEED FORCE";
            case V9 -> "V-9 ACTIVE";
            default -> "SPEED FORCE ONLINE";
        };
        activationTicks = ACTIVATION_LENGTH;
        flash(14);
        addShake(5f);
        hudTicks = 100;
    }

    public static void flash(int ticks) {
        flashTicks = flashMax = Math.max(1, ticks);
    }

    public static void addShake(float amount) {
        shake = Math.max(shake, amount);
    }

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        LocalPlayer me = mc.player;
        if (level == null || me == null) return;
        if (mc.isPaused()) return;

        if (flashTicks > 0) flashTicks--;
        if (activationTicks > 0) activationTicks--;
        if (hudTicks > 0) hudTicks--;
        shake *= 0.85f;
        if (shake < 0.02f) shake = 0f;

        SpeedData md = me.getData(ModAttachments.SPEED);
        double sp = SpeedController.displaySpeed;
        if (md.isPowered() && (sp > 0.3 || md.phasing || md.perception || md.tornado || md.foreverActive
                || md.raceStart >= 0 || ClientInput.isCharging())) {
            hudTicks = Math.max(hudTicks, 60);
        }
        hudSpeed += (sp * 20.0 - hudSpeed) * 0.25;

        float target = 1f;
        if (md.isPowered() && ClientConfig.DYNAMIC_FOV.get()) {
            target = 1f + (float) (Mth.clamp((sp - 0.4) / 12.0, 0.0, 0.5) * ClientConfig.FOV_STRENGTH.get());
        }
        fovFactor += (target - fovFactor) * 0.15f;

        if (ClientConfig.WIND_SOUND.get() && md.isPowered() && sp > 0.6 && (wind == null || wind.isStopped())) {
            wind = new SpeedWindSound(me);
            mc.getSoundManager().play(wind);
        }

        double density = ClientConfig.PARTICLES.get();
        if (density <= 0) return;
        for (AbstractClientPlayer p : level.players()) {
            if (p.isSpectator() || p.distanceToSqr(me) > 96 * 96) continue;
            SpeedData d = p.getData(ModAttachments.SPEED);
            if (!d.isPowered()) continue;
            playerFx(mc, level, p, d, p == me, density);
        }
    }

    private static void playerFx(Minecraft mc, ClientLevel level, AbstractClientPlayer p, SpeedData d, boolean self, double density) {
        RandomSource r = p.getRandom();
        float[] c = SpeedMath.rgb(SpeedMath.lightningColor(p, d));
        Vector3f col = new Vector3f(c[0], c[1], c[2]);
        double sp = Math.hypot(p.getX() - p.xo, p.getZ() - p.zo);
        boolean firstPerson = self && mc.options.getCameraType().isFirstPerson();
        double height = firstPerson ? 1.1 : 1.8;

        // speed trail (afterimage streak)
        if (sp > 0.35) {
            int n = (int) Math.min(30, (sp * 3 + 2) * density);
            DustParticleOptions trail = new DustParticleOptions(col, 0.9f);
            for (int i = 0; i < n; i++) {
                double t = r.nextDouble();
                if (firstPerson && t > 0.7) continue;
                double x = Mth.lerp(t, p.xo, p.getX()) + (r.nextDouble() - 0.5) * 0.3;
                double y = Mth.lerp(t, p.yo, p.getY()) + 0.15 + r.nextDouble() * (height - 0.2);
                double z = Mth.lerp(t, p.zo, p.getZ()) + (r.nextDouble() - 0.5) * 0.3;
                level.addParticle(trail, x, y, z, 0, 0, 0);
            }
            if (sp > 1.0 && !firstPerson) {
                DustParticleOptions ghost = new DustParticleOptions(new Vector3f(1f, 1f, 1f), 0.6f);
                for (int i = 0; i < 3; i++) {
                    double t = r.nextDouble() * 0.5;
                    level.addParticle(ghost, Mth.lerp(t, p.xo, p.getX()), Mth.lerp(t, p.yo, p.getY()) + 0.3 + r.nextDouble() * 1.4,
                            Mth.lerp(t, p.zo, p.getZ()), 0, 0, 0);
                }
            }
        }

        // body lightning
        int arcs = sp > 0.8 ? 1 + (int) Math.min(4, sp * 0.6) : ((d.level >= 5 || d.v9Ticks > 0) && r.nextInt(5) == 0 ? 1 : 0);
        if (d.phasing) arcs++;
        if (d.foreverActive) arcs += 2;
        arcs = (int) Math.round(arcs * Math.min(density, 2.0));
        for (int i = 0; i < arcs; i++) {
            Vec3 a = new Vec3(p.getX() + (r.nextDouble() - 0.5) * 0.8, p.getY() + 0.1 + r.nextDouble() * height * 0.9, p.getZ() + (r.nextDouble() - 0.5) * 0.8);
            Vec3 b = a.add((r.nextDouble() - 0.5) * 1.0, (r.nextDouble() - 0.5) * 0.9, (r.nextDouble() - 0.5) * 1.0);
            arc(level, a, b, col, r);
        }
        if (sp > 0.6 && r.nextInt(3) == 0) {
            level.addParticle(ParticleTypes.ELECTRIC_SPARK, p.getRandomX(0.6), p.getY() + r.nextDouble() * height, p.getRandomZ(0.6), 0, 0, 0);
        }

        // kicked-up ground
        if (p.onGround() && sp > 0.6 && r.nextFloat() < 0.7f) {
            BlockPos below = p.blockPosition().below();
            BlockState bs = level.getBlockState(below);
            if (!bs.isAir()) {
                BlockParticleOption dust = new BlockParticleOption(ParticleTypes.BLOCK, bs);
                for (int i = 0; i < 2; i++) {
                    level.addParticle(dust, p.getX() + (r.nextDouble() - 0.5) * 0.6, p.getY() + 0.1, p.getZ() + (r.nextDouble() - 0.5) * 0.6,
                            -(p.getX() - p.xo) * 0.1, 0.15, -(p.getZ() - p.zo) * 0.1);
                }
                if (r.nextInt(3) == 0) level.addParticle(ParticleTypes.CLOUD, p.getX(), p.getY() + 0.1, p.getZ(), 0, 0.02, 0);
            }
        }

        // water running spray
        BlockPos under = BlockPos.containing(p.getX(), p.getY() - 0.2, p.getZ());
        if (sp > 0.5 && !p.isInWater() && level.getFluidState(under).is(FluidTags.WATER)) {
            for (int i = 0; i < 5; i++) {
                level.addParticle(ParticleTypes.SPLASH, p.getRandomX(0.8), p.getY(), p.getRandomZ(0.8), 0, 0.3, 0);
            }
            level.addParticle(ParticleTypes.BUBBLE_POP, p.getX(), p.getY(), p.getZ(), 0, 0.05, 0);
        }

        // pressure wave past the sound barrier
        if (sp > SpeedMath.SOUND_BARRIER_BT * 0.9 && p.tickCount % 6 == 0) {
            DustParticleOptions white = new DustParticleOptions(new Vector3f(1f, 1f, 1f), 1.2f);
            for (int i = 0; i < 16; i++) {
                double a = i * (Math.PI * 2 / 16);
                level.addParticle(white, p.getX() + Math.cos(a) * 1.6, p.getY() + 1.0, p.getZ() + Math.sin(a) * 1.6, 0, 0, 0);
            }
        }

        // phasing vibration
        if (d.phasing || d.entityPhaseTicks > 0) {
            for (int i = 0; i < 2; i++) {
                level.addParticle(ParticleTypes.ELECTRIC_SPARK, p.getRandomX(0.7), p.getY() + r.nextDouble() * height, p.getRandomZ(0.7), 0, 0, 0);
            }
        }
    }

    private static void arc(ClientLevel level, Vec3 a, Vec3 b, Vector3f col, RandomSource r) {
        DustParticleOptions core = new DustParticleOptions(col, 0.45f);
        Vec3 prev = a;
        int segments = 4;
        for (int s = 1; s <= segments; s++) {
            Vec3 next = s == segments ? b : a.lerp(b, s / (double) segments)
                    .add((r.nextDouble() - 0.5) * 0.25, (r.nextDouble() - 0.5) * 0.25, (r.nextDouble() - 0.5) * 0.25);
            for (int i = 0; i < 3; i++) {
                Vec3 q = prev.lerp(next, i / 3.0);
                level.addParticle(core, q.x, q.y, q.z, 0, 0, 0);
            }
            prev = next;
        }
    }
}
