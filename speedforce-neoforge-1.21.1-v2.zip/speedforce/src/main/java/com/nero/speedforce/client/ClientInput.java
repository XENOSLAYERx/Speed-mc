package com.nero.speedforce.client;

import com.nero.speedforce.Config;
import com.nero.speedforce.data.SpeedData;
import com.nero.speedforce.network.Ability;
import com.nero.speedforce.network.AbilityPayload;
import com.nero.speedforce.registry.ModAttachments;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

/** Key handling: taps, holds and charge-ups. */
public final class ClientInput {
    public static int lightningCharge = -1;
    public static int massCharge = -1;
    private static boolean burstFired;
    private static boolean tornadoHeld;

    private ClientInput() {}

    public static boolean isCharging() {
        return lightningCharge >= 0 || massCharge >= 0 || tornadoHeld;
    }

    public static void reset() {
        lightningCharge = -1;
        massCharge = -1;
        burstFired = false;
        tornadoHeld = false;
    }

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null) return;
        SpeedData d = p.getData(ModAttachments.SPEED);

        while (KeyBinds.POWER.consumeClick()) send(Ability.POWER_TOGGLE, 0);
        if (!d.isPowered() || p.isSpectator()) {
            for (KeyMapping k : KeyBinds.ALL) {
                while (k.consumeClick()) { }
            }
            if (tornadoHeld) send(Ability.TORNADO_STOP, 0);
            reset();
            return;
        }

        while (KeyBinds.LEVEL_UP.consumeClick()) changeLevel(d, 1);
        while (KeyBinds.LEVEL_DOWN.consumeClick()) changeLevel(d, -1);
        lightning(p);
        massPunch(p);
        tornado(p);
        while (KeyBinds.PHASE.consumeClick()) send(p.isShiftKeyDown() ? Ability.ENTITY_PHASE : Ability.PHASE, 0);
        while (KeyBinds.PERCEPTION.consumeClick()) send(Ability.PERCEPTION, 0);
        while (KeyBinds.SPEED_STEAL.consumeClick()) send(Ability.SPEED_STEAL, 0);
        while (KeyBinds.DASH.consumeClick()) {
            SpeedController.dash(p);
            send(Ability.DASH, 0);
        }
        while (KeyBinds.TRAVEL.consumeClick()) send(Ability.TRAVEL, 0);
        while (KeyBinds.FOREVER.consumeClick()) send(p.isShiftKeyDown() ? Ability.SNAP : Ability.FOREVER, 0);
        while (KeyBinds.SUIT_ABILITY.consumeClick()) send(Ability.SUIT_ABILITY, 0);
    }

    /** R: tap to throw, hold to charge a bigger bolt. Sneak + R: lightning burst. */
    private static void lightning(LocalPlayer p) {
        boolean clicked = false;
        while (KeyBinds.LIGHTNING.consumeClick()) clicked = true;
        boolean down = KeyBinds.LIGHTNING.isDown();
        if (down || clicked) {
            if (lightningCharge < 0 && !burstFired) {
                if (p.isShiftKeyDown()) {
                    send(Ability.BURST, 0);
                    burstFired = true;
                } else {
                    lightningCharge = 0;
                }
            } else if (lightningCharge >= 0 && down) {
                lightningCharge = Math.min(40, lightningCharge + 1);
            }
        }
        if (!down) {
            if (lightningCharge >= 0) {
                send(Ability.LIGHTNING, lightningCharge);
                lightningCharge = -1;
            }
            burstFired = false;
        }
    }

    /** G: hold while running to build velocity, release to unleash the Mass Punch. */
    private static void massPunch(LocalPlayer p) {
        while (KeyBinds.MASS_PUNCH.consumeClick()) { }
        boolean down = KeyBinds.MASS_PUNCH.isDown();
        if (down) {
            if (massCharge < 0) massCharge = 0;
            if (SpeedController.speed > 0.5) massCharge = Math.min(100, massCharge + 2);
        } else if (massCharge >= 0) {
            if (massCharge >= 15) {
                send(Ability.MASS_PUNCH, massCharge);
                SpeedController.startMassDash(p);
            }
            massCharge = -1;
        }
    }

    /** H: hold to spin a tornado; aim at a mob first to trap it in a speed vortex. */
    private static void tornado(LocalPlayer p) {
        while (KeyBinds.TORNADO.consumeClick()) { }
        boolean down = KeyBinds.TORNADO.isDown();
        if (down && !tornadoHeld) {
            tornadoHeld = true;
            int target = pickTarget(p, 12);
            SpeedController.orbitTarget = target;
            send(Ability.TORNADO_START, target);
        } else if (!down && tornadoHeld) {
            tornadoHeld = false;
            SpeedController.orbitTarget = -1;
            send(Ability.TORNADO_STOP, 0);
        }
    }

    public static void changeLevel(SpeedData d, int delta) {
        int next = Mth.clamp(d.level + delta, 1, Config.MAX_SPEED_LEVEL.get());
        if (next != d.level) {
            d.level = next;
            send(Ability.LEVEL_SET, next);
        }
        ClientFx.hudTicks = 60;
    }

    private static int pickTarget(LocalPlayer p, double range) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getViewVector(1f);
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(p, eye, eye.add(look.scale(range)),
                p.getBoundingBox().expandTowards(look.scale(range)).inflate(1.0),
                e -> e instanceof LivingEntity && e != p && !e.isSpectator() && e.isPickable(), range * range);
        return hit != null ? hit.getEntity().getId() : -1;
    }

    static void send(Ability ability, int arg) {
        PacketDistributor.sendToServer(new AbilityPayload(ability, arg));
    }
}
