package com.nero.speedforce;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Gameplay config (config/speedforce-common.toml). */
public final class Config {
    private static final ModConfigSpec.Builder B = new ModConfigSpec.Builder();

    public static final ModConfigSpec.DoubleValue SPEED_MULTIPLIER;
    public static final ModConfigSpec.DoubleValue MAX_BLOCKS_PER_TICK;
    public static final ModConfigSpec.IntValue MAX_SPEED_LEVEL;
    public static final ModConfigSpec.IntValue WATER_RUN_LEVEL;
    public static final ModConfigSpec.IntValue WALL_RUN_LEVEL;
    public static final ModConfigSpec.IntValue TRAVEL_LEVEL;

    public static final ModConfigSpec.DoubleValue ENERGY_DRAIN;
    public static final ModConfigSpec.DoubleValue HUNGER_MULTIPLIER;
    public static final ModConfigSpec.DoubleValue PHASE_COST;
    public static final ModConfigSpec.DoubleValue PERCEPTION_COST;

    public static final ModConfigSpec.BooleanValue COLLISION_DAMAGE;
    public static final ModConfigSpec.DoubleValue COLLISION_MULTIPLIER;
    public static final ModConfigSpec.DoubleValue SUPERSONIC_MULTIPLIER;
    public static final ModConfigSpec.BooleanValue MASS_PUNCH_DESTRUCTION;
    public static final ModConfigSpec.BooleanValue BREAK_PLANTS;

    public static final ModConfigSpec.DoubleValue BOSS_HEALTH;
    public static final ModConfigSpec.BooleanValue TIME_WRAITHS;
    public static final ModConfigSpec.BooleanValue SPEED_FORCE_DIMENSION;
    public static final ModConfigSpec.IntValue RESIDUE_DISTANCE;

    public static final ModConfigSpec SPEC;

    static {
        B.push("movement");
        SPEED_MULTIPLIER = B.comment("Multiplies the top speed of every speed level.").defineInRange("speedMultiplier", 1.0, 0.1, 5.0);
        MAX_BLOCKS_PER_TICK = B.comment("Hard cap on speedster velocity in blocks per tick (20 = 400 m/s). Lower this on weak servers.").defineInRange("maxBlocksPerTick", 18.0, 1.0, 40.0);
        MAX_SPEED_LEVEL = B.comment("Highest speed level players can select.").defineInRange("maxSpeedLevel", 10, 1, 10);
        WATER_RUN_LEVEL = B.comment("Minimum active speed level for water running.").defineInRange("waterRunLevel", 6, 1, 10);
        WALL_RUN_LEVEL = B.comment("Minimum active speed level for wall running.").defineInRange("wallRunLevel", 7, 1, 10);
        TRAVEL_LEVEL = B.comment("Minimum active speed level to break into the Speed Force dimension.").defineInRange("speedForceTravelLevel", 9, 1, 10);
        B.pop();

        B.push("energy");
        ENERGY_DRAIN = B.comment("Multiplier for Speed Force energy drain while running.").defineInRange("energyDrain", 1.0, 0.0, 10.0);
        HUNGER_MULTIPLIER = B.comment("Multiplier for the speedster metabolism (hunger burned while running).").defineInRange("hungerMultiplier", 0.5, 0.0, 10.0);
        PHASE_COST = B.comment("Multiplier for phasing energy cost.").defineInRange("phaseCost", 1.0, 0.0, 10.0);
        PERCEPTION_COST = B.comment("Multiplier for speed perception energy cost.").defineInRange("perceptionCost", 1.0, 0.0, 10.0);
        B.pop();

        B.push("combat");
        COLLISION_DAMAGE = B.comment("Speedsters take damage when slamming into walls at high speed.").define("collisionDamage", true);
        COLLISION_MULTIPLIER = B.defineInRange("collisionDamageMultiplier", 1.0, 0.0, 10.0);
        SUPERSONIC_MULTIPLIER = B.comment("Multiplier for supersonic punch bonus damage.").defineInRange("supersonicDamage", 1.0, 0.0, 10.0);
        MASS_PUNCH_DESTRUCTION = B.comment("Mass Punch leaves a crater (destroys blocks).").define("massPunchDestruction", false);
        BREAK_PLANTS = B.comment("Running at high speed tears up grass and ferns.").define("breakPlants", true);
        B.pop();

        B.push("world");
        BOSS_HEALTH = B.comment("Multiplier for rival speedster boss health.").defineInRange("bossHealthMultiplier", 1.0, 0.1, 20.0);
        TIME_WRAITHS = B.comment("Abusing the Speed Force summons Time Wraiths.").define("timeWraiths", true);
        SPEED_FORCE_DIMENSION = B.comment("Allow travel into the Speed Force dimension.").define("speedForceDimension", true);
        RESIDUE_DISTANCE = B.comment("Blocks a speedster must run at high speed to shed one Speed Force Residue. 0 disables.").defineInRange("residueDistance", 3000, 0, 1000000);
        B.pop();

        SPEC = B.build();
    }

    private Config() {}
}
