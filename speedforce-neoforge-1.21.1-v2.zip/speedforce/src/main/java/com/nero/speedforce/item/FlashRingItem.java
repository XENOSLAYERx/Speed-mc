package com.nero.speedforce.item;

import com.nero.speedforce.data.SuitType;
import com.nero.speedforce.network.FxPayload;
import com.nero.speedforce.server.ServerFx;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.List;

/**
 * Stores full suits (with their enchantments) and deploys/retracts them.
 * Use: deploy selected suit / retract the worn suit. Sneak-use: cycle stored suits.
 */
public class FlashRingItem extends Item {
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    public FlashRingItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack ring = player.getItemInHand(hand);
        if (level.isClientSide || !(player instanceof ServerPlayer sp)) return InteractionResultHolder.success(ring);

        CompoundTag tag = ring.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        ListTag suits = tag.getList("Suits", Tag.TAG_COMPOUND);
        int selected = tag.getInt("Selected");

        if (sp.isShiftKeyDown()) {
            if (suits.isEmpty()) {
                sp.displayClientMessage(Component.translatable("message.speedforce.ring_empty").withStyle(ChatFormatting.GRAY), true);
            } else {
                selected = (selected + 1) % suits.size();
                tag.putInt("Selected", selected);
                CustomData.set(DataComponents.CUSTOM_DATA, ring, tag);
                sp.displayClientMessage(Component.translatable("message.speedforce.ring_selected", suitName(suits.getCompound(selected)))
                        .withStyle(ChatFormatting.YELLOW), true);
            }
            return InteractionResultHolder.consume(ring);
        }

        SuitType worn = SuitType.worn(sp);
        ServerLevel serverLevel = sp.serverLevel();
        if (worn != null) {
            CompoundTag entry = new CompoundTag();
            entry.putString("Suit", worn.id);
            ListTag pieces = new ListTag();
            for (EquipmentSlot slot : SLOTS) {
                pieces.add(sp.getItemBySlot(slot).save(level.registryAccess()));
                sp.setItemSlot(slot, ItemStack.EMPTY);
            }
            entry.put("Pieces", pieces);
            suits.add(entry);
            tag.put("Suits", suits);
            tag.putInt("Selected", suits.size() - 1);
            CustomData.set(DataComponents.CUSTOM_DATA, ring, tag);
            effects(sp, serverLevel, worn.lightning, false);
            sp.displayClientMessage(Component.translatable("message.speedforce.ring_retract", worn.displayName()).withStyle(ChatFormatting.YELLOW), true);
        } else if (!suits.isEmpty()) {
            selected = Mth.clamp(selected, 0, suits.size() - 1);
            CompoundTag entry = suits.getCompound(selected);
            ListTag pieces = entry.getList("Pieces", Tag.TAG_COMPOUND);
            for (int i = 0; i < SLOTS.length && i < pieces.size(); i++) {
                ItemStack piece = ItemStack.parseOptional(level.registryAccess(), pieces.getCompound(i));
                ItemStack old = sp.getItemBySlot(SLOTS[i]);
                if (!old.isEmpty() && !sp.getInventory().add(old)) sp.drop(old, false);
                sp.setItemSlot(SLOTS[i], piece);
            }
            suits.remove(selected);
            tag.put("Suits", suits);
            tag.putInt("Selected", 0);
            CustomData.set(DataComponents.CUSTOM_DATA, ring, tag);
            SuitType deployed = SuitType.byId(entry.getString("Suit"));
            effects(sp, serverLevel, deployed != null ? deployed.lightning : 0xFFD21F, true);
            sp.displayClientMessage(Component.translatable("message.speedforce.ring_deploy", suitName(entry)).withStyle(ChatFormatting.GOLD), true);
        } else {
            sp.displayClientMessage(Component.translatable("message.speedforce.ring_how").withStyle(ChatFormatting.GRAY), true);
        }
        return InteractionResultHolder.consume(ring);
    }

    private static void effects(ServerPlayer sp, ServerLevel level, int color, boolean deploy) {
        Vec3 c = sp.position();
        for (int i = 0; i < 40; i++) {
            double a = i * 0.45;
            double y = i * 0.05;
            level.sendParticles(ServerFx.dust(color, 1.1f), c.x + Math.cos(a) * 0.7, c.y + y, c.z + Math.sin(a) * 0.7, 1, 0, 0, 0, 0);
        }
        ServerFx.burst(level, c.add(0, 1, 0), color, 24);
        level.playSound(null, c.x, c.y, c.z, deploy ? SoundEvents.ARMOR_EQUIP_NETHERITE.value() : SoundEvents.ARMOR_EQUIP_ELYTRA.value(),
                SoundSource.PLAYERS, 1.0f, 1.3f);
        level.playSound(null, c.x, c.y, c.z, SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 0.5f, 1.8f);
        PacketDistributor.sendToPlayer(sp, new FxPayload(FxPayload.FLASH, sp.getId(), deploy ? 6 : 3));
    }

    private static Component suitName(CompoundTag entry) {
        SuitType s = SuitType.byId(entry.getString("Suit"));
        return s != null ? s.displayName() : Component.literal(entry.getString("Suit"));
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        ListTag suits = tag.getList("Suits", Tag.TAG_COMPOUND);
        int selected = tag.getInt("Selected");
        tooltip.add(Component.translatable("tooltip.speedforce.flash_ring").withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
        if (suits.isEmpty()) {
            tooltip.add(Component.translatable("tooltip.speedforce.flash_ring.empty").withStyle(ChatFormatting.DARK_GRAY));
        } else {
            tooltip.add(Component.translatable("tooltip.speedforce.flash_ring.stored").withStyle(ChatFormatting.GOLD));
            for (int i = 0; i < suits.size(); i++) {
                Component name = suitName(suits.getCompound(i));
                tooltip.add(Component.literal(i == selected ? " \u25B6 " : " \u2713 ").append(name)
                        .withStyle(i == selected ? ChatFormatting.YELLOW : ChatFormatting.WHITE));
            }
        }
        tooltip.add(Component.translatable("tooltip.speedforce.flash_ring.use").withStyle(ChatFormatting.DARK_AQUA));
    }
}
