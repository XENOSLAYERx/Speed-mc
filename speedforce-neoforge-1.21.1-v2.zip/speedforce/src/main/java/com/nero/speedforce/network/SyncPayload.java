package com.nero.speedforce.network;

import com.nero.speedforce.SpeedForceMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Server -> client: full Speed Force state of one player. */
public record SyncPayload(int entityId, CompoundTag tag) implements CustomPacketPayload {
    public static final Type<SyncPayload> TYPE = new Type<>(SpeedForceMod.rl("sync"));
    public static final StreamCodec<ByteBuf, SyncPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, SyncPayload::entityId,
            ByteBufCodecs.COMPOUND_TAG, SyncPayload::tag,
            SyncPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
