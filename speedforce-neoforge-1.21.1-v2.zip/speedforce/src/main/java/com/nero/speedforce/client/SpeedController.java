package com.nero.speedforce.client;

import com.nero.speedforce.Config;
import com.nero.speedforce.data.SpeedData;
import com.nero.speedforce.data.SpeedMath;
import com.nero.speedforce.network.Ability;
import com.nero.speedforce.network.AbilityPayload;
import com.nero.speedforce.registry.ModAttachments;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Momentum-based speedster movement for the local player.
 * You hold a velocity and a heading; acceleration builds speed toward the level's top speed, steering
 * turns the heading at a rate that shrinks as you go faster, and releasing the keys coasts you to a stop.
 */
public final class SpeedController {
    public static double speed;
    public static Vec3 dir = new Vec3(0, 0, 1);
    public static double displaySpeed;
    public static int dashTicks;
    public static int massDashTicks;
    public static int orbitTarget = -1;
    public static float wallRoll;
    public static boolean waterRunning;
    public static boolean wallRunning;
    public static boolean climbing;

    private static float targetRoll;
    private static boolean prevJump;

    private SpeedController() {}

    public static void reset() {
        speed = 0;
        dashTicks = 0;
        massDashTicks = 0;
        orbitTarget = -1;
        wallRoll = 0;
        targetRoll = 0;
    }

    public static void tick(LocalPlayer p) {
        displaySpeed = Math.hypot(p.getX() - p.xo, p.getZ() - p.zo);
        targetRoll = 0f;
        waterRunning = false;
        wallRunning = false;
        climbing = false;
        Input in = p.input;
        boolean jumpPressed = in.jumping && !prevJump;
        prevJump = in.jumping;

        SpeedData d = p.getData(ModAttachments.SPEED);
        if (!d.isPowered() || p.isPassenger() || p.getAbilities().flying || p.isFallFlying() || p.isSpectator()
                || p.isSleeping() || !p.isAlive()) {
            speed = 0;
            dashTicks = 0;
            massDashTicks = 0;
            settleRoll();
            return;
        }

        double max = SpeedMath.maxSpeedBT(p, d);
        if (!p.getAbilities().instabuild && d.v9Ticks <= 0 && p.getFoodData().getFoodLevel() <= 6) {
            max = Math.min(max, SpeedMath.levelMaxBT(1));
        }
        double dy = p.getDeltaMovement().y;

        if (d.tornado) {
            Entity target = orbitTarget >= 0 ? p.level().getEntity(orbitTarget) : null;
            if (target != null && target.isAlive() && target.distanceTo(p) < 20) {
                orbit(p, target, max, dy);
            } else {
                speed = 0;
                p.setDeltaMovement(0, dy, 0);
            }
            settleRoll();
            return;
        }

        boolean runKey = Minecraft.getInstance().options.keySprint.isDown() || p.isSprinting();
        boolean runInput = in.forwardImpulse > 0.01f && runKey;

        if (massDashTicks > 0) {
            massDashTicks--;
            dir = horizontalLook(p);
            speed = Math.max(max * 1.5, 1.5);
        } else if (dashTicks > 0) {
            dashTicks--;
        } else if (runInput) {
            Vec3 wish = wishDir(p, in.forwardImpulse, in.leftImpulse);
            if (speed < 0.3) {
                dir = wish;
            } else {
                double turn = Mth.clamp(0.9 / (1.0 + speed * 0.55), 0.08, 0.9) * SpeedMath.control(p, d);
                dir = dir.lerp(wish, Math.min(1.0, turn)).normalize();
                if (dir.lengthSqr() < 1e-6) dir = wish;
            }
            double start = Math.min(max, Math.max(speed, 0.28));
            if (start < max) {
                speed = Math.min(max, start + SpeedMath.accel(p, d) * (1.0 + start * 0.35));
            } else {
                speed = Math.max(max, start * 0.96);
            }
        } else {
            speed *= in.shiftKeyDown ? 0.7 : 0.86;
            if (speed < 0.25) speed = 0;
        }

        if (d.phasing) {
            double vy = in.jumping ? 0.32 : (in.shiftKeyDown ? -0.32 : 0.0);
            p.fallDistance = 0;
            if (speed <= 0) {
                Vec3 dm = p.getDeltaMovement();
                p.setDeltaMovement(dm.x, vy, dm.z);
                settleRoll();
                return;
            }
            dy = vy;
        } else {
            if (speed <= 0) {
                settleRoll();
                return;
            }
            if (d.level >= Config.WATER_RUN_LEVEL.get() && speed >= 0.6) dy = waterRun(p, dy);
            if (d.level >= Config.WALL_RUN_LEVEL.get() && speed >= 0.8) dy = wallRun(p, dy, runInput, jumpPressed);
        }

        p.setDeltaMovement(dir.x * speed, dy, dir.z * speed);

        if (!d.phasing && !climbing && p.horizontalCollision && speed > 1.2) {
            if (speed > 2.0) PacketDistributor.sendToServer(new AbilityPayload(Ability.IMPACT, (int) (speed * 100)));
            ClientFx.addShake((float) Math.min(6.0, speed));
            speed *= 0.1;
            massDashTicks = 0;
            dashTicks = 0;
        }
        settleRoll();
    }

    public static void dash(LocalPlayer p) {
        SpeedData d = p.getData(ModAttachments.SPEED);
        double max = SpeedMath.maxSpeedBT(p, d);
        Input in = p.input;
        boolean moving = Math.abs(in.forwardImpulse) > 0.01f || Math.abs(in.leftImpulse) > 0.01f;
        Vec3 wish = moving ? wishDir(p, in.forwardImpulse, in.leftImpulse) : horizontalLook(p);
        dir = speed < 0.3 ? wish : dir.lerp(wish, 0.6).normalize();
        if (dir.lengthSqr() < 1e-6) dir = wish;
        speed = Math.max(speed, max * 1.1 + 0.6);
        dashTicks = 6;
    }

    public static void startMassDash(LocalPlayer p) {
        dir = horizontalLook(p);
        massDashTicks = 14;
    }

    static Vec3 horizontalLook(LocalPlayer p) {
        float yaw = p.getYRot() * Mth.DEG_TO_RAD;
        return new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw));
    }

    private static Vec3 wishDir(LocalPlayer p, float forward, float strafe) {
        float yaw = p.getYRot() * Mth.DEG_TO_RAD;
        double sin = Mth.sin(yaw);
        double cos = Mth.cos(yaw);
        Vec3 v = new Vec3(strafe * cos - forward * sin, 0, forward * cos + strafe * sin);
        return v.lengthSqr() < 1e-6 ? horizontalLook(p) : v.normalize();
    }

    private static double waterRun(LocalPlayer p, double dy) {
        BlockPos below = BlockPos.containing(p.getX(), p.getY() - 0.05, p.getZ());
        BlockPos under2 = BlockPos.containing(p.getX(), p.getY() - 0.6, p.getZ());
        boolean waterBelow = p.level().getFluidState(below).is(FluidTags.WATER) || p.level().getFluidState(under2).is(FluidTags.WATER);
        if (!waterBelow || p.isUnderWater()) return dy;
        waterRunning = true;
        p.fallDistance = 0;
        double surface = below.getY() + p.level().getFluidState(below).getHeight(p.level(), below);
        if (!p.level().getFluidState(below).is(FluidTags.WATER)) surface = under2.getY() + 0.9;
        if (p.getY() < surface) return Math.min(0.3, (surface - p.getY()) * 0.6 + 0.05);
        return p.input.jumping ? dy : Math.max(dy, 0.0);
    }

    private static double wallRun(LocalPlayer p, double dy, boolean runInput, boolean jumpPressed) {
        if (!runInput) return dy;
        Vec3 bump = dir.scale(0.4);
        boolean front = !p.level().noCollision(p, p.getBoundingBox().move(bump.x, 0, bump.z).deflate(0.02, 0.1, 0.02));
        if (front && p.horizontalCollision) {
            climbing = true;
            wallRunning = true;
            p.fallDistance = 0;
            return Math.min(0.9, 0.35 + speed * 0.08);
        }
        Vec3 right = new Vec3(-dir.z, 0, dir.x);
        for (int sign = -1; sign <= 1; sign += 2) {
            Vec3 side = right.scale(0.45 * sign);
            if (!p.onGround() && !p.level().noCollision(p, p.getBoundingBox().move(side.x, 0, side.z).deflate(0.02, 0.1, 0.02))) {
                wallRunning = true;
                p.fallDistance = 0;
                targetRoll = sign * 12f;
                if (jumpPressed) {
                    Vec3 push = right.scale(-sign * 0.6);
                    dir = dir.add(push.scale(0.5)).normalize();
                    return 0.55;
                }
                return Math.max(dy, -0.02);
            }
        }
        return dy;
    }

    private static void orbit(LocalPlayer p, Entity t, double max, double dy) {
        Vec3 r = new Vec3(p.getX() - t.getX(), 0, p.getZ() - t.getZ());
        double len = r.length();
        if (len < 0.1) {
            r = new Vec3(1, 0, 0);
            len = 1;
        }
        Vec3 n = r.scale(1 / len);
        Vec3 tan = new Vec3(-n.z, 0, n.x);
        double v = Mth.clamp(max, 0.8, 1.6);
        Vec3 vel = tan.scale(v).add(n.scale((3.5 - len) * 0.4));
        p.setDeltaMovement(vel.x, dy, vel.z);
        speed = v;
        dir = tan;
    }

    private static void settleRoll() {
        wallRoll += (targetRoll - wallRoll) * 0.2f;
        if (Math.abs(wallRoll) < 0.01f) wallRoll = 0f;
    }
}
