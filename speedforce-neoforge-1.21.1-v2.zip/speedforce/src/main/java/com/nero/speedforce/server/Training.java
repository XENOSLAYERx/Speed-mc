package com.nero.speedforce.server;

import com.nero.speedforce.data.SpeedData;
import com.nero.speedforce.registry.ModAttachments;
import com.nero.speedforce.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;

/** Six drills, each teaching one core power. Not a grind: finish once, get residue. */
public final class Training {
    public static final int REACH_100 = 0;
    public static final int LIGHTNING = 1;
    public static final int PHASE_WALL = 2;
    public static final int WATER_RUN = 3;
    public static final int PERCEPTION_DODGE = 4;
    public static final int SUPERSONIC = 5;
    private static final int COUNT = 6;

    private static final String[] NAMES = {
            "Reach 100 m/s (sprint at speed level 6+)",
            "Hit a mob with a lightning throw [R]",
            "Phase through a solid wall [Z]",
            "Run across water for 3 seconds (level 6+)",
            "Let a projectile pass through you during Speed Perception [C]",
            "Land a supersonic punch while running"
    };

    private Training() {}

    public static void useDevice(ServerPlayer p) {
        SpeedData d = p.getData(ModAttachments.SPEED);
        if (!d.hasPower && d.v9Ticks <= 0) {
            p.displayClientMessage(Component.translatable("message.speedforce.needs_speedster").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        if (p.isShiftKeyDown() && d.trainingActive) {
            d.trainingActive = false;
            d.markDirty();
            p.sendSystemMessage(Component.literal("Training paused.").withStyle(ChatFormatting.GRAY));
            return;
        }
        if (!d.trainingActive) {
            d.trainingActive = true;
            d.markDirty();
            p.sendSystemMessage(Component.literal("\u26A1 SPEED FORCE TRAINING").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
        }
        for (int i = 0; i < COUNT; i++) {
            boolean done = (d.trainingMask & (1 << i)) != 0;
            p.sendSystemMessage(Component.literal((done ? " \u2713 " : " \u2717 ") + NAMES[i])
                    .withStyle(done ? ChatFormatting.GREEN : ChatFormatting.GRAY));
        }
    }

    public static void complete(ServerPlayer p, SpeedData d, int drill) {
        if (!d.trainingActive || (d.trainingMask & (1 << drill)) != 0) return;
        d.trainingMask |= 1 << drill;
        d.markDirty();
        int done = Integer.bitCount(d.trainingMask & ((1 << COUNT) - 1));
        p.sendSystemMessage(Component.literal("\u2713 Drill complete: " + NAMES[drill] + " (" + done + "/" + COUNT + ")")
                .withStyle(ChatFormatting.GREEN));
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.7f, 1.4f);
        if (done >= COUNT) {
            d.trainingActive = false;
            ItemStack reward = new ItemStack(ModItems.SPEED_FORCE_RESIDUE.get(), 8);
            if (!p.getInventory().add(reward)) p.drop(reward, false);
            p.sendSystemMessage(Component.literal("\u26A1 Training complete. You are ready.").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
        }
    }
}
