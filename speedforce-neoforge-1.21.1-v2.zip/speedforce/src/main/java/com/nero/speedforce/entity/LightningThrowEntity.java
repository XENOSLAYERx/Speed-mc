package com.nero.speedforce.entity;

import com.nero.speedforce.data.SpeedData;
import com.nero.speedforce.data.SpeedMath;
import com.nero.speedforce.registry.ModAttachments;
import com.nero.speedforce.registry.ModEntities;
import com.nero.speedforce.server.ServerFx;
import com.nero.speedforce.server.Training;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** Speed Force lightning pulled from the body and hurled. Rendered entirely with particles. */
public class LightningThrowEntity extends ThrowableProjectile {
    private static final EntityDataAccessor<Integer> DATA_COLOR = SynchedEntityData.defineId(LightningThrowEntity.class, EntityDataSerializers.INT);

    private float damage = 6f;
    private float aoe = 2f;
    private int life;
    private Entity directHit;

    public LightningThrowEntity(EntityType<? extends LightningThrowEntity> type, Level level) {
        super(type, level);
    }

    public LightningThrowEntity(Level level, LivingEntity owner, int color, float damage, float aoe) {
        super(ModEntities.LIGHTNING_THROW.get(), owner, level);
        this.entityData.set(DATA_COLOR, color);
        this.damage = damage;
        this.aoe = aoe;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_COLOR, 0xFFD21F);
    }

    public int getColor() {
        return entityData.get(DATA_COLOR);
    }

    @Override
    protected double getDefaultGravity() {
        return 0.0;
    }

    @Override
    public void tick() {
        Vec3 before = position();
        super.tick();
        if (level().isClientSide) {
            trail(before, position());
        } else if (++life > 60) {
            discard();
        }
    }

    private void trail(Vec3 from, Vec3 to) {
        RandomSource r = random;
        float[] c = SpeedMath.rgb(getColor());
        DustParticleOptions core = new DustParticleOptions(new Vector3f(c[0], c[1], c[2]), 0.9f);
        DustParticleOptions glow = new DustParticleOptions(new Vector3f(1f, 1f, 1f), 0.5f);
        Vec3 prev = from;
        int segments = 5;
        for (int s = 1; s <= segments; s++) {
            Vec3 next = from.lerp(to, s / (double) segments).add((r.nextDouble() - 0.5) * 0.35, (r.nextDouble() - 0.5) * 0.35, (r.nextDouble() - 0.5) * 0.35);
            for (int i = 0; i < 4; i++) {
                Vec3 q = prev.lerp(next, i / 4.0);
                level().addParticle(core, q.x, q.y, q.z, 0, 0, 0);
            }
            prev = next;
        }
        level().addParticle(glow, to.x, to.y, to.z, 0, 0, 0);
        if (r.nextInt(2) == 0) level().addParticle(ParticleTypes.ELECTRIC_SPARK, to.x, to.y, to.z, 0, 0, 0);
    }

    @Override
    protected boolean canHitEntity(Entity target) {
        Entity owner = getOwner();
        if (owner != null && (target == owner || target.isAlliedTo(owner))) return false;
        return super.canHitEntity(target);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (level().isClientSide) return;
        Entity target = result.getEntity();
        directHit = target;
        if (target instanceof LivingEntity living) {
            living.hurt(damageSources().thrown(this, getOwner()), damage);
            living.igniteForSeconds(3);
            Vec3 push = getDeltaMovement().normalize();
            living.knockback(0.8, -push.x, -push.z);
            if (getOwner() instanceof ServerPlayer sp) Training.complete(sp, sp.getData(ModAttachments.SPEED), Training.LIGHTNING);
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (level() instanceof ServerLevel serverLevel) {
            impact(serverLevel, result.getLocation());
            discard();
        }
    }

    private void impact(ServerLevel level, Vec3 at) {
        int color = getColor();
        ServerFx.burst(level, at, color, 30);
        level.sendParticles(ParticleTypes.FLASH, at.x, at.y, at.z, 1, 0, 0, 0, 0);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 1.2f, 1.4f);
        Entity owner = getOwner();
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(aoe),
                e -> e != owner && e != directHit && e.isAlive() && (owner == null || !e.isAlliedTo(owner)))) {
            if (e.distanceToSqr(at) > aoe * aoe) continue;
            e.hurt(damageSources().thrown(this, owner), damage * 0.5f);
            ServerFx.arc(level, at, e.position().add(0, e.getBbHeight() * 0.5, 0), color);
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putFloat("Damage", damage);
        tag.putFloat("Aoe", aoe);
        tag.putInt("Color", getColor());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        damage = tag.getFloat("Damage");
        aoe = tag.getFloat("Aoe");
        entityData.set(DATA_COLOR, tag.getInt("Color"));
    }

    /** Helper for speedster players. */
    public static LightningThrowEntity fromPlayer(ServerPlayer p, SpeedData d, float damage, float aoe) {
        return new LightningThrowEntity(p.level(), p, SpeedMath.lightningColor(p, d), damage, aoe);
    }
}
