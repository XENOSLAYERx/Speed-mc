package com.nero.speedforce;

import com.mojang.logging.LogUtils;
import com.nero.speedforce.network.ModNetwork;
import com.nero.speedforce.registry.ModArmorMaterials;
import com.nero.speedforce.registry.ModAttachments;
import com.nero.speedforce.registry.ModBlockEntities;
import com.nero.speedforce.registry.ModBlocks;
import com.nero.speedforce.registry.ModEntities;
import com.nero.speedforce.registry.ModItems;
import com.nero.speedforce.registry.ModTabs;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import org.slf4j.Logger;

@Mod(SpeedForceMod.MODID)
public class SpeedForceMod {
    public static final String MODID = "speedforce";
    public static final Logger LOGGER = LogUtils.getLogger();

    public SpeedForceMod(IEventBus modBus, ModContainer container) {
        ModArmorMaterials.ARMOR_MATERIALS.register(modBus);
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModAttachments.ATTACHMENT_TYPES.register(modBus);
        ModTabs.TABS.register(modBus);

        modBus.addListener(ModNetwork::register);
        modBus.addListener(ModEntities::registerAttributes);

        container.registerConfig(ModConfig.Type.COMMON, Config.SPEC);
    }

    public static ResourceLocation rl(String path) {
        return ResourceLocation.fromNamespaceAndPath(MODID, path);
    }
}
