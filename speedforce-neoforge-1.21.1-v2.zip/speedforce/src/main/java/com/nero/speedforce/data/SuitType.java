package com.nero.speedforce.data;

import com.nero.speedforce.item.SuitArmorItem;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

import javax.annotation.Nullable;

/** Every suit has its own stats, lightning and ability, not just a texture. */
public enum SuitType {
    //            id               lightning  maxMult accel control dmg  collRes force                     ability               defense {head,chest,legs,feet}  toughness
    FLASH        ("flash",         0xFFD21F, 1.00, 1.00, 1.00, 0.0f, 0.5f, null,                     "Lightning Barrage", new int[]{3, 7, 6, 3}, 1.0f),
    WALLY_WEST   ("wally_west",    0xFFB01F, 1.15, 1.20, 1.05, 0.0f, 0.5f, null,                     "Overdrive",         new int[]{3, 7, 6, 3}, 1.0f),
    JAY_GARRICK  ("jay_garrick",   0xFFE070, 0.85, 0.95, 1.00, 2.0f, 0.7f, null,                     "Iron Will",         new int[]{4, 8, 7, 4}, 2.0f),
    KID_FLASH    ("kid_flash",     0xFFF06A, 0.90, 1.40, 1.35, 0.0f, 0.4f, null,                     "Blitz",             new int[]{2, 6, 5, 2}, 0.0f),
    REVERSE_FLASH("reverse_flash", 0xFF2A2A, 1.05, 1.15, 1.00, 1.0f, 0.5f, SpeedForceType.NEGATIVE,  "Negative Surge",    new int[]{3, 7, 6, 3}, 1.0f),
    ZOOM         ("zoom",          0x3AA0FF, 1.10, 1.10, 0.95, 1.5f, 0.6f, null,                     "Time Freeze",       new int[]{3, 8, 6, 3}, 2.0f),
    GODSPEED     ("godspeed",      0xF4F8FF, 1.20, 1.15, 1.10, 1.0f, 0.6f, null,                     "Speed Clones",      new int[]{3, 7, 6, 3}, 2.0f),
    SAVITAR      ("savitar",       0xB8E8FF, 0.90, 0.90, 0.85, 3.0f, 0.9f, null,                     "Armored Charge",    new int[]{5, 10, 8, 5}, 4.0f),
    IMPULSE      ("impulse",       0xFF8A1F, 0.95, 1.55, 1.20, 0.0f, 0.3f, null,                     "Reckless Rush",     new int[]{2, 6, 5, 2}, 0.0f),
    MAX_MERCURY  ("max_mercury",   0xD6D6FF, 1.05, 1.00, 1.45, 1.0f, 0.8f, null,                     "Zen Focus",         new int[]{3, 8, 6, 3}, 2.0f),
    JESSE_QUICK  ("jesse_quick",   0x5AC8FF, 1.10, 1.25, 1.15, 0.0f, 0.5f, null,                     "Velocity Burst",    new int[]{3, 7, 6, 3}, 1.0f),
    INERTIA      ("inertia",       0x7A3AFF, 1.15, 1.10, 1.00, 2.0f, 0.6f, null,                     "Momentum Drain",    new int[]{4, 8, 7, 4}, 2.0f);

    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    public final String id;
    public final int lightning;
    public final double maxMult;
    public final double accel;
    public final double control;
    public final float bonusDamage;
    public final float collisionResist;
    @Nullable public final SpeedForceType forceOverride;
    public final String abilityName;
    public final int[] defense;
    public final float toughness;

    SuitType(String id, int lightning, double maxMult, double accel, double control, float bonusDamage, float collisionResist,
             @Nullable SpeedForceType forceOverride, String abilityName, int[] defense, float toughness) {
        this.id = id;
        this.lightning = lightning;
        this.maxMult = maxMult;
        this.accel = accel;
        this.control = control;
        this.bonusDamage = bonusDamage;
        this.collisionResist = collisionResist;
        this.forceOverride = forceOverride;
        this.abilityName = abilityName;
        this.defense = defense;
        this.toughness = toughness;
    }

    public Component displayName() {
        return Component.translatable("suit.speedforce." + id);
    }

    /** The suit the player is wearing as a complete set, or null. */
    @Nullable
    public static SuitType worn(Player player) {
        SuitType found = null;
        for (EquipmentSlot slot : SLOTS) {
            ItemStack stack = player.getItemBySlot(slot);
            if (!(stack.getItem() instanceof SuitArmorItem armor)) return null;
            if (found == null) found = armor.suit;
            else if (found != armor.suit) return null;
        }
        return found;
    }

    @Nullable
    public static SuitType byId(String id) {
        for (SuitType s : values()) if (s.id.equalsIgnoreCase(id)) return s;
        return null;
    }
}
