package com.nero.speedforce.item;

import com.nero.speedforce.registry.ModItems;
import com.nero.speedforce.server.ServerEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;

import java.util.List;

/** Raise it to the sky during a thunderstorm to capture a bolt of lightning. */
public class EmptyVialItem extends Item {
    public EmptyVialItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isThundering() || !level.canSeeSky(player.blockPosition().above())) {
            if (!level.isClientSide) {
                player.displayClientMessage(Component.translatable("message.speedforce.vial_needs_storm").withStyle(ChatFormatting.GRAY), true);
            }
            return InteractionResultHolder.fail(stack);
        }
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public int getUseDuration(ItemStack stack, LivingEntity entity) {
        return 60;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.BOW;
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remaining) {
        if (level.isClientSide && remaining % 3 == 0) {
            level.addParticle(ParticleTypes.ELECTRIC_SPARK, entity.getX(), entity.getEyeY() + 0.6, entity.getZ(),
                    (level.random.nextDouble() - 0.5) * 0.4, 0.2, (level.random.nextDouble() - 0.5) * 0.4);
        }
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (!(level instanceof ServerLevel serverLevel) || !(entity instanceof Player player) || !level.isThundering()) {
            return stack;
        }
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(serverLevel);
        if (bolt != null) {
            bolt.moveTo(player.getX() + 1.5, player.getY(), player.getZ() + 0.5);
            bolt.setVisualOnly(true);
            bolt.addTag(ServerEvents.NO_FILL_TAG);
            serverLevel.addFreshEntity(bolt);
        }
        player.displayClientMessage(Component.translatable("message.speedforce.vial_filled").withStyle(ChatFormatting.YELLOW), true);

        ItemStack filled = new ItemStack(ModItems.DARK_MATTER_VIAL.get());
        if (!player.getAbilities().instabuild) stack.shrink(1);
        if (stack.isEmpty()) return filled;
        if (!player.getInventory().add(filled)) player.drop(filled, false);
        return stack;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.speedforce.empty_dark_matter_vial").withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
        tooltip.add(Component.translatable("tooltip.speedforce.empty_dark_matter_vial.use").withStyle(ChatFormatting.DARK_AQUA));
    }
}
