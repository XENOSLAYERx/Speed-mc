package com.nero.speedforce.server;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Race gates in a level and per-course leaderboards. */
public class RaceData extends SavedData {
    public record Entry(String name, int ticks) {}

    public final Map<BlockPos, Integer> gates = new HashMap<>();
    public final Map<Long, List<Entry>> boards = new HashMap<>();

    public static RaceData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(new SavedData.Factory<>(RaceData::new, RaceData::load, null), "speedforce_races");
    }

    public static RaceData load(CompoundTag tag, HolderLookup.Provider registries) {
        RaceData data = new RaceData();
        ListTag gates = tag.getList("Gates", Tag.TAG_COMPOUND);
        for (int i = 0; i < gates.size(); i++) {
            CompoundTag g = gates.getCompound(i);
            data.gates.put(BlockPos.of(g.getLong("Pos")), g.getInt("Index"));
        }
        ListTag boards = tag.getList("Boards", Tag.TAG_COMPOUND);
        for (int i = 0; i < boards.size(); i++) {
            CompoundTag b = boards.getCompound(i);
            List<Entry> entries = new ArrayList<>();
            ListTag list = b.getList("Entries", Tag.TAG_COMPOUND);
            for (int j = 0; j < list.size(); j++) {
                CompoundTag e = list.getCompound(j);
                entries.add(new Entry(e.getString("Name"), e.getInt("Ticks")));
            }
            data.boards.put(b.getLong("Origin"), entries);
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        ListTag gateList = new ListTag();
        gates.forEach((pos, idx) -> {
            CompoundTag g = new CompoundTag();
            g.putLong("Pos", pos.asLong());
            g.putInt("Index", idx);
            gateList.add(g);
        });
        tag.put("Gates", gateList);
        ListTag boardList = new ListTag();
        boards.forEach((origin, entries) -> {
            CompoundTag b = new CompoundTag();
            b.putLong("Origin", origin);
            ListTag list = new ListTag();
            for (Entry e : entries) {
                CompoundTag et = new CompoundTag();
                et.putString("Name", e.name());
                et.putInt("Ticks", e.ticks());
                list.add(et);
            }
            b.put("Entries", list);
            boardList.add(b);
        });
        tag.put("Boards", boardList);
        return tag;
    }

    public int maxIndexNear(BlockPos origin) {
        int max = 0;
        for (Map.Entry<BlockPos, Integer> e : gates.entrySet()) {
            if (e.getKey().distSqr(origin) <= 1024 * 1024) max = Math.max(max, e.getValue());
        }
        return max;
    }
}
