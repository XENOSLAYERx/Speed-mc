package com.nero.speedforce.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.nero.speedforce.SpeedForceMod;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.VexRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.Vex;

/** Time Wraiths reuse the vex model at double size with their own ghostly skin. */
public class TimeWraithRenderer extends VexRenderer {
    private static final ResourceLocation TEXTURE = SpeedForceMod.rl("textures/entity/time_wraith.png");

    public TimeWraithRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.6f;
    }

    @Override
    public ResourceLocation getTextureLocation(Vex entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(Vex entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(2.0f, 2.0f, 2.0f);
    }
}
