package com.nero.speedforce.server;

import com.nero.speedforce.data.SpeedData;
import com.nero.speedforce.data.SpeedForceType;
import com.nero.speedforce.network.FxPayload;
import com.nero.speedforce.registry.ModAttachments;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

/** The "BOOM, you're a speedster" moment. */
public final class SpeedForceOrigin {
    private SpeedForceOrigin() {}

    public static void grant(ServerPlayer p, SpeedForceType type) {
        SpeedData d = p.getData(ModAttachments.SPEED);
        boolean first = !d.hasPower;
        d.hasPower = true;
        d.type = type;
        d.enabled = true;
        d.energy = 100f;
        if (first) d.level = Math.max(d.level, 1);
        d.markDirty();

        ServerLevel level = p.serverLevel();
        Vec3 flatLook = p.getLookAngle().multiply(1, 0, 1);
        if (flatLook.lengthSqr() < 1e-4) flatLook = new Vec3(0, 0, 1);
        Vec3 behind = p.position().subtract(flatLook.normalize().scale(2.0));
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {
            bolt.moveTo(behind.x, p.getY(), behind.z);
            bolt.setVisualOnly(true);
            bolt.addTag(ServerEvents.NO_FILL_TAG);
            level.addFreshEntity(bolt);
        }
        int color = type.color;
        ServerFx.burst(level, p.position().add(0, 1, 0), color, 90);
        ServerFx.ring(level, p.position().add(0, 0.1, 0), 2.5, color, 48);
        level.sendParticles(ParticleTypes.FLASH, p.getX(), p.getY() + 1, p.getZ(), 1, 0, 0, 0, 0);
        level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 2.0f, 1.0f);
        level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.0f, 1.5f);

        PacketDistributor.sendToPlayer(p, new FxPayload(FxPayload.ACTIVATE, p.getId(), type.ordinal()));
        String key = type == SpeedForceType.NEGATIVE ? "message.speedforce.origin_negative" : "message.speedforce.origin";
        p.sendSystemMessage(Component.translatable(key).withStyle(type == SpeedForceType.NEGATIVE ? ChatFormatting.RED : ChatFormatting.GOLD));
        if (first) p.sendSystemMessage(Component.translatable("message.speedforce.origin_help").withStyle(ChatFormatting.GRAY));
        SpeedSync.sync(p, d, true);
        d.dirty = false;
    }

    public static void revoke(ServerPlayer p) {
        SpeedData d = p.getData(ModAttachments.SPEED);
        d.hasPower = false;
        d.type = SpeedForceType.NONE;
        d.v9Ticks = 0;
        d.clearActiveStates();
        d.markDirty();
    }
}
