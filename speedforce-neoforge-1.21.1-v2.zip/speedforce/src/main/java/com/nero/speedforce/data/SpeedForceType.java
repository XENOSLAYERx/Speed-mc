package com.nero.speedforce.data;

import java.util.Locale;

public enum SpeedForceType {
    NONE(0xFFD21F, 1.0f, 1.0f),
    SPEED(0xFFD21F, 1.0f, 1.0f),
    NEGATIVE(0xFF2424, 1.3f, 1.25f),
    V9(0x3D7BFF, 1.1f, 1.2f);

    public final int color;
    public final float damageMult;
    public final float accelMult;

    SpeedForceType(int color, float damageMult, float accelMult) {
        this.color = color;
        this.damageMult = damageMult;
        this.accelMult = accelMult;
    }

    public String id() {
        return name().toLowerCase(Locale.ROOT);
    }

    public static SpeedForceType byName(String name) {
        for (SpeedForceType t : values()) {
            if (t.id().equalsIgnoreCase(name)) return t;
        }
        return NONE;
    }
}
