package com.nero.speedforce.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/** Plain item with a lore line and optional enchantment glint. */
public class TooltipItem extends Item {
    private final String key;
    private final boolean foil;

    public TooltipItem(Properties properties, String key, boolean foil) {
        super(properties);
        this.key = key;
        this.foil = foil;
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return foil || super.isFoil(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.speedforce." + key).withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
    }
}
