package com.nero.speedforce.client;

import com.nero.speedforce.SpeedForceMod;
import com.nero.speedforce.data.SpeedData;
import com.nero.speedforce.registry.ModAttachments;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.player.LocalPlayer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.ComputeFovModifierEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.RenderBlockScreenEffectEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

import java.util.concurrent.ThreadLocalRandom;

@EventBusSubscriber(modid = SpeedForceMod.MODID, value = Dist.CLIENT)
public final class ClientGameEvents {
    private ClientGameEvents() {}

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        ClientInput.tick();
        ClientFx.tick();
    }

    /** Runs after vanilla movement each tick, before the position is sent to the server. */
    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (event.getEntity() instanceof LocalPlayer lp && lp == Minecraft.getInstance().player) {
            SpeedController.tick(lp);
        }
    }

    @SubscribeEvent
    public static void onFov(ComputeFovModifierEvent event) {
        if (event.getPlayer() != Minecraft.getInstance().player || Math.abs(ClientFx.fovFactor - 1f) < 0.001f) return;
        double effect = Minecraft.getInstance().options.fovEffectScale().get();
        float factor = 1f + (ClientFx.fovFactor - 1f) * (float) effect;
        event.setNewFovModifier(event.getNewFovModifier() * factor);
    }

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles event) {
        float s = ClientFx.shake;
        if (s > 0 && ClientConfig.CAMERA_SHAKE.get()) {
            ThreadLocalRandom r = ThreadLocalRandom.current();
            event.setYaw(event.getYaw() + (r.nextFloat() - 0.5f) * s * 0.6f);
            event.setPitch(event.getPitch() + (r.nextFloat() - 0.5f) * s * 0.6f);
            event.setRoll(event.getRoll() + (r.nextFloat() - 0.5f) * s * 0.4f);
        }
        if (ClientConfig.WALL_RUN_TILT.get() && Math.abs(SpeedController.wallRoll) > 0.05f) {
            event.setRoll(event.getRoll() + SpeedController.wallRoll);
        }
    }

    /** Alt + mouse wheel changes speed level (instead of the hotbar slot). */
    @SubscribeEvent
    public static void onScroll(InputEvent.MouseScrollingEvent event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen != null || mc.player == null || !Screen.hasAltDown()) return;
        SpeedData d = mc.player.getData(ModAttachments.SPEED);
        if (!d.isPowered()) return;
        double dy = event.getScrollDeltaY();
        if (dy == 0) return;
        ClientInput.changeLevel(d, dy > 0 ? 1 : -1);
        event.setCanceled(true);
    }

    /** No "inside a block" overlay while phasing through walls. */
    @SubscribeEvent
    public static void onBlockOverlay(RenderBlockScreenEffectEvent event) {
        if (event.getOverlayType() != RenderBlockScreenEffectEvent.OverlayType.BLOCK) return;
        if (event.getPlayer() == Minecraft.getInstance().player && event.getPlayer().getData(ModAttachments.SPEED).phasing) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        SpeedController.reset();
        ClientInput.reset();
        ClientFx.shake = 0;
        ClientFx.flashTicks = 0;
        ClientFx.activationTicks = 0;
        ClientFx.fovFactor = 1f;
    }
}
