package com.nero.speedforce.block;

import com.nero.speedforce.data.SpeedData;
import com.nero.speedforce.data.SpeedForceType;
import com.nero.speedforce.registry.ModAttachments;
import com.nero.speedforce.registry.ModBlockEntities;
import com.nero.speedforce.server.ServerEvents;
import com.nero.speedforce.server.ServerFx;
import com.nero.speedforce.server.SpeedForceOrigin;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Runs the 9-second Speed Force Storm sequence. */
public class AcceleratorBlockEntity extends BlockEntity {
    private static final int DURATION = 180;
    private int timer = -1;

    public AcceleratorBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.ACCELERATOR.get(), pos, state);
    }

    public boolean isRunning() {
        return timer >= 0;
    }

    public void start() {
        timer = 0;
        setChanged();
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, AcceleratorBlockEntity be) {
        if (level instanceof ServerLevel serverLevel) be.tick(serverLevel, pos, state);
    }

    private void tick(ServerLevel level, BlockPos pos, BlockState state) {
        if (timer < 0) return;
        timer++;
        Vec3 c = Vec3.atCenterOf(pos);

        // spinning energy ring, accelerating
        double spin = timer * (0.05 + timer * 0.0016);
        int points = 4 + timer / 18;
        DustParticleOptions yellow = ServerFx.dust(0xFFD21F, 1.0f);
        for (int i = 0; i < points; i++) {
            double a = spin + i * (Math.PI * 2 / points);
            level.sendParticles(yellow, c.x + Math.cos(a) * 2.3, c.y + 0.6, c.z + Math.sin(a) * 2.3, 1, 0, 0, 0, 0);
        }
        if (timer % 10 == 0) {
            for (int dx = -1; dx <= 1; dx += 2) {
                for (int dz = -1; dz <= 1; dz += 2) {
                    level.sendParticles(DustParticleOptions.REDSTONE, pos.getX() + dx + 0.5, pos.getY() + 1.1, pos.getZ() + dz + 0.5, 6, 0.3, 0.1, 0.3, 0);
                }
            }
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y + 1.2, c.z, 8, 0.8, 0.4, 0.8, 0.2);
        }
        if (timer == 1) {
            level.setBlock(pos, state.setValue(ParticleAcceleratorBlock.POWER, 1), 3);
            level.playSound(null, pos, SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 1.5f, 0.6f);
        }
        if (timer % 20 == 0) {
            level.playSound(null, pos, SoundEvents.BEACON_AMBIENT, SoundSource.BLOCKS, 1.5f, 0.5f + timer / (float) DURATION);
        }
        if (timer == 100) {
            level.setBlock(pos, state.setValue(ParticleAcceleratorBlock.POWER, 2), 3);
        }
        // the localized storm
        if (timer >= 70) {
            level.sendParticles(ParticleTypes.LARGE_SMOKE, c.x, c.y + 9, c.z, 6, 4.0, 0.6, 4.0, 0.01);
            if (timer % Math.max(6, 22 - timer / 10) == 0) {
                double ox = (level.random.nextDouble() - 0.5) * 16;
                double oz = (level.random.nextDouble() - 0.5) * 16;
                strikeVisual(level, c.add(ox, 0, oz));
            }
        }
        if (timer >= DURATION) {
            finish(level, pos, state, c);
        } else if (timer % 20 == 0) {
            setChanged();
        }
    }

    private void finish(ServerLevel level, BlockPos pos, BlockState state, Vec3 c) {
        timer = -1;
        setChanged();
        level.setBlock(pos, state.setValue(ParticleAcceleratorBlock.POWER, 0), 3);
        strikeVisual(level, c.add(0, 1, 0));
        ServerFx.burst(level, c.add(0, 1, 0), 0xFFD21F, 120);
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, c.x, c.y + 1, c.z, 1, 0, 0, 0, 0);
        level.playSound(null, pos, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.BLOCKS, 4.0f, 0.8f);

        AABB field = new AABB(pos).inflate(5.0, 3.0, 5.0);
        for (ServerPlayer player : level.getEntitiesOfClass(ServerPlayer.class, field)) {
            SpeedData d = player.getData(ModAttachments.SPEED);
            if (d.hasPower) {
                d.energy = 100f;
                d.markDirty();
                player.displayClientMessage(Component.translatable("message.speedforce.accelerator_recharge").withStyle(ChatFormatting.YELLOW), true);
            } else {
                SpeedForceOrigin.grant(player, SpeedForceType.SPEED);
            }
        }
    }

    private static void strikeVisual(ServerLevel level, Vec3 at) {
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt == null) return;
        bolt.moveTo(at.x, at.y, at.z);
        bolt.setVisualOnly(true);
        bolt.addTag(ServerEvents.NO_FILL_TAG);
        level.addFreshEntity(bolt);
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Timer", timer);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        timer = tag.contains("Timer") ? tag.getInt("Timer") : -1;
    }
}
