package com.nero.speedforce.network;

import javax.annotation.Nullable;

public enum Ability {
    POWER_TOGGLE, LEVEL_SET, LIGHTNING, BURST, PHASE, ENTITY_PHASE, PERCEPTION, SPEED_STEAL, DASH,
    TORNADO_START, TORNADO_STOP, MASS_PUNCH, TRAVEL, FOREVER, SNAP, SUIT_ABILITY, IMPACT;

    @Nullable
    public static Ability byId(int id) {
        Ability[] v = values();
        return id >= 0 && id < v.length ? v[id] : null;
    }
}
