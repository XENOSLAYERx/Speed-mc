package com.nero.speedforce.block;

import com.nero.speedforce.server.RaceData;
import com.nero.speedforce.server.RaceManager;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Race checkpoint. Index 0 = start/finish line, 1..15 = checkpoints in order.
 * Sneak + use to change the index. Use gate 0 to see its leaderboard.
 */
public class RaceGateBlock extends Block {
    public static final IntegerProperty INDEX = IntegerProperty.create("index", 0, 15);
    private static final VoxelShape SHAPE = Block.box(0, 0, 6, 16, 16, 10);

    public RaceGateBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(INDEX, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(INDEX);
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
        super.onPlace(state, level, pos, oldState, movedByPiston);
        if (level instanceof ServerLevel serverLevel) {
            RaceData data = RaceData.get(serverLevel);
            data.gates.put(pos.immutable(), state.getValue(INDEX));
            data.setDirty();
        }
    }

    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && level instanceof ServerLevel serverLevel) {
            RaceData data = RaceData.get(serverLevel);
            data.gates.remove(pos);
            data.setDirty();
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (player.isShiftKeyDown()) {
            int next = (state.getValue(INDEX) + 1) % 16;
            level.setBlock(pos, state.setValue(INDEX, next), 3);
            player.displayClientMessage(Component.literal(next == 0 ? "Gate set to START / FINISH" : "Gate set to CHECKPOINT " + next)
                    .withStyle(ChatFormatting.YELLOW), true);
        } else if (state.getValue(INDEX) == 0 && level instanceof ServerLevel serverLevel) {
            RaceManager.showLeaderboard(serverLevel, pos, player);
        } else {
            player.displayClientMessage(Component.literal("Checkpoint " + state.getValue(INDEX) + " (sneak + use to change)")
                    .withStyle(ChatFormatting.GRAY), true);
        }
        return InteractionResult.CONSUME;
    }
}
