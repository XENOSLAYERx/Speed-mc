package com.nero.speedforce.registry;

import com.nero.speedforce.SpeedForceMod;
import com.nero.speedforce.data.SuitType;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public final class ModArmorMaterials {
    public static final DeferredRegister<ArmorMaterial> ARMOR_MATERIALS =
            DeferredRegister.create(Registries.ARMOR_MATERIAL, SpeedForceMod.MODID);

    public static final Map<SuitType, DeferredHolder<ArmorMaterial, ArmorMaterial>> SUITS = new EnumMap<>(SuitType.class);

    static {
        for (SuitType suit : SuitType.values()) {
            SUITS.put(suit, ARMOR_MATERIALS.register(suit.id, () -> create(suit)));
        }
    }

    private static ArmorMaterial create(SuitType suit) {
        EnumMap<ArmorItem.Type, Integer> defense = new EnumMap<>(ArmorItem.Type.class);
        defense.put(ArmorItem.Type.HELMET, suit.defense[0]);
        defense.put(ArmorItem.Type.CHESTPLATE, suit.defense[1]);
        defense.put(ArmorItem.Type.LEGGINGS, suit.defense[2]);
        defense.put(ArmorItem.Type.BOOTS, suit.defense[3]);
        defense.put(ArmorItem.Type.BODY, suit.defense[1]);
        return new ArmorMaterial(defense, 15, SoundEvents.ARMOR_EQUIP_LEATHER,
                () -> Ingredient.of(ModItems.SPEED_FORCE_RESIDUE.get()),
                List.of(new ArmorMaterial.Layer(SpeedForceMod.rl(suit.id))),
                suit.toughness, 0.0f);
    }

    private ModArmorMaterials() {}
}
