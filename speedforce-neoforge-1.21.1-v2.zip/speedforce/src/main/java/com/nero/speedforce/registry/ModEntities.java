package com.nero.speedforce.registry;

import com.nero.speedforce.SpeedForceMod;
import com.nero.speedforce.entity.LightningThrowEntity;
import com.nero.speedforce.entity.SpeedsterEntity;
import com.nero.speedforce.entity.TimeWraithEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, SpeedForceMod.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<LightningThrowEntity>> LIGHTNING_THROW = ENTITIES.register("lightning_throw",
            () -> EntityType.Builder.<LightningThrowEntity>of(LightningThrowEntity::new, MobCategory.MISC)
                    .sized(0.35f, 0.35f).clientTrackingRange(8).updateInterval(1).build("lightning_throw"));

    public static final DeferredHolder<EntityType<?>, EntityType<SpeedsterEntity>> REVERSE_FLASH = speedster("reverse_flash", SpeedsterEntity.Variant.REVERSE_FLASH);
    public static final DeferredHolder<EntityType<?>, EntityType<SpeedsterEntity>> ZOOM = speedster("zoom", SpeedsterEntity.Variant.ZOOM);
    public static final DeferredHolder<EntityType<?>, EntityType<SpeedsterEntity>> GODSPEED = speedster("godspeed", SpeedsterEntity.Variant.GODSPEED);
    public static final DeferredHolder<EntityType<?>, EntityType<SpeedsterEntity>> SAVITAR = speedster("savitar", SpeedsterEntity.Variant.SAVITAR);
    public static final DeferredHolder<EntityType<?>, EntityType<SpeedsterEntity>> BLACK_FLASH = speedster("black_flash", SpeedsterEntity.Variant.BLACK_FLASH);
    public static final DeferredHolder<EntityType<?>, EntityType<SpeedsterEntity>> SPEED_CLONE = speedster("speed_clone", SpeedsterEntity.Variant.CLONE);

    public static final DeferredHolder<EntityType<?>, EntityType<TimeWraithEntity>> TIME_WRAITH = ENTITIES.register("time_wraith",
            () -> EntityType.Builder.<TimeWraithEntity>of(TimeWraithEntity::new, MobCategory.MONSTER)
                    .sized(0.8f, 1.6f).fireImmune().clientTrackingRange(10).build("time_wraith"));

    private static DeferredHolder<EntityType<?>, EntityType<SpeedsterEntity>> speedster(String name, SpeedsterEntity.Variant variant) {
        return ENTITIES.register(name, () -> EntityType.Builder.<SpeedsterEntity>of(
                        (type, level) -> new SpeedsterEntity(type, level, variant), MobCategory.MONSTER)
                .sized(0.6f, 1.8f).clientTrackingRange(10).build(name));
    }

    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(REVERSE_FLASH.get(), SpeedsterEntity.attributes(300, 9).build());
        event.put(ZOOM.get(), SpeedsterEntity.attributes(400, 11).build());
        event.put(GODSPEED.get(), SpeedsterEntity.attributes(350, 10).build());
        event.put(SAVITAR.get(), SpeedsterEntity.attributes(500, 13).build());
        event.put(BLACK_FLASH.get(), SpeedsterEntity.attributes(380, 12).build());
        event.put(SPEED_CLONE.get(), SpeedsterEntity.attributes(16, 5).build());
        event.put(TIME_WRAITH.get(), TimeWraithEntity.createWraithAttributes().build());
    }

    private ModEntities() {}
}
