package com.nero.speedforce.data;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.common.util.INBTSerializable;

/** Per-player Speed Force state. Persisted, copied on death and synced to clients. */
public class SpeedData implements INBTSerializable<CompoundTag> {
    // --- persistent ---
    public boolean hasPower;
    public SpeedForceType type = SpeedForceType.NONE;
    public int level = 1;
    public float energy = 100f;
    public boolean enabled = true;
    public int colorOverride = -1;
    public boolean foreverUnlocked;
    public boolean whiteUnlocked;
    public int trainingMask;
    public boolean trainingActive;
    public float residueDistance;
    public float instability;

    // --- active states (synced) ---
    public boolean phasing;
    public boolean perception;
    public boolean foreverActive;
    public boolean tornado;
    public int entityPhaseTicks;
    public int v9Ticks;
    public int stolenTicks;
    public float stolenBonus;
    public int overdriveTicks;
    public int freezeTicks;
    public int armoredTicks;
    public int blitzTicks;
    public int massPunchTicks;
    public float massPunchPower;
    public int vortexTarget = -1;
    public float vortexCharge;
    public long raceStart = -1L;
    public int raceNext;
    public long raceOrigin;

    // --- server-only runtime (never saved) ---
    public double serverSpeed;
    public Vec3 lastPos;
    public ResourceKey<Level> lastDim;
    public boolean dirty;
    public int syncTimer;
    public boolean soundBarrier;
    public int waterRunTicks;
    public int wraithCooldown;
    public long lastGate;
    public long lastGateTime;

    public boolean isPowered() {
        return enabled && (hasPower || v9Ticks > 0);
    }

    public void markDirty() {
        dirty = true;
    }

    public void clearActiveStates() {
        phasing = false;
        perception = false;
        foreverActive = false;
        tornado = false;
        vortexTarget = -1;
        vortexCharge = 0;
        massPunchTicks = 0;
        entityPhaseTicks = 0;
        armoredTicks = 0;
        freezeTicks = 0;
        raceStart = -1L;
    }

    @Override
    public CompoundTag serializeNBT(HolderLookup.Provider provider) {
        CompoundTag t = new CompoundTag();
        t.putBoolean("HasPower", hasPower);
        t.putString("Type", type.id());
        t.putInt("Level", level);
        t.putFloat("Energy", energy);
        t.putBoolean("Enabled", enabled);
        t.putInt("Color", colorOverride);
        t.putBoolean("Forever", foreverUnlocked);
        t.putBoolean("White", whiteUnlocked);
        t.putInt("Training", trainingMask);
        t.putBoolean("TrainingActive", trainingActive);
        t.putFloat("Residue", residueDistance);
        t.putFloat("Instability", instability);

        t.putBoolean("Phasing", phasing);
        t.putBoolean("Perception", perception);
        t.putBoolean("ForeverActive", foreverActive);
        t.putBoolean("Tornado", tornado);
        t.putInt("EntityPhase", entityPhaseTicks);
        t.putInt("V9", v9Ticks);
        t.putInt("Stolen", stolenTicks);
        t.putFloat("StolenBonus", stolenBonus);
        t.putInt("Overdrive", overdriveTicks);
        t.putInt("Freeze", freezeTicks);
        t.putInt("Armored", armoredTicks);
        t.putInt("Blitz", blitzTicks);
        t.putInt("MassPunch", massPunchTicks);
        t.putFloat("MassPunchPower", massPunchPower);
        t.putInt("Vortex", vortexTarget);
        t.putFloat("VortexCharge", vortexCharge);
        t.putLong("RaceStart", raceStart);
        t.putInt("RaceNext", raceNext);
        t.putLong("RaceOrigin", raceOrigin);
        return t;
    }

    @Override
    public void deserializeNBT(HolderLookup.Provider provider, CompoundTag t) {
        hasPower = t.getBoolean("HasPower");
        type = SpeedForceType.byName(t.getString("Type"));
        level = Math.max(1, Math.min(10, t.contains("Level") ? t.getInt("Level") : 1));
        energy = t.contains("Energy") ? t.getFloat("Energy") : 100f;
        enabled = !t.contains("Enabled") || t.getBoolean("Enabled");
        colorOverride = t.contains("Color") ? t.getInt("Color") : -1;
        foreverUnlocked = t.getBoolean("Forever");
        whiteUnlocked = t.getBoolean("White");
        trainingMask = t.getInt("Training");
        trainingActive = t.getBoolean("TrainingActive");
        residueDistance = t.getFloat("Residue");
        instability = t.getFloat("Instability");

        phasing = t.getBoolean("Phasing");
        perception = t.getBoolean("Perception");
        foreverActive = t.getBoolean("ForeverActive");
        tornado = t.getBoolean("Tornado");
        entityPhaseTicks = t.getInt("EntityPhase");
        v9Ticks = t.getInt("V9");
        stolenTicks = t.getInt("Stolen");
        stolenBonus = t.getFloat("StolenBonus");
        overdriveTicks = t.getInt("Overdrive");
        freezeTicks = t.getInt("Freeze");
        armoredTicks = t.getInt("Armored");
        blitzTicks = t.getInt("Blitz");
        massPunchTicks = t.getInt("MassPunch");
        massPunchPower = t.getFloat("MassPunchPower");
        vortexTarget = t.contains("Vortex") ? t.getInt("Vortex") : -1;
        vortexCharge = t.getFloat("VortexCharge");
        raceStart = t.contains("RaceStart") ? t.getLong("RaceStart") : -1L;
        raceNext = t.getInt("RaceNext");
        raceOrigin = t.getLong("RaceOrigin");
    }
}
