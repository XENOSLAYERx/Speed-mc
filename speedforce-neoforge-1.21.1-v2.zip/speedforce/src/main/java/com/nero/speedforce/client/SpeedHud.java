package com.nero.speedforce.client;

import com.nero.speedforce.data.SpeedData;
import com.nero.speedforce.data.SpeedForceType;
import com.nero.speedforce.data.SpeedMath;
import com.nero.speedforce.registry.ModAttachments;
import com.nero.speedforce.server.RaceManager;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;

import java.util.ArrayList;
import java.util.List;

/** Speed Force HUD layer: screen tints, activation title, speedometer panel, charge bars, race timer. */
public final class SpeedHud {
    private static final int PANEL_W = 136;

    private SpeedHud() {}

    public static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.options.hideGui) return;
        SpeedData d = p.getData(ModAttachments.SPEED);
        int w = g.guiWidth();
        int h = g.guiHeight();
        Font font = mc.font;

        if (d.isPowered()) {
            if (d.foreverActive) g.fill(0, 0, w, h, 0x30B8F4FF);
            else if (d.freezeTicks > 0) g.fill(0, 0, w, h, 0x283060FF);
            else if (d.perception) g.fill(0, 0, w, h, 0x20304AFF);
            if (d.phasing) g.fill(0, 0, w, h, 0x1422E0FF);
            if (d.v9Ticks > 0 && d.v9Ticks < 200 && (p.tickCount / 4) % 2 == 0) g.fill(0, 0, w, h, 0x18FF2020);
        }
        if (ClientFx.flashTicks > 0) {
            int alpha = (int) (200 * ClientFx.flashTicks / (float) ClientFx.flashMax);
            g.fill(0, 0, w, h, (alpha << 24) | 0xFFFFFF);
        }
        if (ClientFx.activationTicks > 0) activation(g, font, w, h);
        if (!d.isPowered()) return;

        if (ClientConfig.HUD_ENABLED.get() && (!ClientConfig.HUD_AUTO_HIDE.get() || ClientFx.hudTicks > 0)) panel(g, font, p, d);
        charges(g, font, w, h, p, d);
        race(g, font, w, p, d, delta);
    }

    private static void activation(GuiGraphics g, Font font, int w, int h) {
        float t = ClientFx.activationTicks / (float) ClientFx.ACTIVATION_LENGTH;
        float alpha = t > 0.85f ? (1f - t) / 0.15f : Math.min(1f, t / 0.3f);
        int a = (int) (Math.max(0f, Math.min(1f, alpha)) * 255);
        if (a < 8) return;
        String title = "\u26A1 " + ClientFx.activationTitle + " \u26A1";
        g.pose().pushPose();
        g.pose().translate(w / 2f, h / 2f - 40, 0);
        g.pose().scale(2.5f, 2.5f, 1f);
        g.drawString(font, title, -font.width(title) / 2, 0, (a << 24) | (ClientFx.activationColor & 0xFFFFFF), true);
        g.pose().popPose();
        String sub = "Sprint to run \u2022 Alt+Scroll speed level \u2022 R lightning \u2022 Z phase \u2022 C perception";
        g.drawString(font, sub, (w - font.width(sub)) / 2, h / 2 - 8, (a << 24) | 0xDDDDDD, true);
    }

    private static void panel(GuiGraphics g, Font font, LocalPlayer p, SpeedData d) {
        float fade = ClientConfig.HUD_AUTO_HIDE.get() ? Math.min(1f, ClientFx.hudTicks / 10f) : 1f;
        int a = (int) (fade * 255);
        if (a < 8) return;
        int color = SpeedMath.lightningColor(p, d) & 0xFFFFFF;
        int text = (a << 24) | 0xFFFFFF;
        int accent = (a << 24) | color;
        int dim = (a << 24) | 0xAAAAAA;

        List<String> tags = new ArrayList<>();
        if (d.phasing) tags.add("PHASING");
        if (d.entityPhaseTicks > 0) tags.add("VIBRATING");
        if (d.perception) tags.add("PERCEPTION");
        if (d.freezeTicks > 0) tags.add("TIME FREEZE");
        if (d.foreverActive) tags.add("FOREVER");
        if (d.tornado) tags.add(d.vortexTarget >= 0 ? "VORTEX" : "TORNADO");
        if (d.v9Ticks > 0) tags.add("V-9 " + d.v9Ticks / 20 + "s");
        if (d.overdriveTicks > 0) tags.add("OVERDRIVE");
        if (d.blitzTicks > 0) tags.add("BLITZ");
        if (d.armoredTicks > 0) tags.add("ARMORED");
        if (d.stolenTicks > 0) tags.add("+" + Math.round(d.stolenBonus * 100) + "% STOLEN");
        if (SpeedController.waterRunning) tags.add("WATER RUN");
        if (SpeedController.wallRunning) tags.add(SpeedController.climbing ? "WALL CLIMB" : "WALL RUN");
        if (!p.getAbilities().instabuild && d.v9Ticks <= 0 && p.getFoodData().getFoodLevel() <= 6) tags.add("STARVING");

        String tagLine = String.join(" \u2022 ", tags);
        int lines = 4 + (tagLine.isEmpty() ? 0 : 1);
        int height = 8 + lines * 11 + 8;

        g.pose().pushPose();
        g.pose().translate(ClientConfig.HUD_X.get(), ClientConfig.HUD_Y.get(), 0);
        float scale = ClientConfig.HUD_SCALE.get().floatValue();
        g.pose().scale(scale, scale, 1f);

        g.fill(0, 0, PANEL_W, height, ((int) (a * 0.55f)) << 24);
        g.fill(0, 0, 2, height, accent);

        SpeedForceType type = SpeedMath.effectiveType(p, d);
        String header = switch (type) {
            case NEGATIVE -> "\u26A1 NEGATIVE SPEED FORCE";
            case V9 -> "\u26A1 V-9";
            default -> "\u26A1 SPEED FORCE";
        };
        int y = 5;
        g.drawString(font, header, 6, y, accent, true);
        y += 11;
        g.drawString(font, "LEVEL " + d.level + "  \u00B7  max " + (int) SpeedMath.LEVEL_MS[d.level] + " m/s", 6, y, text, true);
        y += 11;
        double ms = ClientFx.hudSpeed;
        String vel = String.format("%.1f m/s", ms);
        String kmh = String.format("%.0f km/h", ms * 3.6);
        g.drawString(font, vel, 6, y, accent, true);
        g.drawString(font, kmh, PANEL_W - 6 - font.width(kmh), y, dim, true);
        if (ms >= 343) g.drawString(font, "MACH " + String.format("%.1f", ms / 343.0), 6 + font.width(vel) + 6, y, (a << 24) | 0x9FE8FF, true);
        y += 11;

        int barW = PANEL_W - 12;
        g.fill(6, y + 1, 6 + barW, y + 6, ((int) (a * 0.6f)) << 24 | 0x303030);
        int filled = (int) (barW * Math.max(0f, Math.min(1f, d.energy / 100f)));
        int energyColor = d.energy < 20 ? 0xFF3030 : color;
        g.fill(6, y + 1, 6 + filled, y + 6, (a << 24) | energyColor);
        String lightning = SpeedMath.colorName(SpeedMath.lightningColor(p, d));
        g.drawString(font, lightning, PANEL_W - 6 - font.width(lightning), y + 8, dim, false);
        g.drawString(font, (int) d.energy + "%", 6, y + 8, dim, false);
        y += 11;
        if (!tagLine.isEmpty()) {
            y += 4;
            g.drawString(font, tagLine, 6, y, (a << 24) | 0x7FE8FF, true);
        }
        g.pose().popPose();
    }

    private static void charges(GuiGraphics g, Font font, int w, int h, LocalPlayer p, SpeedData d) {
        int color = SpeedMath.lightningColor(p, d) & 0xFFFFFF;
        int x = w / 2 - 50;
        int y = h / 2 + 16;
        if (ClientInput.lightningCharge >= 0) {
            bar(g, font, x, y, "LIGHTNING", ClientInput.lightningCharge / 40f, color);
            y += 16;
        }
        if (ClientInput.massCharge >= 0) {
            bar(g, font, x, y, "MASS PUNCH \u2022 " + ClientInput.massCharge + "%", ClientInput.massCharge / 100f, color);
            y += 16;
        }
        if (d.tornado && d.vortexTarget >= 0) {
            bar(g, font, x, y, "VORTEX", d.vortexCharge / 100f, color);
        }
    }

    private static void bar(GuiGraphics g, Font font, int x, int y, String label, float frac, int color) {
        g.drawString(font, label, x + 50 - font.width(label) / 2, y, 0xFFFFFFFF, true);
        g.fill(x, y + 10, x + 100, y + 13, 0x90303030);
        g.fill(x, y + 10, x + (int) (100 * Math.max(0f, Math.min(1f, frac))), y + 13, 0xFF000000 | color);
    }

    private static void race(GuiGraphics g, Font font, int w, LocalPlayer p, SpeedData d, DeltaTracker delta) {
        if (d.raceStart < 0) return;
        long ticks = p.level().getGameTime() - d.raceStart;
        if (ticks < 0) return;
        String time = RaceManager.format((int) ticks);
        String next = "NEXT: " + (d.raceNext <= 15 ? "CP " + d.raceNext + " / FINISH" : "FINISH");
        g.pose().pushPose();
        g.pose().translate(w / 2f, 22, 0);
        g.pose().scale(2f, 2f, 1f);
        g.drawString(font, time, -font.width(time) / 2, 0, 0xFFFFD21F, true);
        g.pose().popPose();
        g.drawString(font, next, (w - font.width(next)) / 2, 42, 0xFFCCCCCC, true);
    }
}
