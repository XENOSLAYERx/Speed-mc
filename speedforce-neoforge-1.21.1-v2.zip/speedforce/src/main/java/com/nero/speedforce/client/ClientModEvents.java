package com.nero.speedforce.client;

import com.nero.speedforce.SpeedForceMod;
import com.nero.speedforce.client.renderer.SpeedsterRenderer;
import com.nero.speedforce.client.renderer.TimeWraithRenderer;
import com.nero.speedforce.registry.ModEntities;
import net.minecraft.client.renderer.entity.NoopRenderer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;

@EventBusSubscriber(modid = SpeedForceMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private ClientModEvents() {}

    @SubscribeEvent
    public static void onKeys(RegisterKeyMappingsEvent event) {
        KeyBinds.register(event);
    }

    @SubscribeEvent
    public static void onGuiLayers(RegisterGuiLayersEvent event) {
        event.registerAboveAll(SpeedForceMod.rl("speed_hud"), SpeedHud::render);
    }

    @SubscribeEvent
    public static void onRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.LIGHTNING_THROW.get(), NoopRenderer::new);
        event.registerEntityRenderer(ModEntities.REVERSE_FLASH.get(), SpeedsterRenderer::new);
        event.registerEntityRenderer(ModEntities.ZOOM.get(), SpeedsterRenderer::new);
        event.registerEntityRenderer(ModEntities.GODSPEED.get(), SpeedsterRenderer::new);
        event.registerEntityRenderer(ModEntities.SAVITAR.get(), SpeedsterRenderer::new);
        event.registerEntityRenderer(ModEntities.BLACK_FLASH.get(), SpeedsterRenderer::new);
        event.registerEntityRenderer(ModEntities.SPEED_CLONE.get(), SpeedsterRenderer::new);
        event.registerEntityRenderer(ModEntities.TIME_WRAITH.get(), TimeWraithRenderer::new);
    }
}
