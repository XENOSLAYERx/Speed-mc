package com.nero.speedforce.registry;

import com.nero.speedforce.SpeedForceMod;
import com.nero.speedforce.block.ParticleAcceleratorBlock;
import com.nero.speedforce.block.RaceGateBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(SpeedForceMod.MODID);

    public static final DeferredBlock<Block> PARTICLE_ACCELERATOR = BLOCKS.register("particle_accelerator",
            () -> new ParticleAcceleratorBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.METAL).strength(5.0f, 12.0f).requiresCorrectToolForDrops()
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(ParticleAcceleratorBlock.POWER) * 7)));

    public static final DeferredBlock<Block> RACE_GATE = BLOCKS.register("race_gate",
            () -> new RaceGateBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.GOLD).strength(1.5f).noCollission().noOcclusion()
                    .sound(SoundType.METAL).lightLevel(state -> 8)));

    public static final DeferredBlock<Block> SPEED_FORCE_CRYSTAL = BLOCKS.register("speed_force_crystal",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.GOLD).strength(2.0f).sound(SoundType.AMETHYST).lightLevel(state -> 15)));

    private ModBlocks() {}
}
