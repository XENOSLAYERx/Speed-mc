package com.nero.speedforce.item;

import com.nero.speedforce.data.SpeedData;
import com.nero.speedforce.data.SpeedForceType;
import com.nero.speedforce.network.FxPayload;
import com.nero.speedforce.registry.ModAttachments;
import com.nero.speedforce.server.ServerFx;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.List;

/** Dangerous temporary speed: blue lightning, +50% top speed, infinite energy... and it eats you alive. */
public class V9Item extends Item {
    public static final int DURATION = 1200;

    public V9Item(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        return ItemUtils.startUsingInstantly(level, player, hand);
    }

    @Override
    public int getUseDuration(ItemStack stack, LivingEntity entity) {
        return 32;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.DRINK;
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (entity instanceof ServerPlayer sp) {
            SpeedData d = sp.getData(ModAttachments.SPEED);
            if (d.v9Ticks > 0) {
                sp.hurt(sp.damageSources().magic(), 6.0f);
                d.instability += 40f;
                sp.sendSystemMessage(Component.translatable("message.speedforce.v9_overdose").withStyle(ChatFormatting.DARK_RED));
            } else {
                sp.sendSystemMessage(Component.translatable("message.speedforce.v9").withStyle(ChatFormatting.BLUE));
            }
            d.v9Ticks = DURATION;
            d.enabled = true;
            d.energy = 100f;
            d.markDirty();
            ServerFx.burst(sp.serverLevel(), sp.position().add(0, 1, 0), SpeedForceType.V9.color, 50);
            sp.serverLevel().playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 0.6f, 1.6f);
            PacketDistributor.sendToPlayer(sp, new FxPayload(FxPayload.ACTIVATE, sp.getId(), SpeedForceType.V9.ordinal()));
        }
        if (entity instanceof Player player && !player.getAbilities().instabuild) stack.shrink(1);
        if (stack.isEmpty()) return new ItemStack(Items.GLASS_BOTTLE);
        if (entity instanceof Player player && !player.getAbilities().instabuild) {
            ItemStack bottle = new ItemStack(Items.GLASS_BOTTLE);
            if (!player.getInventory().add(bottle)) player.drop(bottle, false);
        }
        return stack;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.speedforce.v9_serum").withStyle(ChatFormatting.BLUE, ChatFormatting.ITALIC));
        tooltip.add(Component.translatable("tooltip.speedforce.v9_serum.warning").withStyle(ChatFormatting.DARK_RED));
    }
}
