package com.nero.speedforce.network;

import com.nero.speedforce.SpeedForceMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client -> server: "use this ability" with one integer argument. */
public record AbilityPayload(int ability, int arg) implements CustomPacketPayload {
    public static final Type<AbilityPayload> TYPE = new Type<>(SpeedForceMod.rl("ability"));
    public static final StreamCodec<ByteBuf, AbilityPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, AbilityPayload::ability,
            ByteBufCodecs.VAR_INT, AbilityPayload::arg,
            AbilityPayload::new);

    public AbilityPayload(Ability ability, int arg) {
        this(ability.ordinal(), arg);
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
