package com.nero.speedforce.item;

import com.nero.speedforce.data.SpeedData;
import com.nero.speedforce.network.FxPayload;
import com.nero.speedforce.registry.ModAttachments;
import com.nero.speedforce.server.ServerFx;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.List;

/** Boss trophies that permanently unlock a power. */
public class UnlockItem extends Item {
    public enum Kind { FOREVER, WHITE }

    private final Kind kind;

    public UnlockItem(Properties properties, Kind kind) {
        super(properties);
        this.kind = kind;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.success(stack);
        ServerPlayer sp = (ServerPlayer) player;
        SpeedData d = sp.getData(ModAttachments.SPEED);
        if (!d.hasPower) {
            sp.displayClientMessage(Component.translatable("message.speedforce.needs_speedster").withStyle(ChatFormatting.GRAY), true);
            return InteractionResultHolder.fail(stack);
        }
        boolean already = kind == Kind.FOREVER ? d.foreverUnlocked : d.whiteUnlocked;
        if (already) {
            sp.displayClientMessage(Component.translatable("message.speedforce.already_unlocked").withStyle(ChatFormatting.GRAY), true);
            return InteractionResultHolder.fail(stack);
        }
        if (kind == Kind.FOREVER) d.foreverUnlocked = true;
        else d.whiteUnlocked = true;
        d.markDirty();

        int color = kind == Kind.FOREVER ? 0x7FE8FF : 0xFFFFFF;
        ServerFx.burst(sp.serverLevel(), sp.position().add(0, 1, 0), color, 60);
        sp.serverLevel().playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.0f, 1.4f);
        PacketDistributor.sendToPlayer(sp, new FxPayload(FxPayload.FLASH, sp.getId(), 10));
        sp.sendSystemMessage(Component.translatable(kind == Kind.FOREVER ? "message.speedforce.forever_unlocked" : "message.speedforce.white_unlocked")
                .withStyle(ChatFormatting.AQUA));
        if (!sp.getAbilities().instabuild) stack.shrink(1);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        String k = kind == Kind.FOREVER ? "forever_force_fragment" : "white_speed_core";
        tooltip.add(Component.translatable("tooltip.speedforce." + k).withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
        tooltip.add(Component.translatable("tooltip.speedforce." + k + ".use").withStyle(ChatFormatting.DARK_AQUA));
    }
}
