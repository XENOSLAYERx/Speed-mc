package com.nero.speedforce.server;

import com.nero.speedforce.Config;
import com.nero.speedforce.entity.SpeedsterEntity;
import com.nero.speedforce.entity.TimeWraithEntity;
import com.nero.speedforce.registry.ModEntities;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.List;
import java.util.Locale;

public final class BossSpawner {
    public static final List<String> NAMES = List.of("reverse_flash", "zoom", "godspeed", "savitar", "black_flash", "time_wraith", "speed_clone");

    private BossSpawner() {}

    @Nullable
    public static Mob spawn(ServerLevel level, String name, Vec3 at, @Nullable LivingEntity target) {
        EntityType<? extends Mob> type = switch (name.toLowerCase(Locale.ROOT)) {
            case "reverse_flash" -> ModEntities.REVERSE_FLASH.get();
            case "zoom" -> ModEntities.ZOOM.get();
            case "godspeed" -> ModEntities.GODSPEED.get();
            case "savitar" -> ModEntities.SAVITAR.get();
            case "black_flash" -> ModEntities.BLACK_FLASH.get();
            case "speed_clone" -> ModEntities.SPEED_CLONE.get();
            case "time_wraith" -> ModEntities.TIME_WRAITH.get();
            default -> null;
        };
        if (type == null) return null;
        Mob mob = type.create(level);
        if (mob == null) return null;
        mob.moveTo(at.x, at.y, at.z, level.random.nextFloat() * 360f, 0f);
        if (mob instanceof SpeedsterEntity s && s.variant.boss) {
            AttributeInstance hp = s.getAttribute(Attributes.MAX_HEALTH);
            if (hp != null) hp.setBaseValue(hp.getBaseValue() * Config.BOSS_HEALTH.get());
            s.setHealth(s.getMaxHealth());
        }
        if (target != null) mob.setTarget(target);
        level.addFreshEntity(mob);

        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {
            bolt.moveTo(at.x, at.y, at.z);
            bolt.setVisualOnly(true);
            bolt.addTag(ServerEvents.NO_FILL_TAG);
            level.addFreshEntity(bolt);
        }
        int color = mob instanceof SpeedsterEntity s ? s.variant.color : (mob instanceof TimeWraithEntity ? 0x5AD1FF : 0xFFFFFF);
        ServerFx.burst(level, at.add(0, 1, 0), color, 40);
        return mob;
    }

    /** Speedster Signal: a random rival answers. */
    public static boolean spawnRandomRival(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        String[] rivals = {"reverse_flash", "zoom", "godspeed", "savitar", "black_flash"};
        String pick = rivals[level.random.nextInt(rivals.length)];
        double a = level.random.nextDouble() * Math.PI * 2;
        int x = (int) Math.floor(p.getX() + Math.cos(a) * 14);
        int z = (int) Math.floor(p.getZ() + Math.sin(a) * 14);
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        Mob mob = spawn(level, pick, new Vec3(x + 0.5, y, z + 0.5), p);
        if (mob == null) return false;
        level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 0.6f, 1.6f);
        p.sendSystemMessage(Component.translatable("message.speedforce.rival_arrives", mob.getDisplayName()).withStyle(ChatFormatting.DARK_RED));
        return true;
    }
}
