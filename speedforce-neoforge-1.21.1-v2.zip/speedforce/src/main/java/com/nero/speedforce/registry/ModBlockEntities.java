package com.nero.speedforce.registry;

import com.nero.speedforce.SpeedForceMod;
import com.nero.speedforce.block.AcceleratorBlockEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, SpeedForceMod.MODID);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AcceleratorBlockEntity>> ACCELERATOR =
            BLOCK_ENTITIES.register("particle_accelerator",
                    () -> BlockEntityType.Builder.of(AcceleratorBlockEntity::new, ModBlocks.PARTICLE_ACCELERATOR.get()).build(null));

    private ModBlockEntities() {}
}
