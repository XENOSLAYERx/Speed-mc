package com.nero.speedforce.network;

import com.nero.speedforce.SpeedForceMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Server -> client: screen effects (activation cinematic, shake, flash). */
public record FxPayload(int kind, int entityId, float value) implements CustomPacketPayload {
    public static final int ACTIVATE = 0;
    public static final int SHAKE = 1;
    public static final int FLASH = 2;
    public static final int BOOM = 3;

    public static final Type<FxPayload> TYPE = new Type<>(SpeedForceMod.rl("fx"));
    public static final StreamCodec<ByteBuf, FxPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, FxPayload::kind,
            ByteBufCodecs.VAR_INT, FxPayload::entityId,
            ByteBufCodecs.FLOAT, FxPayload::value,
            FxPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
