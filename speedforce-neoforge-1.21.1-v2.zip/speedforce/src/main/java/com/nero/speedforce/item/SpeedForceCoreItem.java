package com.nero.speedforce.item;

import com.nero.speedforce.data.SpeedData;
import com.nero.speedforce.data.SpeedForceType;
import com.nero.speedforce.registry.ModAttachments;
import com.nero.speedforce.server.SpeedForceOrigin;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/** Right-click: BOOM, you're a speedster (or your Speed Force is converted). */
public class SpeedForceCoreItem extends Item {
    private final SpeedForceType grants;

    public SpeedForceCoreItem(Properties properties, SpeedForceType grants) {
        super(properties);
        this.grants = grants;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.success(stack);
        ServerPlayer sp = (ServerPlayer) player;
        SpeedData d = sp.getData(ModAttachments.SPEED);
        if (d.hasPower && d.type == grants) {
            sp.displayClientMessage(Component.translatable("message.speedforce.already_connected").withStyle(ChatFormatting.GRAY), true);
            return InteractionResultHolder.fail(stack);
        }
        SpeedForceOrigin.grant(sp, grants);
        if (!sp.getAbilities().instabuild) stack.shrink(1);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.speedforce.core." + grants.id()).withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
        tooltip.add(Component.translatable("tooltip.speedforce.core.use").withStyle(ChatFormatting.DARK_AQUA));
    }
}
