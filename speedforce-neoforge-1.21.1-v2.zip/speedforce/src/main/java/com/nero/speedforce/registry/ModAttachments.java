package com.nero.speedforce.registry;

import com.nero.speedforce.SpeedForceMod;
import com.nero.speedforce.data.SpeedData;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

import java.util.function.Supplier;

public final class ModAttachments {
    public static final DeferredRegister<AttachmentType<?>> ATTACHMENT_TYPES =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, SpeedForceMod.MODID);

    public static final Supplier<AttachmentType<SpeedData>> SPEED = ATTACHMENT_TYPES.register("speed_data",
            () -> AttachmentType.serializable(SpeedData::new).copyOnDeath().build());

    private ModAttachments() {}
}
