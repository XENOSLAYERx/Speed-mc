package com.nero.speedforce.server;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

/**
 * Local time slowdown. Instead of ticking the world slower (impossible per-player), everything inside a
 * speedster's bubble is slowed: mobs get heavy slowness, projectiles and falling blocks hang in the air
 * with their original velocity stored, TNT fuses stop. Leaving the bubble restores them.
 */
public final class PerceptionManager {
    private record Frozen(Vec3 velocity, boolean noGravity) {}

    private static final Map<Entity, Frozen> FROZEN = new WeakHashMap<>();
    private static final Set<Entity> TOUCHED = Collections.newSetFromMap(new WeakHashMap<>());

    private PerceptionManager() {}

    public static void bubble(ServerPlayer p, double radius, int amplifier, boolean forever) {
        ServerLevel level = p.serverLevel();
        AABB box = p.getBoundingBox().inflate(radius);
        double r2 = radius * radius;
        for (Entity e : level.getEntities(p, box, e -> e.isAlive() && e.distanceToSqr(p) <= r2)) {
            if (e instanceof Projectile proj) {
                if (proj.getOwner() != p) freeze(e);
            } else if (e instanceof FallingBlockEntity) {
                freeze(e);
            } else if (e instanceof PrimedTnt tnt) {
                tnt.setFuse(tnt.getFuse() + 1);
            } else if (e instanceof LivingEntity living) {
                if (living.isAlliedTo(p)) continue;
                if (living instanceof Player other && (other.isCreative() || other.isSpectator())) continue;
                int amp = living instanceof Player ? Math.min(amplifier, 2) : amplifier;
                living.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 10, amp, false, false));
                living.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 10, 2, false, false));
                if (forever) {
                    living.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 10, 0, false, false));
                    living.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 10, 2, false, false));
                } else if (!(living instanceof Player)) {
                    Vec3 v = living.getDeltaMovement();
                    living.setDeltaMovement(v.x * 0.5, v.y > 0 ? v.y * 0.5 : v.y, v.z * 0.5);
                }
            }
        }
    }

    private static void freeze(Entity e) {
        Frozen f = FROZEN.get(e);
        if (f == null) {
            f = new Frozen(e.getDeltaMovement(), e.isNoGravity());
            FROZEN.put(e, f);
            e.setNoGravity(true);
        }
        e.setDeltaMovement(f.velocity().scale(0.04));
        e.hasImpulse = true;
        TOUCHED.add(e);
    }

    /** Called once per server tick after all players ticked: release anything no bubble touched. */
    public static void serverTick() {
        Iterator<Map.Entry<Entity, Frozen>> it = FROZEN.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Entity, Frozen> entry = it.next();
            Entity e = entry.getKey();
            if (e == null || e.isRemoved()) {
                it.remove();
                continue;
            }
            if (!TOUCHED.contains(e)) {
                e.setNoGravity(entry.getValue().noGravity());
                e.setDeltaMovement(entry.getValue().velocity());
                e.hasImpulse = true;
                it.remove();
            }
        }
        TOUCHED.clear();
    }
}
