package com.nero.speedforce.client;

import com.nero.speedforce.registry.ModAttachments;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;

/** Looping wind roar whose volume and pitch follow your velocity. */
public class SpeedWindSound extends AbstractTickableSoundInstance {
    private final LocalPlayer player;

    public SpeedWindSound(LocalPlayer player) {
        super(SoundEvents.ELYTRA_FLYING, SoundSource.PLAYERS, SoundInstance.createUnseededRandom());
        this.player = player;
        this.looping = true;
        this.delay = 0;
        this.volume = 0.05f;
        this.x = player.getX();
        this.y = player.getY();
        this.z = player.getZ();
    }

    @Override
    public void tick() {
        if (player.isRemoved() || !player.getData(ModAttachments.SPEED).isPowered()) {
            stop();
            return;
        }
        double s = SpeedController.displaySpeed;
        if (s < 0.3) {
            volume = Math.max(0f, volume - 0.08f);
            if (volume <= 0.01f) {
                stop();
                return;
            }
        } else {
            volume = (float) Mth.clamp(s / 9.0, 0.08, 0.9);
        }
        pitch = (float) Mth.clamp(0.6 + s * 0.07, 0.6, 1.9);
        x = player.getX();
        y = player.getY();
        z = player.getZ();
    }
}
