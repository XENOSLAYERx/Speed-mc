package com.nero.speedforce.item;

import com.nero.speedforce.data.SuitType;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/** A suit piece. The full set changes speed stats, lightning colour and the [Y] suit ability. */
public class SuitArmorItem extends ArmorItem {
    public final SuitType suit;

    public SuitArmorItem(Holder<ArmorMaterial> material, ArmorItem.Type type, SuitType suit, Item.Properties properties) {
        super(material, type, properties);
        this.suit = suit;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(suit.displayName().copy().withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.translatable("tooltip.speedforce.suit.set").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal(String.format(" Top speed x%.2f  Accel x%.2f  Control x%.2f", suit.maxMult, suit.accel, suit.control))
                .withStyle(ChatFormatting.DARK_AQUA));
        tooltip.add(Component.literal(" [Y] " + suit.abilityName).withStyle(ChatFormatting.AQUA));
        if (suit.bonusDamage > 0) {
            tooltip.add(Component.literal(String.format(" +%.1f punch damage", suit.bonusDamage)).withStyle(ChatFormatting.DARK_AQUA));
        }
        if (suit.forceOverride != null) {
            tooltip.add(Component.translatable("tooltip.speedforce.suit.negative").withStyle(ChatFormatting.RED));
        }
    }
}
