package com.nero.speedforce.server;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.nero.speedforce.data.SpeedData;
import com.nero.speedforce.data.SpeedForceType;
import com.nero.speedforce.data.SuitType;
import com.nero.speedforce.item.SuitArmorItem;
import com.nero.speedforce.registry.ModAttachments;
import com.nero.speedforce.registry.ModItems;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.registries.DeferredItem;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * /speedforce grant [speed|negative] | revoke | level <1-10> | lightning <color|#RRGGBB|reset>
 *             suit <suit> | boss <name> | dimension | energy <0-100> | unlock <forever|white> | give
 */
public final class SpeedForceCommand {
    private static final Map<String, Integer> COLORS = Map.of(
            "yellow", 0xFFD21F, "red", 0xFF2424, "blue", 0x3D7BFF, "white", 0xF4F8FF, "orange", 0xFF8C1A,
            "purple", 0xB04CFF, "green", 0x3DFF6A, "gold", 0xFFE070, "black", 0x1A1A2E);
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private SpeedForceCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        List<String> suits = Arrays.stream(SuitType.values()).map(s -> s.id).toList();
        dispatcher.register(Commands.literal("speedforce").requires(s -> s.hasPermission(2))
                .then(Commands.literal("grant")
                        .executes(c -> grant(c, SpeedForceType.SPEED))
                        .then(Commands.argument("type", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(List.of("speed", "negative"), b))
                                .executes(c -> grant(c, SpeedForceType.byName(StringArgumentType.getString(c, "type"))))))
                .then(Commands.literal("revoke").executes(c -> {
                    SpeedForceOrigin.revoke(player(c));
                    return ok(c, "Speed Force removed.");
                }))
                .then(Commands.literal("level").then(Commands.argument("level", IntegerArgumentType.integer(1, 10)).executes(c -> {
                    SpeedData d = data(c);
                    d.level = IntegerArgumentType.getInteger(c, "level");
                    d.markDirty();
                    return ok(c, "Speed level set to " + d.level);
                })))
                .then(Commands.literal("lightning").then(Commands.argument("color", StringArgumentType.greedyString())
                        .suggests((c, b) -> SharedSuggestionProvider.suggest(COLORS.keySet().stream().toList(), b))
                        .executes(SpeedForceCommand::lightning)))
                .then(Commands.literal("suit").then(Commands.argument("suit", StringArgumentType.word())
                        .suggests((c, b) -> SharedSuggestionProvider.suggest(suits, b))
                        .executes(SpeedForceCommand::suit)))
                .then(Commands.literal("boss").then(Commands.argument("boss", StringArgumentType.word())
                        .suggests((c, b) -> SharedSuggestionProvider.suggest(BossSpawner.NAMES, b))
                        .executes(SpeedForceCommand::boss)))
                .then(Commands.literal("dimension").executes(c -> {
                    ServerPlayer p = player(c);
                    TravelManager.use(p, p.getData(ModAttachments.SPEED), true);
                    return 1;
                }))
                .then(Commands.literal("energy").then(Commands.argument("amount", IntegerArgumentType.integer(0, 100)).executes(c -> {
                    SpeedData d = data(c);
                    d.energy = IntegerArgumentType.getInteger(c, "amount");
                    d.markDirty();
                    return ok(c, "Energy set to " + (int) d.energy);
                })))
                .then(Commands.literal("unlock")
                        .then(Commands.literal("forever").executes(c -> {
                            SpeedData d = data(c);
                            d.foreverUnlocked = true;
                            d.markDirty();
                            return ok(c, "Forever Force unlocked.");
                        }))
                        .then(Commands.literal("white").executes(c -> {
                            SpeedData d = data(c);
                            d.whiteUnlocked = true;
                            d.markDirty();
                            return ok(c, "White lightning unlocked.");
                        })))
                .then(Commands.literal("give").executes(c -> {
                    ServerPlayer p = player(c);
                    give(p, new ItemStack(ModItems.SPEED_FORCE_CORE.get()));
                    give(p, new ItemStack(ModItems.FLASH_RING.get()));
                    give(p, new ItemStack(ModItems.SPEED_TRAINING_DEVICE.get()));
                    for (DeferredItem<SuitArmorItem> piece : ModItems.SUITS.get(SuitType.FLASH)) give(p, new ItemStack(piece.get()));
                    return ok(c, "Starter speedster kit given.");
                })));
    }

    private static ServerPlayer player(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        return c.getSource().getPlayerOrException();
    }

    private static SpeedData data(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        return player(c).getData(ModAttachments.SPEED);
    }

    private static int ok(CommandContext<CommandSourceStack> c, String msg) {
        c.getSource().sendSuccess(() -> Component.literal(msg), false);
        return 1;
    }

    private static void give(ServerPlayer p, ItemStack stack) {
        if (!p.getInventory().add(stack)) p.drop(stack, false);
    }

    private static int grant(CommandContext<CommandSourceStack> c, SpeedForceType type) throws CommandSyntaxException {
        if (type == SpeedForceType.NONE || type == SpeedForceType.V9) type = SpeedForceType.SPEED;
        SpeedForceOrigin.grant(player(c), type);
        return 1;
    }

    private static int lightning(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        String arg = StringArgumentType.getString(c, "color").trim().toLowerCase(Locale.ROOT);
        SpeedData d = data(c);
        if (arg.equals("reset")) {
            d.colorOverride = -1;
        } else if (COLORS.containsKey(arg)) {
            d.colorOverride = COLORS.get(arg);
        } else {
            try {
                d.colorOverride = Integer.parseInt(arg.replace("#", ""), 16) & 0xFFFFFF;
            } catch (NumberFormatException e) {
                c.getSource().sendFailure(Component.literal("Use a color name, #RRGGBB, or reset"));
                return 0;
            }
        }
        d.markDirty();
        return ok(c, "Lightning color updated.");
    }

    private static int suit(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        SuitType suit = SuitType.byId(StringArgumentType.getString(c, "suit"));
        if (suit == null) {
            c.getSource().sendFailure(Component.literal("Unknown suit"));
            return 0;
        }
        ServerPlayer p = player(c);
        List<DeferredItem<SuitArmorItem>> pieces = ModItems.SUITS.get(suit);
        for (int i = 0; i < SLOTS.length; i++) {
            ItemStack old = p.getItemBySlot(SLOTS[i]);
            if (!old.isEmpty()) give(p, old);
            p.setItemSlot(SLOTS[i], new ItemStack(pieces.get(i).get()));
        }
        return ok(c, "Suited up.");
    }

    private static int boss(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer p = player(c);
        Vec3 at = p.position().add(p.getLookAngle().multiply(1, 0, 1).normalize().scale(8));
        Mob mob = BossSpawner.spawn(p.serverLevel(), StringArgumentType.getString(c, "boss"), at, p);
        if (mob == null) {
            c.getSource().sendFailure(Component.literal("Unknown boss"));
            return 0;
        }
        return ok(c, "Summoned " + mob.getDisplayName().getString());
    }
}
