package com.nero.speedforce.client.renderer;

import com.nero.speedforce.SpeedForceMod;
import com.nero.speedforce.entity.SpeedsterEntity;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Rival speedsters use the player model with their own 64x64 skin. */
public class SpeedsterRenderer extends HumanoidMobRenderer<SpeedsterEntity, PlayerModel<SpeedsterEntity>> {
    private static final ResourceLocation REVERSE_FLASH = SpeedForceMod.rl("textures/entity/reverse_flash.png");
    private static final ResourceLocation ZOOM = SpeedForceMod.rl("textures/entity/zoom.png");
    private static final ResourceLocation GODSPEED = SpeedForceMod.rl("textures/entity/godspeed.png");
    private static final ResourceLocation SAVITAR = SpeedForceMod.rl("textures/entity/savitar.png");
    private static final ResourceLocation BLACK_FLASH = SpeedForceMod.rl("textures/entity/black_flash.png");
    private static final ResourceLocation CLONE = SpeedForceMod.rl("textures/entity/speed_clone.png");

    public SpeedsterRenderer(EntityRendererProvider.Context context) {
        super(context, new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER), false), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(SpeedsterEntity entity) {
        return switch (entity.variant) {
            case REVERSE_FLASH -> REVERSE_FLASH;
            case ZOOM -> ZOOM;
            case GODSPEED -> GODSPEED;
            case SAVITAR -> SAVITAR;
            case BLACK_FLASH -> BLACK_FLASH;
            case CLONE -> CLONE;
        };
    }
}
