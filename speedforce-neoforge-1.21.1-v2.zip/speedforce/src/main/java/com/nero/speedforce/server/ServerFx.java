package com.nero.speedforce.server;

import com.nero.speedforce.data.SpeedMath;
import com.nero.speedforce.network.FxPayload;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;
import org.joml.Vector3f;

/** Server-broadcast particle effects visible to every nearby player. */
public final class ServerFx {
    private ServerFx() {}

    public static DustParticleOptions dust(int color, float scale) {
        float[] c = SpeedMath.rgb(color);
        return new DustParticleOptions(new Vector3f(c[0], c[1], c[2]), scale);
    }

    /** Jagged lightning arc between two points. */
    public static void arc(ServerLevel level, Vec3 a, Vec3 b, int color) {
        DustParticleOptions d = dust(color, 0.7f);
        RandomSource r = level.random;
        double length = a.distanceTo(b);
        double jitter = Math.min(0.6, length * 0.12);
        int segments = 5;
        int budget = 40;
        Vec3 prev = a;
        for (int s = 1; s <= segments && budget > 0; s++) {
            Vec3 next = s == segments ? b : a.lerp(b, s / (double) segments)
                    .add((r.nextDouble() - 0.5) * jitter * 2, (r.nextDouble() - 0.5) * jitter * 2, (r.nextDouble() - 0.5) * jitter * 2);
            int n = Math.max(2, (int) (prev.distanceTo(next) / 0.3));
            for (int i = 0; i < n && budget > 0; i++, budget--) {
                Vec3 q = prev.lerp(next, i / (double) n);
                level.sendParticles(d, q.x, q.y, q.z, 1, 0, 0, 0, 0);
            }
            prev = next;
        }
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, b.x, b.y, b.z, 3, 0.1, 0.1, 0.1, 0.1);
    }

    public static void ring(ServerLevel level, Vec3 c, double radius, int color, int points) {
        DustParticleOptions d = dust(color, 1.0f);
        for (int i = 0; i < points; i++) {
            double a = i * (Math.PI * 2 / points);
            level.sendParticles(d, c.x + Math.cos(a) * radius, c.y, c.z + Math.sin(a) * radius, 1, 0, 0.05, 0, 0);
        }
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, points / 3, radius * 0.5, 0.2, radius * 0.5, 0.2);
    }

    public static void burst(ServerLevel level, Vec3 c, int color, int count) {
        level.sendParticles(dust(color, 1.2f), c.x, c.y, c.z, count, 0.6, 0.8, 0.6, 0);
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, Math.max(1, count / 2), 0.5, 0.7, 0.5, 0.25);
    }

    public static void shake(ServerPlayer player, float amount) {
        PacketDistributor.sendToPlayer(player, new FxPayload(FxPayload.SHAKE, player.getId(), amount));
    }

    public static void shakeNearby(ServerLevel level, Vec3 c, double radius, float amount) {
        for (ServerPlayer p : level.players()) {
            double d = p.position().distanceTo(c);
            if (d < radius) shake(p, amount * (float) (1.0 - d / radius));
        }
    }
}
