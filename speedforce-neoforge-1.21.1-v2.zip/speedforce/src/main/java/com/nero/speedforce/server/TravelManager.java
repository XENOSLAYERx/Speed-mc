package com.nero.speedforce.server;

import com.nero.speedforce.Config;
import com.nero.speedforce.SpeedForceMod;
import com.nero.speedforce.data.SpeedData;
import com.nero.speedforce.data.SpeedMath;
import com.nero.speedforce.entity.SpeedsterEntity;
import com.nero.speedforce.network.FxPayload;
import com.nero.speedforce.registry.ModBlocks;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.List;

/**
 * Speed Force travel. Break in at speed level 9+ running 150 m/s. Coordinates are scaled 1:8, so running
 * inside the Speed Force and stepping out is a fast-travel system (like the Nether, but earned).
 */
public final class TravelManager {
    public static final ResourceKey<Level> SPEED_FORCE = ResourceKey.create(Registries.DIMENSION, SpeedForceMod.rl("speed_force"));
    private static final double ENTRY_SPEED = 7.5;

    private TravelManager() {}

    public static void use(ServerPlayer p, SpeedData d, boolean force) {
        if (!force && !Config.SPEED_FORCE_DIMENSION.get()) {
            AbilityHandler.bar(p, "The Speed Force is closed on this server", ChatFormatting.GRAY);
            return;
        }
        MinecraftServer server = p.server;
        ServerLevel speedForce = server.getLevel(SPEED_FORCE);
        if (speedForce == null) {
            AbilityHandler.bar(p, "Speed Force dimension missing (datapack not loaded)", ChatFormatting.RED);
            return;
        }
        boolean inside = p.level().dimension() == SPEED_FORCE;
        if (!force && !inside) {
            if (d.level < Config.TRAVEL_LEVEL.get()) {
                AbilityHandler.bar(p, "Reach speed level " + Config.TRAVEL_LEVEL.get() + " to break into the Speed Force", ChatFormatting.GRAY);
                return;
            }
            if (d.serverSpeed < ENTRY_SPEED) {
                AbilityHandler.bar(p, "Run faster! " + (int) (ENTRY_SPEED * 20) + " m/s needed", ChatFormatting.GOLD);
                return;
            }
            if (!AbilityHandler.spend(p, d, 30f)) return;
        }

        ServerLevel from = p.serverLevel();
        ServerLevel to;
        Vec3 dest;
        if (inside) {
            to = server.overworld();
            int x = Mth.floor(p.getX() * 8);
            int z = Mth.floor(p.getZ() * 8);
            int y = to.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            if (y <= to.getMinBuildHeight() + 1) {
                y = 100;
                platform(to, x, y - 1, z, Blocks.GLASS.defaultBlockState());
            }
            dest = new Vec3(x + 0.5, y, z + 0.5);
        } else {
            to = speedForce;
            int x = Mth.floor(p.getX() / 8);
            int z = Mth.floor(p.getZ() / 8);
            int y = findSurface(to, x, z);
            if (y < 0) {
                y = 121;
                platform(to, x, y - 1, z, ModBlocks.SPEED_FORCE_CRYSTAL.get().defaultBlockState());
            }
            dest = new Vec3(x + 0.5, y, z + 0.5);
            d.instability += 25f;
        }

        int color = SpeedMath.lightningColor(p, d);
        ServerFx.burst(from, p.position().add(0, 1, 0), color, 60);
        from.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 1.5f, 1.4f);

        List<SpeedsterEntity> followers = from.getEntitiesOfClass(SpeedsterEntity.class, p.getBoundingBox().inflate(64),
                s -> s.getTarget() == p && !s.isAlly());

        p.teleportTo(to, dest.x, dest.y, dest.z, p.getYRot(), p.getXRot());
        for (SpeedsterEntity s : followers) migrate(s, to, dest, p);

        ServerFx.burst(to, dest.add(0, 1, 0), color, 60);
        to.playSound(null, dest.x, dest.y, dest.z, SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.2f, 1.6f);
        PacketDistributor.sendToPlayer(p, new FxPayload(FxPayload.FLASH, p.getId(), 14));
        p.sendSystemMessage(Component.translatable(inside ? "message.speedforce.exit_speed_force" : "message.speedforce.enter_speed_force")
                .withStyle(ChatFormatting.GOLD));
        if (!followers.isEmpty()) {
            p.sendSystemMessage(Component.translatable("message.speedforce.followed").withStyle(ChatFormatting.DARK_RED));
        }
        d.lastPos = null;
        d.markDirty();
    }

    private static int findSurface(ServerLevel level, int x, int z) {
        BlockPos.MutableBlockPos bp = new BlockPos.MutableBlockPos();
        for (int y = 230; y > 5; y--) {
            bp.set(x, y, z);
            BlockState s = level.getBlockState(bp);
            if (!s.isAir() && s.getFluidState().isEmpty() && level.getBlockState(bp.above()).isAir() && level.getBlockState(bp.above(2)).isAir()) {
                return y + 1;
            }
        }
        return -1;
    }

    private static void platform(ServerLevel level, int x, int y, int z, BlockState state) {
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                BlockPos bp = new BlockPos(x + dx, y, z + dz);
                if (level.getBlockState(bp).isAir()) level.setBlockAndUpdate(bp, state);
            }
        }
    }

    private static void migrate(SpeedsterEntity old, ServerLevel to, Vec3 dest, ServerPlayer target) {
        Entity created = old.getType().create(to);
        if (!(created instanceof SpeedsterEntity copy)) return;
        copy.moveTo(dest.x + 4, dest.y, dest.z + 4, old.getYRot(), 0);
        AttributeInstance oldHp = old.getAttribute(Attributes.MAX_HEALTH);
        AttributeInstance newHp = copy.getAttribute(Attributes.MAX_HEALTH);
        if (oldHp != null && newHp != null) newHp.setBaseValue(oldHp.getBaseValue());
        copy.setHealth(old.getHealth());
        copy.setTarget(target);
        to.addFreshEntity(copy);
        old.discard();
    }
}
