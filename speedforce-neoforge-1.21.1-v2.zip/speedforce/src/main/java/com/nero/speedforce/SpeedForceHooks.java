package com.nero.speedforce;

import com.nero.speedforce.data.SpeedData;
import com.nero.speedforce.registry.ModAttachments;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

/** Small static entry points used by mixins. */
public final class SpeedForceHooks {
    private SpeedForceHooks() {}

    public static boolean isPhasing(Player player) {
        if (player.isSpectator()) return false;
        SpeedData d = player.getData(ModAttachments.SPEED);
        return d.phasing && d.isPowered();
    }

    /** Lets the server accept speedster-scale movement packets. */
    public static boolean bypassMovementCheck(ServerPlayer player) {
        return player != null && player.getData(ModAttachments.SPEED).isPowered();
    }
}
