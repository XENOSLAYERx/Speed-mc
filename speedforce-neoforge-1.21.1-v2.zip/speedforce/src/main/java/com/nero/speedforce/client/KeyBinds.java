package com.nero.speedforce.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import org.lwjgl.glfw.GLFW;

/** All rebindable in Options > Controls > Speed Force. */
public final class KeyBinds {
    public static final String CATEGORY = "key.categories.speedforce";

    public static final KeyMapping POWER = key("power", GLFW.GLFW_KEY_N);
    public static final KeyMapping LEVEL_UP = key("level_up", GLFW.GLFW_KEY_EQUAL);
    public static final KeyMapping LEVEL_DOWN = key("level_down", GLFW.GLFW_KEY_MINUS);
    public static final KeyMapping LIGHTNING = key("lightning", GLFW.GLFW_KEY_R);
    public static final KeyMapping PHASE = key("phase", GLFW.GLFW_KEY_Z);
    public static final KeyMapping PERCEPTION = key("perception", GLFW.GLFW_KEY_C);
    public static final KeyMapping SPEED_STEAL = key("speed_steal", GLFW.GLFW_KEY_V);
    public static final KeyMapping DASH = key("dash", GLFW.GLFW_KEY_B);
    public static final KeyMapping MASS_PUNCH = key("mass_punch", GLFW.GLFW_KEY_G);
    public static final KeyMapping TORNADO = key("tornado", GLFW.GLFW_KEY_H);
    public static final KeyMapping TRAVEL = key("travel", GLFW.GLFW_KEY_P);
    public static final KeyMapping FOREVER = key("forever", GLFW.GLFW_KEY_J);
    public static final KeyMapping SUIT_ABILITY = key("suit_ability", GLFW.GLFW_KEY_Y);

    public static final KeyMapping[] ALL = {POWER, LEVEL_UP, LEVEL_DOWN, LIGHTNING, PHASE, PERCEPTION, SPEED_STEAL,
            DASH, MASS_PUNCH, TORNADO, TRAVEL, FOREVER, SUIT_ABILITY};

    private KeyBinds() {}

    private static KeyMapping key(String name, int key) {
        return new KeyMapping("key.speedforce." + name, InputConstants.Type.KEYSYM, key, CATEGORY);
    }

    public static void register(RegisterKeyMappingsEvent event) {
        for (KeyMapping k : ALL) event.register(k);
    }
}
