package com.nero.speedforce.server;

import com.nero.speedforce.data.SpeedData;
import com.nero.speedforce.network.SyncPayload;
import com.nero.speedforce.registry.ModAttachments;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

public final class SpeedSync {
    private SpeedSync() {}

    public static void sync(ServerPlayer player, SpeedData d, boolean everyone) {
        SyncPayload payload = new SyncPayload(player.getId(), d.serializeNBT(player.registryAccess()));
        if (everyone) PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, payload);
        else PacketDistributor.sendToPlayer(player, payload);
    }

    /** Send {@code subject}'s state to one viewer (used when they start tracking). */
    public static void sendTo(ServerPlayer subject, ServerPlayer viewer) {
        SpeedData d = subject.getData(ModAttachments.SPEED);
        PacketDistributor.sendToPlayer(viewer, new SyncPayload(subject.getId(), d.serializeNBT(subject.registryAccess())));
    }
}
