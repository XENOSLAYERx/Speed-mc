package com.nero.speedforce.data;

import com.nero.speedforce.Config;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

/** Shared speed formulas, used identically on client (movement) and server (validation, combat). */
public final class SpeedMath {
    /** Top speed per level in metres (blocks) per second. Index 0 unused. */
    public static final double[] LEVEL_MS = {0, 8, 15, 25, 40, 60, 90, 130, 180, 250, 350};
    public static final double SOUND_BARRIER_BT = 343.0 / 20.0;

    private SpeedMath() {}

    public static double levelMaxBT(int level) {
        return LEVEL_MS[Mth.clamp(level, 1, 10)] / 20.0 * Config.SPEED_MULTIPLIER.get();
    }

    public static double maxSpeedBT(Player p, SpeedData d) {
        double m = levelMaxBT(d.level);
        SuitType suit = SuitType.worn(p);
        if (suit != null) m *= suit.maxMult;
        if (d.v9Ticks > 0) m *= 1.5;
        if (d.overdriveTicks > 0) m *= 1.3;
        if (d.stolenTicks > 0) m *= 1.0 + d.stolenBonus;
        if (d.whiteUnlocked) m *= 1.1;
        if (d.energy <= 0.5f && d.v9Ticks <= 0) m = Math.min(m, levelMaxBT(3));
        return Math.min(m, Config.MAX_BLOCKS_PER_TICK.get());
    }

    public static double accel(Player p, SpeedData d) {
        double a = 0.022 * effectiveType(p, d).accelMult;
        SuitType suit = SuitType.worn(p);
        if (suit != null) a *= suit.accel;
        if (d.overdriveTicks > 0) a *= 1.5;
        if (d.v9Ticks > 0) a *= 1.3;
        return a;
    }

    public static double control(Player p, SpeedData d) {
        SuitType suit = SuitType.worn(p);
        return suit != null ? suit.control : 1.0;
    }

    public static SpeedForceType effectiveType(Player p, SpeedData d) {
        SuitType suit = SuitType.worn(p);
        if (suit != null && suit.forceOverride != null && d.hasPower) return suit.forceOverride;
        if (d.type == SpeedForceType.NONE) return d.v9Ticks > 0 ? SpeedForceType.V9 : SpeedForceType.SPEED;
        return d.type;
    }

    public static int lightningColor(Player p, SpeedData d) {
        if (d.colorOverride >= 0) return d.colorOverride;
        if (d.v9Ticks > 0) return SpeedForceType.V9.color;
        SuitType suit = SuitType.worn(p);
        if (suit != null) return suit.lightning;
        return effectiveType(p, d).color;
    }

    public static float[] rgb(int color) {
        return new float[]{((color >> 16) & 255) / 255f, ((color >> 8) & 255) / 255f, (color & 255) / 255f};
    }

    public static String colorName(int color) {
        return switch (color) {
            case 0xFFD21F -> "YELLOW";
            case 0xFF2424, 0xFF2A2A -> "RED";
            case 0x3D7BFF, 0x3AA0FF, 0x2F8BFF -> "BLUE";
            case 0xF4F8FF, 0xFFFFFF, 0xF4F4F4 -> "WHITE";
            case 0xFFB01F, 0xFF8C1A -> "ORANGE";
            case 0xB04CFF -> "PURPLE";
            case 0x3DFF6A -> "GREEN";
            case 0xFFE070, 0xFFF06A -> "GOLD";
            case 0xB8E8FF -> "ICE";
            default -> String.format("#%06X", color & 0xFFFFFF);
        };
    }
}
