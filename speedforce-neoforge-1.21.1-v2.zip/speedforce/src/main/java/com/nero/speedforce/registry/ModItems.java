package com.nero.speedforce.registry;

import com.nero.speedforce.SpeedForceMod;
import com.nero.speedforce.data.SpeedForceType;
import com.nero.speedforce.data.SuitType;
import com.nero.speedforce.item.EmptyVialItem;
import com.nero.speedforce.item.FlashRingItem;
import com.nero.speedforce.item.SpeedForceCoreItem;
import com.nero.speedforce.item.SpeedsterSignalItem;
import com.nero.speedforce.item.SuitArmorItem;
import com.nero.speedforce.item.TooltipItem;
import com.nero.speedforce.item.TrainingDeviceItem;
import com.nero.speedforce.item.UnlockItem;
import com.nero.speedforce.item.V9Item;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(SpeedForceMod.MODID);

    // --- origin chain ---
    public static final DeferredItem<Item> EMPTY_DARK_MATTER_VIAL = ITEMS.register("empty_dark_matter_vial",
            () -> new EmptyVialItem(new Item.Properties().stacksTo(16)));
    public static final DeferredItem<Item> DARK_MATTER_VIAL = ITEMS.register("dark_matter_vial",
            () -> new TooltipItem(new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON), "dark_matter_vial", true));
    public static final DeferredItem<Item> SPEED_FORCE_CORE = ITEMS.register("speed_force_core",
            () -> new SpeedForceCoreItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC), SpeedForceType.SPEED));
    public static final DeferredItem<Item> PARTICLE_ACCELERATOR = ITEMS.register("particle_accelerator",
            () -> new BlockItem(ModBlocks.PARTICLE_ACCELERATOR.get(), new Item.Properties().rarity(Rarity.RARE)));

    // --- materials ---
    public static final DeferredItem<Item> SPEED_FORCE_RESIDUE = ITEMS.register("speed_force_residue",
            () -> new TooltipItem(new Item.Properties(), "speed_force_residue", false));
    public static final DeferredItem<Item> TEMPORAL_RESIDUE = ITEMS.register("temporal_residue",
            () -> new TooltipItem(new Item.Properties().rarity(Rarity.UNCOMMON), "temporal_residue", false));

    // --- boss trophies ---
    public static final DeferredItem<Item> NEGATIVE_SPEED_FORCE_CORE = ITEMS.register("negative_speed_force_core",
            () -> new SpeedForceCoreItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant(), SpeedForceType.NEGATIVE));
    public static final DeferredItem<Item> FOREVER_FORCE_FRAGMENT = ITEMS.register("forever_force_fragment",
            () -> new UnlockItem(new Item.Properties().stacksTo(16).rarity(Rarity.EPIC).fireResistant(), UnlockItem.Kind.FOREVER));
    public static final DeferredItem<Item> WHITE_SPEED_CORE = ITEMS.register("white_speed_core",
            () -> new UnlockItem(new Item.Properties().stacksTo(16).rarity(Rarity.EPIC).fireResistant(), UnlockItem.Kind.WHITE));

    // --- gear ---
    public static final DeferredItem<Item> FLASH_RING = ITEMS.register("flash_ring",
            () -> new FlashRingItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final DeferredItem<Item> V9_SERUM = ITEMS.register("v9_serum",
            () -> new V9Item(new Item.Properties().stacksTo(8).rarity(Rarity.RARE)));
    public static final DeferredItem<Item> SPEEDSTER_SIGNAL = ITEMS.register("speedster_signal",
            () -> new SpeedsterSignalItem(new Item.Properties().stacksTo(4).rarity(Rarity.RARE)));
    public static final DeferredItem<Item> SPEED_TRAINING_DEVICE = ITEMS.register("speed_training_device",
            () -> new TrainingDeviceItem(new Item.Properties().stacksTo(1)));
    public static final DeferredItem<Item> RACE_GATE = ITEMS.register("race_gate",
            () -> new BlockItem(ModBlocks.RACE_GATE.get(), new Item.Properties()));
    public static final DeferredItem<Item> SPEED_FORCE_CRYSTAL = ITEMS.register("speed_force_crystal",
            () -> new BlockItem(ModBlocks.SPEED_FORCE_CRYSTAL.get(), new Item.Properties()));

    // --- spawn eggs (creative / map makers) ---
    public static final DeferredItem<Item> REVERSE_FLASH_SPAWN_EGG = ITEMS.register("reverse_flash_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.REVERSE_FLASH, 0x2A0A0A, 0xFF2424, new Item.Properties()));
    public static final DeferredItem<Item> ZOOM_SPAWN_EGG = ITEMS.register("zoom_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.ZOOM, 0x121212, 0x3AA0FF, new Item.Properties()));
    public static final DeferredItem<Item> SAVITAR_SPAWN_EGG = ITEMS.register("savitar_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.SAVITAR, 0x1B3A4A, 0x9FE8FF, new Item.Properties()));
    public static final DeferredItem<Item> BLACK_FLASH_SPAWN_EGG = ITEMS.register("black_flash_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.BLACK_FLASH, 0x0A0A0F, 0x7A1FD0, new Item.Properties()));
    public static final DeferredItem<Item> GODSPEED_SPAWN_EGG = ITEMS.register("godspeed_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.GODSPEED, 0xE8E8E8, 0x8A8A8A, new Item.Properties()));
    public static final DeferredItem<Item> TIME_WRAITH_SPAWN_EGG = ITEMS.register("time_wraith_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.TIME_WRAITH, 0x0E0E14, 0x5AD1FF, new Item.Properties()));

    // --- suits: <suit>_cowl, <suit>_suit, <suit>_leggings, <suit>_boots ---
    public static final Map<SuitType, List<DeferredItem<SuitArmorItem>>> SUITS = new EnumMap<>(SuitType.class);

    static {
        for (SuitType suit : SuitType.values()) {
            List<DeferredItem<SuitArmorItem>> pieces = new ArrayList<>();
            pieces.add(piece(suit, ArmorItem.Type.HELMET, "cowl"));
            pieces.add(piece(suit, ArmorItem.Type.CHESTPLATE, "suit"));
            pieces.add(piece(suit, ArmorItem.Type.LEGGINGS, "leggings"));
            pieces.add(piece(suit, ArmorItem.Type.BOOTS, "boots"));
            SUITS.put(suit, pieces);
        }
    }

    private static DeferredItem<SuitArmorItem> piece(SuitType suit, ArmorItem.Type type, String name) {
        return ITEMS.register(suit.id + "_" + name,
                () -> new SuitArmorItem(ModArmorMaterials.SUITS.get(suit), type, suit, new Item.Properties().durability(type.getDurability(30))));
    }

    private ModItems() {}
}
