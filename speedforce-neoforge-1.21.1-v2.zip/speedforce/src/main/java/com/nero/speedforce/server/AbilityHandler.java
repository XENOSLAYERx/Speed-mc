package com.nero.speedforce.server;

import com.nero.speedforce.Config;
import com.nero.speedforce.data.SpeedData;
import com.nero.speedforce.data.SpeedForceType;
import com.nero.speedforce.data.SpeedMath;
import com.nero.speedforce.data.SuitType;
import com.nero.speedforce.entity.LightningThrowEntity;
import com.nero.speedforce.entity.SpeedsterEntity;
import com.nero.speedforce.entity.TimeWraithEntity;
import com.nero.speedforce.network.Ability;
import com.nero.speedforce.registry.ModAttachments;
import com.nero.speedforce.registry.ModEntities;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

/** Every active ability, validated and executed server-side. */
public final class AbilityHandler {
    private AbilityHandler() {}

    public static void handle(ServerPlayer p, int id, int arg) {
        Ability a = Ability.byId(id);
        if (a == null || !p.isAlive()) return;
        SpeedData d = p.getData(ModAttachments.SPEED);
        if (a == Ability.POWER_TOGGLE) {
            togglePower(p, d);
            return;
        }
        if (!d.isPowered() || p.isSpectator()) return;
        switch (a) {
            case LEVEL_SET -> setLevel(p, d, arg);
            case LIGHTNING -> lightning(p, d, Mth.clamp(arg, 0, 40));
            case BURST -> burst(p, d);
            case PHASE -> togglePhase(p, d);
            case ENTITY_PHASE -> entityPhase(p, d);
            case PERCEPTION -> togglePerception(p, d);
            case SPEED_STEAL -> speedSteal(p, d);
            case DASH -> dash(p, d);
            case TORNADO_START -> tornadoStart(p, d, arg);
            case TORNADO_STOP -> tornadoStop(p, d);
            case MASS_PUNCH -> massPunch(p, d, Mth.clamp(arg, 0, 100));
            case TRAVEL -> TravelManager.use(p, d, false);
            case FOREVER -> toggleForever(p, d);
            case SNAP -> snap(p, d);
            case SUIT_ABILITY -> suitAbility(p, d);
            case IMPACT -> impact(p, d, arg / 100.0);
            default -> { }
        }
    }

    // ------------------------------------------------------------------ helpers

    static void bar(ServerPlayer p, String text, ChatFormatting color) {
        p.displayClientMessage(Component.literal(text).withStyle(color), true);
    }

    public static boolean spend(ServerPlayer p, SpeedData d, float cost) {
        if (d.v9Ticks > 0 || p.getAbilities().instabuild) return true;
        if (d.energy < cost) {
            bar(p, "\u26A1 Not enough Speed Force energy", ChatFormatting.RED);
            return false;
        }
        d.energy -= cost;
        d.markDirty();
        return true;
    }

    /** Targets that area abilities are allowed to hurt: monsters, mobs hunting you, and players where PvP allows. */
    public static boolean hostileTo(ServerPlayer p, Entity e) {
        if (e == p || !(e instanceof LivingEntity) || !e.isAlive() || e.isAlliedTo(p)) return false;
        if (e instanceof TamableAnimal t && t.isTame()) return false;
        if (e instanceof Player other) return p.server.isPvpAllowed() && p.canHarmPlayer(other) && !other.isCreative() && !other.isSpectator();
        if (e instanceof SpeedsterEntity s) return !s.isAlly();
        if (e instanceof Enemy) return true;
        return e instanceof Mob m && m.getTarget() == p;
    }

    static float mult(ServerPlayer p, SpeedData d) {
        return SpeedMath.effectiveType(p, d).damageMult;
    }

    // ------------------------------------------------------------------ toggles

    private static void togglePower(ServerPlayer p, SpeedData d) {
        if (!d.hasPower && d.v9Ticks <= 0) return;
        d.enabled = !d.enabled;
        if (!d.enabled) d.clearActiveStates();
        d.markDirty();
        bar(p, d.enabled ? "\u26A1 SPEED FORCE ONLINE" : "Speed Force offline", d.enabled ? ChatFormatting.GOLD : ChatFormatting.GRAY);
    }

    private static void setLevel(ServerPlayer p, SpeedData d, int level) {
        int clamped = Mth.clamp(level, 1, Config.MAX_SPEED_LEVEL.get());
        if (clamped == d.level) return;
        d.level = clamped;
        d.markDirty();
        bar(p, "SPEED LEVEL " + clamped + "  (" + (int) SpeedMath.LEVEL_MS[clamped] + " m/s)", ChatFormatting.YELLOW);
    }

    private static void togglePhase(ServerPlayer p, SpeedData d) {
        if (d.phasing) {
            if (!p.level().noCollision(p)) {
                bar(p, "\u26A1 Can't stabilize inside solid matter", ChatFormatting.RED);
                return;
            }
            d.phasing = false;
        } else {
            if (d.energy < 5f && d.v9Ticks <= 0 && !p.getAbilities().instabuild) {
                bar(p, "\u26A1 Not enough energy to phase", ChatFormatting.RED);
                return;
            }
            d.phasing = true;
        }
        d.markDirty();
        SpeedSync.sync(p, d, true);
        d.dirty = false;
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ILLUSIONER_MIRROR_MOVE, SoundSource.PLAYERS, 0.8f, d.phasing ? 2.0f : 1.2f);
        bar(p, d.phasing ? "PHASING" : "Solid", d.phasing ? ChatFormatting.AQUA : ChatFormatting.GRAY);
    }

    private static void entityPhase(ServerPlayer p, SpeedData d) {
        if (!spend(p, d, 12f)) return;
        d.entityPhaseTicks = 60;
        d.markDirty();
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ILLUSIONER_MIRROR_MOVE, SoundSource.PLAYERS, 0.7f, 1.7f);
        bar(p, "Vibrating: attacks pass through you", ChatFormatting.AQUA);
    }

    private static void togglePerception(ServerPlayer p, SpeedData d) {
        if (d.perception) {
            d.perception = false;
        } else {
            if (d.energy < 10f && d.v9Ticks <= 0 && !p.getAbilities().instabuild) {
                bar(p, "\u26A1 Not enough energy", ChatFormatting.RED);
                return;
            }
            d.perception = true;
            p.playNotifySound(SoundEvents.WARDEN_HEARTBEAT, SoundSource.PLAYERS, 1.0f, 0.6f);
        }
        d.markDirty();
    }

    private static void toggleForever(ServerPlayer p, SpeedData d) {
        if (!d.foreverUnlocked) {
            bar(p, "The Forever Force has not chosen you (defeat Zoom)", ChatFormatting.GRAY);
            return;
        }
        if (!d.foreverActive && d.energy < 20f && d.v9Ticks <= 0 && !p.getAbilities().instabuild) {
            bar(p, "\u26A1 Not enough energy", ChatFormatting.RED);
            return;
        }
        d.foreverActive = !d.foreverActive;
        d.markDirty();
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.0f, d.foreverActive ? 0.5f : 1.5f);
        bar(p, d.foreverActive ? "FOREVER FORCE: the world stops" : "Forever Force released", ChatFormatting.AQUA);
    }

    // ------------------------------------------------------------------ attacks

    private static void lightning(ServerPlayer p, SpeedData d, int charge) {
        if (!spend(p, d, 6f + charge * 0.3f)) return;
        fireBolt(p, d, charge, 0f);
    }

    private static void fireBolt(ServerPlayer p, SpeedData d, int charge, float yawOffset) {
        SpeedForceType type = SpeedMath.effectiveType(p, d);
        float damage = (5f + charge * 0.35f + d.level * 0.4f) * type.damageMult;
        float aoe = type == SpeedForceType.NEGATIVE ? 3.5f : 2.0f;
        LightningThrowEntity bolt = LightningThrowEntity.fromPlayer(p, d, damage, aoe);
        bolt.shootFromRotation(p, p.getXRot(), p.getYRot() + yawOffset, 0f, 3.2f + charge * 0.05f, 0.1f);
        p.level().addFreshEntity(bolt);
        p.swing(InteractionHand.MAIN_HAND, true);
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 0.9f, 1.7f);
    }

    private static void burst(ServerPlayer p, SpeedData d) {
        if (!spend(p, d, 22f)) return;
        ServerLevel level = p.serverLevel();
        int color = SpeedMath.lightningColor(p, d);
        double r = 6 + d.level * 0.25;
        float damage = (6f + d.level * 0.6f) * mult(p, d);
        Vec3 center = p.position().add(0, 1, 0);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(r),
                e -> hostileTo(p, e) && e.distanceToSqr(p) <= r * r)) {
            e.hurt(level.damageSources().indirectMagic(p, p), damage);
            e.knockback(1.3, p.getX() - e.getX(), p.getZ() - e.getZ());
            e.hurtMarked = true;
            e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 50, 3));
            e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 50, 1));
            ServerFx.arc(level, center, e.position().add(0, e.getBbHeight() * 0.5, 0), color);
        }
        ServerFx.ring(level, p.position().add(0, 0.2, 0), r * 0.6, color, 36);
        ServerFx.ring(level, p.position().add(0, 0.2, 0), r, color, 48);
        ServerFx.burst(level, center, color, 40);
        level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 2.0f, 0.8f);
        ServerFx.shake(p, 3f);
    }

    private static void speedSteal(ServerPlayer p, SpeedData d) {
        if (!spend(p, d, 15f)) return;
        ServerLevel level = p.serverLevel();
        double range = 24;
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getViewVector(1f);
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(p, eye, eye.add(look.scale(range)),
                p.getBoundingBox().expandTowards(look.scale(range)).inflate(1.5),
                e -> e instanceof LivingEntity && e != p && !e.isSpectator() && e.isPickable(), range * range);
        if (hit == null || !(hit.getEntity() instanceof LivingEntity target)) {
            d.energy = Math.min(100f, d.energy + 15f);
            bar(p, "No target to steal speed from", ChatFormatting.GRAY);
            return;
        }
        boolean negative = SpeedMath.effectiveType(p, d) == SpeedForceType.NEGATIVE;
        float gain = (float) Mth.clamp(target.getAttributeValue(Attributes.MOVEMENT_SPEED) * 1.2, 0.10, 0.45);
        if (target instanceof SpeedsterEntity || target instanceof TimeWraithEntity) gain = 0.5f;
        if (target instanceof ServerPlayer tp) {
            SpeedData td = tp.getData(ModAttachments.SPEED);
            if (td.isPowered()) {
                float drained = Math.min(td.energy, negative ? 60f : 40f);
                td.energy -= drained;
                td.markDirty();
                d.energy = Math.min(100f, d.energy + drained * 0.5f);
                gain = 0.5f;
                tp.displayClientMessage(Component.literal("\u26A1 Your speed is being stolen!").withStyle(ChatFormatting.RED), true);
            }
        }
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 200, negative ? 4 : 2));
        target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 200, 0));
        if (negative) target.hurt(level.damageSources().indirectMagic(p, p), 6f);

        d.stolenBonus = d.stolenTicks > 0 ? Math.max(d.stolenBonus, gain) : gain;
        d.stolenTicks = 300;
        d.energy = Math.min(100f, d.energy + 20f);
        d.markDirty();

        int color = SpeedMath.lightningColor(p, d);
        Vec3 from = target.position().add(0, target.getBbHeight() * 0.5, 0);
        Vec3 to = p.position().add(0, 1, 0);
        ServerFx.arc(level, from, to, color);
        ServerFx.arc(level, from, to, color);
        ServerFx.burst(level, from, color, 16);
        level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 1.0f, 1.8f);
        bar(p, String.format("\u26A1 Speed stolen: +%d%% top speed", Math.round(d.stolenBonus * 100)), ChatFormatting.GOLD);
    }

    private static void dash(ServerPlayer p, SpeedData d) {
        if (!spend(p, d, d.blitzTicks > 0 ? 0f : 10f)) return;
        ServerLevel level = p.serverLevel();
        int color = SpeedMath.lightningColor(p, d);
        level.sendParticles(ServerFx.dust(color, 1.4f), p.getX(), p.getY() + 1, p.getZ(), 24, 0.3, 0.7, 0.3, 0);
        level.sendParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 0.2, p.getZ(), 8, 0.3, 0.1, 0.3, 0.05);
        level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ILLUSIONER_MIRROR_MOVE, SoundSource.PLAYERS, 1.0f, 1.5f);
    }

    private static void massPunch(ServerPlayer p, SpeedData d, int charge) {
        if (charge < 15) return;
        if (!spend(p, d, 20f + charge * 0.2f)) return;
        d.massPunchTicks = 16;
        d.massPunchPower = charge;
        d.markDirty();
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.WARDEN_SONIC_CHARGE, SoundSource.PLAYERS, 1.0f, 1.4f);
    }

    public static void tickMassPunch(ServerPlayer p, SpeedData d) {
        d.massPunchTicks--;
        ServerLevel level = p.serverLevel();
        int color = SpeedMath.lightningColor(p, d);
        level.sendParticles(ServerFx.dust(color, 1.3f), p.getX(), p.getY() + 1, p.getZ(), 6, 0.3, 0.5, 0.3, 0);
        Vec3 look = p.getLookAngle();
        AABB box = p.getBoundingBox().inflate(1.2).expandTowards(look.scale(2.0));
        List<LivingEntity> hits = level.getEntitiesOfClass(LivingEntity.class, box, e -> e != p && e.isAlive() && !e.isAlliedTo(p));
        if (!hits.isEmpty()) {
            hits.sort(Comparator.comparingDouble(e -> e.distanceToSqr(p)));
            massImpact(p, d, hits.get(0).position(), hits.get(0));
        } else if (p.horizontalCollision && d.massPunchTicks < 14) {
            massImpact(p, d, p.position().add(look.multiply(1, 0, 1).normalize()), null);
        } else if (d.massPunchTicks <= 0) {
            d.massPunchTicks = 0;
            d.markDirty();
        }
    }

    private static void massImpact(ServerPlayer p, SpeedData d, Vec3 at, LivingEntity primary) {
        d.massPunchTicks = 0;
        d.markDirty();
        ServerLevel level = p.serverLevel();
        int color = SpeedMath.lightningColor(p, d);
        float power = d.massPunchPower;
        float damage = (12f + power * 0.5f) * mult(p, d) * (float) (0.6 + d.level * 0.06);
        double radius = 3.0 + power / 25.0;
        Vec3 look = p.getLookAngle().multiply(1, 0, 1).normalize();
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(at, at).inflate(radius),
                e -> e != p && e.isAlive() && !e.isAlliedTo(p))) {
            boolean main = e == primary;
            if (!main && !hostileTo(p, e)) continue;
            e.hurt(level.damageSources().indirectMagic(p, p), main ? damage : damage * 0.5f);
            Vec3 dir = main ? look : e.position().subtract(at).multiply(1, 0, 1).normalize();
            double force = main ? 3.0 + power / 40.0 : 1.5;
            e.push(dir.x * force, 0.8, dir.z * force);
            e.hurtMarked = true;
        }
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, at.x, at.y + 0.5, at.z, 1, 0, 0, 0, 0);
        level.sendParticles(ParticleTypes.SONIC_BOOM, at.x, at.y + 1, at.z, 1, 0, 0, 0, 0);
        ServerFx.ring(level, at.add(0, 0.2, 0), radius, color, 60);
        ServerFx.burst(level, at.add(0, 1, 0), color, 60);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 2.0f, 0.7f);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 2.0f, 1.0f);
        ServerFx.shakeNearby(level, at, 32, 8f);

        if (Config.MASS_PUNCH_DESTRUCTION.get()) {
            double cr = Math.min(3.5, 1.0 + power / 40.0);
            BlockPos c = BlockPos.containing(at);
            int ir = (int) Math.ceil(cr);
            for (BlockPos bp : BlockPos.betweenClosed(c.offset(-ir, -ir, -ir), c.offset(ir, ir, ir))) {
                if (bp.distSqr(c) > cr * cr) continue;
                BlockState s = level.getBlockState(bp);
                float hardness = s.getDestroySpeed(level, bp);
                if (s.isAir() || hardness < 0 || hardness > 50 || s.hasBlockEntity()) continue;
                level.destroyBlock(bp, false, p);
            }
        }
    }

    private static void snap(ServerPlayer p, SpeedData d) {
        if (!d.foreverUnlocked) return;
        if (!spend(p, d, 30f)) return;
        ServerLevel level = p.serverLevel();
        double r = 12;
        float damage = 14f * mult(p, d);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(r),
                e -> hostileTo(p, e) && e.distanceToSqr(p) <= r * r)) {
            e.hurt(level.damageSources().indirectMagic(p, p), damage);
            e.knockback(2.2, p.getX() - e.getX(), p.getZ() - e.getZ());
            e.hurtMarked = true;
        }
        ServerFx.ring(level, p.position().add(0, 1, 0), 4, 0xFFFFFF, 40);
        ServerFx.ring(level, p.position().add(0, 1, 0), 8, 0x7FE8FF, 60);
        ServerFx.ring(level, p.position().add(0, 1, 0), 12, 0xFFFFFF, 80);
        level.sendParticles(ParticleTypes.FLASH, p.getX(), p.getY() + 1, p.getZ(), 1, 0, 0, 0, 0);
        level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.PLAYER_ATTACK_CRIT, SoundSource.PLAYERS, 2.0f, 2.0f);
        level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 1.5f, 1.6f);
        ServerFx.shakeNearby(level, p.position(), 24, 6f);
        d.foreverActive = false;
        d.instability += 20f;
        d.markDirty();
    }

    // ------------------------------------------------------------------ tornado / vortex

    private static void tornadoStart(ServerPlayer p, SpeedData d, int targetId) {
        if (d.energy < 10f && d.v9Ticks <= 0 && !p.getAbilities().instabuild) {
            bar(p, "\u26A1 Not enough energy", ChatFormatting.RED);
            return;
        }
        d.tornado = true;
        d.vortexTarget = -1;
        d.vortexCharge = 0;
        if (targetId >= 0) {
            Entity e = p.level().getEntity(targetId);
            if (e instanceof LivingEntity le && le.isAlive() && le.distanceTo(p) < 20) d.vortexTarget = targetId;
        }
        d.markDirty();
    }

    public static void tickTornado(ServerPlayer p, SpeedData d) {
        ServerLevel level = p.serverLevel();
        int color = SpeedMath.lightningColor(p, d);
        long t = level.getGameTime();
        if (d.vortexTarget >= 0) {
            Entity e = level.getEntity(d.vortexTarget);
            if (!(e instanceof LivingEntity target) || !target.isAlive() || target.distanceTo(p) > 24) {
                d.vortexTarget = -1;
                d.tornado = false;
                d.markDirty();
                return;
            }
            d.vortexCharge = Math.min(100f, d.vortexCharge + 1f);
            Vec3 v = target.getDeltaMovement();
            target.setDeltaMovement(v.x * 0.2, target.getY() < p.getY() + 3 ? 0.12 : 0.0, v.z * 0.2);
            target.hurtMarked = true;
            target.fallDistance = 0;
            if (t % 10 == 0) target.hurt(level.damageSources().indirectMagic(p, p), 1.5f);
            spiral(level, target.position(), 1.4, color, t);
            return;
        }
        double r = 6 + d.level * 0.3;
        for (Entity e : level.getEntities(p, p.getBoundingBox().inflate(r, 6, r),
                e -> e instanceof ItemEntity || hostileTo(p, e))) {
            Vec3 rel = new Vec3(e.getX() - p.getX(), 0, e.getZ() - p.getZ());
            double dist = rel.length();
            if (dist < 0.5 || dist > r) continue;
            Vec3 n = rel.scale(1 / dist);
            Vec3 tan = new Vec3(-n.z, 0, n.x);
            double up = e.getY() < p.getY() + 4 + d.level * 0.3 ? 0.16 : 0.02;
            Vec3 vel = tan.scale(0.5 + d.level * 0.03).add(n.scale(-0.12));
            e.setDeltaMovement(vel.x, up, vel.z);
            e.hurtMarked = true;
            e.fallDistance = 0;
            e.clearFire();
        }
        if (t % 10 == 0) {
            BlockPos c = p.blockPosition();
            for (BlockPos bp : BlockPos.betweenClosed(c.offset(-4, -2, -4), c.offset(4, 3, 4))) {
                if (level.getBlockState(bp).getBlock() instanceof BaseFireBlock) level.removeBlock(bp, false);
            }
        }
        spiral(level, p.position(), 0.8, color, t);
    }

    private static void spiral(ServerLevel level, Vec3 c, double base, int color, long t) {
        for (int i = 0; i < 10; i++) {
            double h = i * 0.5;
            double a = t * 0.7 + i * 0.9;
            double rad = base + h * 0.45;
            level.sendParticles(ParticleTypes.CLOUD, c.x + Math.cos(a) * rad, c.y + h, c.z + Math.sin(a) * rad, 1, 0, 0, 0, 0);
            if (i % 2 == 0) {
                level.sendParticles(ServerFx.dust(color, 0.9f), c.x + Math.cos(a + Math.PI) * rad, c.y + h, c.z + Math.sin(a + Math.PI) * rad, 1, 0, 0, 0, 0);
            }
        }
    }

    private static void tornadoStop(ServerPlayer p, SpeedData d) {
        if (!d.tornado) return;
        ServerLevel level = p.serverLevel();
        int color = SpeedMath.lightningColor(p, d);
        if (d.vortexTarget >= 0 && level.getEntity(d.vortexTarget) instanceof LivingEntity target && target.isAlive()) {
            float damage = Math.min(60f, (6f + d.vortexCharge * 0.4f) * mult(p, d));
            target.hurt(level.damageSources().indirectMagic(p, p), damage);
            Vec3 away = target.position().subtract(p.position()).multiply(1, 0, 1).normalize();
            target.push(away.x * 2.5, 0.9, away.z * 2.5);
            target.hurtMarked = true;
            level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, target.getX(), target.getY() + 1, target.getZ(), 1, 0, 0, 0, 0);
            ServerFx.burst(level, target.position().add(0, 1, 0), color, 50);
            level.playSound(null, target.getX(), target.getY(), target.getZ(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 1.5f, 1.3f);
            ServerFx.shake(p, 6f);
            bar(p, String.format("SPEED VORTEX: %.0f damage", damage), ChatFormatting.GOLD);
        } else {
            double r = 6 + d.level * 0.3;
            for (Entity e : level.getEntities(p, p.getBoundingBox().inflate(r, 8, r), e -> hostileTo(p, e))) {
                Vec3 out = new Vec3(e.getX() - p.getX(), 0, e.getZ() - p.getZ()).normalize();
                e.push(out.x * 1.4, 0.6, out.z * 1.4);
                e.hurtMarked = true;
                e.hurt(level.damageSources().indirectMagic(p, p), 4f * mult(p, d));
            }
            ServerFx.ring(level, p.position().add(0, 0.5, 0), r, color, 48);
        }
        d.tornado = false;
        d.vortexTarget = -1;
        d.vortexCharge = 0;
        d.markDirty();
    }

    // ------------------------------------------------------------------ suit abilities

    private static void suitAbility(ServerPlayer p, SpeedData d) {
        SuitType suit = SuitType.worn(p);
        if (suit == null) {
            bar(p, "Wear a full speedster suit to use its ability", ChatFormatting.GRAY);
            return;
        }
        ServerLevel level = p.serverLevel();
        int color = SpeedMath.lightningColor(p, d);
        float m = mult(p, d);
        switch (suit) {
            case FLASH -> {
                if (!spend(p, d, 25f)) return;
                for (float off : new float[]{-16f, -8f, 0f, 8f, 16f}) fireBolt(p, d, 24, off);
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 1));
                ServerFx.ring(level, p.position().add(0, 0.2, 0), 3, color, 36);
                level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 0.8f, 1.7f);
            }
            case WALLY_WEST -> {
                if (!spend(p, d, 25f)) return;
                d.overdriveTicks = 300;
                p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 0));
                ServerFx.ring(level, p.position().add(0, 0.2, 0), 2.5, color, 30);
                ServerFx.ring(level, p.position().add(0, 1.0, 0), 2.0, color, 30);
            }
            case JAY_GARRICK -> {
                if (!spend(p, d, 25f)) return;
                p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 240, 1));
                p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 240, 0));
                p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 400, 1));
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(4), e -> hostileTo(p, e))) {
                    e.hurt(level.damageSources().indirectMagic(p, p), 6f * m);
                    Vec3 dir = e.position().subtract(p.position()).multiply(1, 0, 1).normalize();
                    e.push(dir.x * 1.5, 0.35, dir.z * 1.5);
                    e.hurtMarked = true;
                }
                ServerFx.ring(level, p.position().add(0, 0.3, 0), 4, color, 48);
                level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 0.7f, 1.4f);
            }
            case KID_FLASH -> {
                if (!spend(p, d, 20f)) return;
                d.blitzTicks = 160;
                p.addEffect(new MobEffectInstance(MobEffects.JUMP, 160, 2));
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 160, 1));
            }
            case REVERSE_FLASH -> {
                if (!spend(p, d, 35f)) return;
                List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(16), e -> hostileTo(p, e));
                targets.sort(Comparator.comparingDouble(e -> e.distanceToSqr(p)));
                Vec3 from = p.position().add(0, 1.2, 0);
                float healed = 0f;
                for (int i = 0; i < Math.min(8, targets.size()); i++) {
                    LivingEntity e = targets.get(i);
                    Vec3 to = e.position().add(0, e.getBbHeight() * 0.5, 0);
                    ServerFx.arc(level, from, to, color);
                    if (e.hurt(level.damageSources().indirectMagic(p, p), 9f * m)) healed += 1f;
                    e.addEffect(new MobEffectInstance(MobEffects.WITHER, 60, 0));
                    from = to;
                }
                p.heal(Math.min(healed, 8f));
                level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 1.2f, 1.6f);
            }
            case ZOOM -> {
                if (!spend(p, d, 30f)) return;
                d.freezeTicks = 160;
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(14), e -> hostileTo(p, e))) {
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 4));
                    e.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0));
                }
                ServerFx.ring(level, p.position().add(0, 0.3, 0), 14, color, 90);
                p.playNotifySound(SoundEvents.WARDEN_HEARTBEAT, SoundSource.PLAYERS, 1.0f, 0.5f);
            }
            case GODSPEED -> {
                if (!spend(p, d, 40f)) return;
                for (int i = 0; i < 3; i++) {
                    SpeedsterEntity clone = ModEntities.SPEED_CLONE.get().create(level);
                    if (clone == null) continue;
                    double a = p.getYRot() * Mth.DEG_TO_RAD + (i - 1) * 1.4;
                    clone.moveTo(p.getX() + Math.cos(a) * 1.5, p.getY(), p.getZ() + Math.sin(a) * 1.5, p.getYRot(), 0);
                    clone.makeAllyOf(p, 300);
                    level.addFreshEntity(clone);
                    ServerFx.burst(level, clone.position().add(0, 1, 0), color, 16);
                }
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, 1));
            }
            case SAVITAR -> {
                if (!spend(p, d, 35f)) return;
                d.armoredTicks = 80;
                p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 200, 2));
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(4), e -> hostileTo(p, e))) {
                    e.hurt(level.damageSources().indirectMagic(p, p), 7f * m);
                    Vec3 dir = e.position().subtract(p.position()).multiply(1, 0, 1).normalize();
                    e.push(dir.x * 1.8, 0.5, dir.z * 1.8);
                    e.hurtMarked = true;
                }
                ServerFx.ring(level, p.position().add(0, 0.3, 0), 4, color, 48);
                level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 1.0f, 0.6f);
            }
            case IMPULSE -> {
                if (!spend(p, d, 25f)) return;
                d.blitzTicks = 200;
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 3));
                p.addEffect(new MobEffectInstance(MobEffects.JUMP, 200, 1));
                ServerFx.burst(level, p.position().add(0, 1, 0), color, 30);
            }
            case MAX_MERCURY -> {
                if (!spend(p, d, 30f)) return;
                p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 160, 2));
                p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 300, 2));
                p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 160, 0));
                for (MobEffectInstance inst : new java.util.ArrayList<>(p.getActiveEffects())) {
                    if (inst.getEffect().value().getCategory() == MobEffectCategory.HARMFUL) p.removeEffect(inst.getEffect());
                }
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(6), e -> hostileTo(p, e))) {
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
                }
                ServerFx.ring(level, p.position().add(0, 0.2, 0), 2, color, 24);
                ServerFx.ring(level, p.position().add(0, 1.0, 0), 1.5, color, 24);
            }
            case JESSE_QUICK -> {
                if (!spend(p, d, 30f)) return;
                List<LivingEntity> near = level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(7), e -> hostileTo(p, e));
                near.sort(Comparator.comparingDouble(e -> e.distanceToSqr(p)));
                for (int i = 0; i < near.size(); i++) {
                    LivingEntity e = near.get(i);
                    e.hurt(level.damageSources().indirectMagic(p, p), 12f * m);
                    Vec3 dir = e.position().subtract(p.position()).multiply(1, 0, 1).normalize();
                    e.push(dir.x * 2.0, 0.5, dir.z * 2.0);
                    e.hurtMarked = true;
                    if (i < 4) ServerFx.arc(level, p.position().add(0, 1.2, 0), e.position().add(0, e.getBbHeight() * 0.5, 0), color);
                }
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, 1));
                ServerFx.ring(level, p.position().add(0, 0.3, 0), 7, color, 70);
                level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 1.0f, 1.6f);
            }
            case INERTIA -> {
                if (!spend(p, d, 35f)) return;
                float healed = 0f;
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(10), e -> hostileTo(p, e))) {
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 120, 3));
                    e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 120, 1));
                    Vec3 pull = p.position().subtract(e.position()).multiply(1, 0, 1).normalize();
                    e.push(pull.x * 0.8, 0.15, pull.z * 0.8);
                    e.hurtMarked = true;
                    ServerFx.arc(level, e.position().add(0, 1, 0), p.position().add(0, 1, 0), color);
                    healed += 2f;
                }
                p.heal(Math.min(healed, 14f));
                p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 120, 1));
            }
        }
        d.markDirty();
        ServerFx.burst(level, p.position().add(0, 1, 0), color, 20);
        bar(p, "[Y] " + suit.abilityName, ChatFormatting.GOLD);
    }

    public static void tickArmoredCharge(ServerPlayer p, SpeedData d) {
        ServerLevel level = p.serverLevel();
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(1.3), e -> hostileTo(p, e))) {
            if (e.hurt(level.damageSources().indirectMagic(p, p), 6f)) {
                Vec3 dir = e.position().subtract(p.position()).multiply(1, 0, 1).normalize();
                e.push(dir.x * 2.0, 0.5, dir.z * 2.0);
                e.hurtMarked = true;
            }
        }
        level.sendParticles(ServerFx.dust(SpeedMath.lightningColor(p, d), 1.0f), p.getX(), p.getY() + 1, p.getZ(), 4, 0.4, 0.6, 0.4, 0);
    }

    // ------------------------------------------------------------------ collisions

    private static void impact(ServerPlayer p, SpeedData d, double speed) {
        if (!Config.COLLISION_DAMAGE.get() || speed < 2.0 || d.phasing || d.armoredTicks > 0) return;
        if (Math.abs(speed - d.serverSpeed) > 6.0 && d.serverSpeed < 1.0) return;
        SuitType suit = SuitType.worn(p);
        float resist = suit != null ? suit.collisionResist : 0f;
        float damage = (float) ((speed - 2.0) * 1.5 * Config.COLLISION_MULTIPLIER.get()) * (1f - resist);
        damage = Math.min(damage, 12f);
        if (damage >= 0.5f) {
            p.hurt(p.damageSources().flyIntoWall(), damage);
            p.serverLevel().sendParticles(ParticleTypes.POOF, p.getX(), p.getY() + 1, p.getZ(), 10, 0.3, 0.5, 0.3, 0.05);
        }
    }
}
