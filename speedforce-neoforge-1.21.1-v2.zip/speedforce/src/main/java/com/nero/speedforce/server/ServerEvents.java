package com.nero.speedforce.server;

import com.nero.speedforce.Config;
import com.nero.speedforce.SpeedForceMod;
import com.nero.speedforce.data.SpeedData;
import com.nero.speedforce.data.SpeedForceType;
import com.nero.speedforce.data.SpeedMath;
import com.nero.speedforce.data.SuitType;
import com.nero.speedforce.registry.ModAttachments;
import com.nero.speedforce.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.ProjectileImpactEvent;
import net.neoforged.neoforge.event.entity.living.LivingFallEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

@EventBusSubscriber(modid = SpeedForceMod.MODID)
public final class ServerEvents {
    /** Lightning bolts we spawn ourselves carry this tag so they don't fill vials. */
    public static final String NO_FILL_TAG = "speedforce_no_fill";

    private ServerEvents() {}

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (event.getEntity() instanceof ServerPlayer sp) PowerTicker.tick(sp);
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        PerceptionManager.serverTick();
    }

    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        LivingEntity target = event.getEntity();
        if (target.level().isClientSide) return;
        DamageSource source = event.getSource();

        // defensive powers
        if (target instanceof ServerPlayer tp) {
            SpeedData td = tp.getData(ModAttachments.SPEED);
            if (td.isPowered()) {
                if (td.phasing && (source.is(DamageTypes.IN_WALL) || source.is(DamageTypes.CRAMMING))) {
                    event.setCanceled(true);
                    return;
                }
                if (td.armoredTicks > 0 && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
                    event.setCanceled(true);
                    return;
                }
                Entity direct = source.getDirectEntity();
                if (td.entityPhaseTicks > 0 && direct != null && direct != tp) {
                    tp.serverLevel().sendParticles(ParticleTypes.ELECTRIC_SPARK, tp.getX(), tp.getY() + 1, tp.getZ(), 8, 0.3, 0.5, 0.3, 0.1);
                    event.setCanceled(true);
                    return;
                }
            }
        }

        // supersonic / phase punches
        if (source.getDirectEntity() instanceof ServerPlayer attacker && source.is(DamageTypes.PLAYER_ATTACK) && attacker != target) {
            SpeedData ad = attacker.getData(ModAttachments.SPEED);
            if (!ad.isPowered()) return;
            ServerLevel level = attacker.serverLevel();
            SpeedForceType type = SpeedMath.effectiveType(attacker, ad);
            int color = SpeedMath.lightningColor(attacker, ad);
            float amount = event.getAmount();
            if (ad.phasing) {
                amount *= 1.75f;
                level.sendParticles(ParticleTypes.ENCHANTED_HIT, target.getX(), target.getY() + 1, target.getZ(), 12, 0.3, 0.5, 0.3, 0.2);
            }
            double speed = ad.serverSpeed;
            if (speed > 0.8) {
                amount += (float) ((2.0 + speed * 1.6) * type.damageMult * Config.SUPERSONIC_MULTIPLIER.get());
                Vec3 dir = attacker.getLookAngle().multiply(1, 0, 1).normalize();
                target.knockback(Math.min(0.6 + speed * 0.35, 5.0), -dir.x, -dir.z);
                target.hurtMarked = true;
                Vec3 at = target.position().add(0, target.getBbHeight() * 0.5, 0);
                level.sendParticles(ParticleTypes.FLASH, at.x, at.y, at.z, 1, 0, 0, 0, 0);
                ServerFx.burst(level, at, color, 20);
                if (speed > 4) {
                    level.sendParticles(ParticleTypes.SONIC_BOOM, at.x, at.y, at.z, 1, 0, 0, 0, 0);
                    level.playSound(null, at.x, at.y, at.z, SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 1.2f, 1.4f);
                } else {
                    level.playSound(null, at.x, at.y, at.z, SoundEvents.PLAYER_ATTACK_KNOCKBACK, SoundSource.PLAYERS, 1.2f, 0.8f);
                }
                ServerFx.shake(attacker, (float) Math.min(6.0, 1.0 + speed * 0.4));
                Training.complete(attacker, ad, Training.SUPERSONIC);
                if (SuitType.worn(attacker) == SuitType.SAVITAR) {
                    float splash = amount * 0.4f;
                    for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, target.getBoundingBox().inflate(3),
                            e -> e != target && AbilityHandler.hostileTo(attacker, e))) {
                        e.hurt(level.damageSources().indirectMagic(attacker, attacker), splash);
                    }
                    ServerFx.ring(level, target.position().add(0, 0.3, 0), 3, color, 30);
                }
            }
            event.setAmount(amount);
        }
    }

    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (event.getEntity() instanceof Player p && p.getData(ModAttachments.SPEED).isPowered()) {
            event.setDamageMultiplier(event.getDamageMultiplier() * 0.35f);
        }
    }

    @SubscribeEvent
    public static void onProjectileImpact(ProjectileImpactEvent event) {
        Projectile projectile = event.getProjectile();
        if (projectile.level().isClientSide) return;
        if (!(event.getRayTraceResult() instanceof EntityHitResult hit) || !(hit.getEntity() instanceof ServerPlayer p)) return;
        if (projectile.getOwner() == p) return;
        SpeedData d = p.getData(ModAttachments.SPEED);
        if (!d.isPowered()) return;
        boolean perceiving = d.perception || d.freezeTicks > 0 || d.foreverActive;
        boolean dodge = perceiving || d.phasing || d.entityPhaseTicks > 0
                || (d.level >= 8 && d.serverSpeed > 3.0 && p.getRandom().nextFloat() < 0.5f);
        if (dodge) {
            event.setCanceled(true);
            p.serverLevel().sendParticles(ServerFx.dust(SpeedMath.lightningColor(p, d), 0.8f), p.getX(), p.getY() + 1, p.getZ(), 6, 0.3, 0.5, 0.3, 0);
            if (perceiving) Training.complete(p, d, Training.PERCEPTION_DODGE);
        }
    }

    /** Natural lightning near a player holding an Empty Dark-Matter Vial fills it. */
    @SubscribeEvent
    public static void onEntityJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide() || !(event.getEntity() instanceof LightningBolt bolt) || bolt.getTags().contains(NO_FILL_TAG)) return;
        for (Player player : event.getLevel().players()) {
            if (player.distanceToSqr(bolt) > 24 * 24) continue;
            for (InteractionHand hand : InteractionHand.values()) {
                ItemStack stack = player.getItemInHand(hand);
                if (stack.is(ModItems.EMPTY_DARK_MATTER_VIAL.get())) {
                    stack.shrink(1);
                    ItemStack filled = new ItemStack(ModItems.DARK_MATTER_VIAL.get());
                    if (!player.getInventory().add(filled)) player.drop(filled, false);
                    player.displayClientMessage(Component.translatable("message.speedforce.vial_filled").withStyle(ChatFormatting.YELLOW), true);
                    break;
                }
            }
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) reset(sp);
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) reset(sp);
    }

    @SubscribeEvent
    public static void onChangeDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            SpeedData d = sp.getData(ModAttachments.SPEED);
            d.lastPos = null;
            SpeedSync.sync(sp, d, true);
        }
    }

    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking event) {
        if (event.getTarget() instanceof ServerPlayer subject && event.getEntity() instanceof ServerPlayer viewer) {
            SpeedSync.sendTo(subject, viewer);
        }
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        SpeedForceCommand.register(event.getDispatcher());
    }

    private static void reset(ServerPlayer sp) {
        SpeedData d = sp.getData(ModAttachments.SPEED);
        d.clearActiveStates();
        d.lastPos = null;
        d.serverSpeed = 0;
        SpeedSync.sync(sp, d, true);
        d.dirty = false;
    }
}
