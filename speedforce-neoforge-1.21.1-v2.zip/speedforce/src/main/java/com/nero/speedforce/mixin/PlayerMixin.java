package com.nero.speedforce.mixin;

import com.nero.speedforce.SpeedForceHooks;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Player.tick() resets noPhysics to isSpectator() every tick. Right before the LivingEntity tick
 * (which moves the player) we switch collisions off for phasing speedsters, on both sides.
 */
@Mixin(Player.class)
public abstract class PlayerMixin {
    @Inject(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;tick()V"))
    private void speedforce$phaseThroughBlocks(CallbackInfo ci) {
        Player self = (Player) (Object) this;
        if (SpeedForceHooks.isPhasing(self)) self.noPhysics = true;
    }
}
