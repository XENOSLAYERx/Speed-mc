package com.nero.speedforce.client;

import com.nero.speedforce.SpeedForceMod;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.client.gui.ConfigurationScreen;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;

/** Client-only entrypoint: client config + in-game config screen (Mods > Speed Force > Config). */
@Mod(value = SpeedForceMod.MODID, dist = Dist.CLIENT)
public class SpeedForceClient {
    public SpeedForceClient(ModContainer container) {
        container.registerConfig(ModConfig.Type.CLIENT, ClientConfig.SPEC);
        container.registerExtensionPoint(IConfigScreenFactory.class, ConfigurationScreen::new);
    }
}
