package com.nero.speedforce.server;

import com.nero.speedforce.Config;
import com.nero.speedforce.SpeedForceMod;
import com.nero.speedforce.data.SpeedData;
import com.nero.speedforce.data.SpeedForceType;
import com.nero.speedforce.data.SpeedMath;
import com.nero.speedforce.data.SuitType;
import com.nero.speedforce.entity.TimeWraithEntity;
import com.nero.speedforce.network.FxPayload;
import com.nero.speedforce.registry.ModAttachments;
import com.nero.speedforce.registry.ModEntities;
import com.nero.speedforce.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

/** Everything a speedster does every server tick: energy, metabolism, active powers, world interaction. */
public final class PowerTicker {
    private static final ResourceLocation STEP_ID = SpeedForceMod.rl("speedster_step");
    private static final ResourceLocation ATTACK_SPEED_ID = SpeedForceMod.rl("speedster_attack_speed");
    private static final ResourceLocation ATTACK_DAMAGE_ID = SpeedForceMod.rl("speedster_attack_damage");
    private static final ResourceLocation SAFE_FALL_ID = SpeedForceMod.rl("speedster_safe_fall");

    private PowerTicker() {}

    public static void tick(ServerPlayer p) {
        SpeedData d = p.getData(ModAttachments.SPEED);
        ServerLevel level = p.serverLevel();

        // measure real speed from accepted movement
        Vec3 pos = p.position();
        Vec3 prev = d.lastPos;
        if (prev != null && level.dimension().equals(d.lastDim)) {
            double dist = Math.hypot(pos.x - prev.x, pos.z - prev.z);
            if (dist > 40) {
                dist = 0;
                prev = null;
            }
            d.serverSpeed = Math.max(dist, d.serverSpeed * 0.75);
        } else {
            d.serverSpeed = 0;
            prev = null;
        }
        d.lastPos = pos;
        d.lastDim = level.dimension();

        tickTimers(p, d);
        if (prev != null) RaceManager.tick(p, d, prev, pos);

        boolean powered = d.isPowered() && !p.isSpectator();
        if (p.tickCount % 10 == 0) applyAttributes(p, d, powered);
        if (!powered) {
            if (d.phasing || d.perception || d.tornado || d.foreverActive || d.massPunchTicks > 0) {
                d.clearActiveStates();
                d.markDirty();
            }
            sync(p, d);
            return;
        }

        energy(p, d);

        if (d.perception || d.freezeTicks > 0) {
            PerceptionManager.bubble(p, (d.freezeTicks > 0 ? 22 : 14) + d.level, d.freezeTicks > 0 ? 6 : 4, false);
        }
        if (d.foreverActive) PerceptionManager.bubble(p, 12, 6, true);
        if (d.tornado) AbilityHandler.tickTornado(p, d);
        if (d.massPunchTicks > 0) AbilityHandler.tickMassPunch(p, d);
        if (d.armoredTicks > 0) AbilityHandler.tickArmoredCharge(p, d);

        if (prev != null && d.serverSpeed > 1.5) worldInteraction(p, d, prev, pos);
        soundBarrier(p, d);
        wraiths(p, d);
        residue(p, d);
        training(p, d);
        sync(p, d);
    }

    private static void tickTimers(ServerPlayer p, SpeedData d) {
        if (d.entityPhaseTicks > 0 && --d.entityPhaseTicks == 0) d.markDirty();
        if (d.stolenTicks > 0 && --d.stolenTicks == 0) {
            d.stolenBonus = 0;
            d.markDirty();
        }
        if (d.overdriveTicks > 0 && --d.overdriveTicks == 0) d.markDirty();
        if (d.freezeTicks > 0 && --d.freezeTicks == 0) d.markDirty();
        if (d.armoredTicks > 0 && --d.armoredTicks == 0) d.markDirty();
        if (d.blitzTicks > 0 && --d.blitzTicks == 0) d.markDirty();
        if (d.wraithCooldown > 0) d.wraithCooldown--;
        if (d.v9Ticks > 0) {
            d.v9Ticks--;
            if (d.v9Ticks > 0 && d.v9Ticks % 80 == 0) p.hurt(p.damageSources().magic(), 1.0f);
            if (!p.getAbilities().instabuild) p.causeFoodExhaustion(0.02f);
            if (d.v9Ticks == 200) p.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 220, 0));
            if (d.v9Ticks == 0) {
                p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 600, 1));
                p.addEffect(new MobEffectInstance(MobEffects.HUNGER, 300, 1));
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 200, 1));
                p.sendSystemMessage(Component.translatable("message.speedforce.v9_crash").withStyle(ChatFormatting.DARK_AQUA));
                if (!d.hasPower) d.clearActiveStates();
                d.markDirty();
            }
        }
    }

    private static void energy(ServerPlayer p, SpeedData d) {
        double max = SpeedMath.maxSpeedBT(p, d);
        double frac = max > 0 ? Math.min(1.0, d.serverSpeed / max) : 0;
        boolean running = d.serverSpeed > 0.6;
        SuitType suit = SuitType.worn(p);
        float before = d.energy;

        if (running) {
            float drain = (float) (0.002 * d.level * frac * Config.ENERGY_DRAIN.get());
            if (suit == SuitType.FLASH) drain *= 0.8f;
            d.energy -= drain;
            if (!p.getAbilities().instabuild) p.causeFoodExhaustion((float) (0.004 * d.level * frac * Config.HUNGER_MULTIPLIER.get()));
        } else {
            d.energy += SpeedMath.effectiveType(p, d) == SpeedForceType.NEGATIVE ? 0.24f : 0.3f;
        }
        if (d.phasing) d.energy -= (float) (0.3 * Config.PHASE_COST.get());
        if (d.perception && d.freezeTicks <= 0) {
            d.energy -= (float) ((suit == SuitType.ZOOM ? 0.18 : 0.35) * Config.PERCEPTION_COST.get());
            d.instability += 0.01f;
        }
        if (d.foreverActive) {
            d.energy -= 0.5f;
            d.instability += 0.04f;
        }
        if (d.tornado) d.energy -= 0.35f;
        if (d.v9Ticks > 0 || p.getAbilities().instabuild) d.energy = 100f;
        d.energy = Math.max(0f, Math.min(100f, d.energy));

        if (d.energy <= 0f && before > 0f) {
            boolean any = d.phasing || d.perception || d.foreverActive || d.tornado;
            d.phasing = false;
            d.perception = false;
            d.foreverActive = false;
            d.tornado = false;
            d.vortexTarget = -1;
            if (any) d.markDirty();
            p.displayClientMessage(Component.literal("\u26A1 Speed Force depleted").withStyle(ChatFormatting.RED), true);
        }
    }

    private static void applyAttributes(ServerPlayer p, SpeedData d, boolean powered) {
        if (powered) {
            SuitType suit = SuitType.worn(p);
            double dmg = (suit != null ? suit.bonusDamage : 0) + (SpeedMath.effectiveType(p, d) == SpeedForceType.NEGATIVE ? 1.0 : 0.0);
            set(p, Attributes.STEP_HEIGHT, STEP_ID, 1.0);
            set(p, Attributes.ATTACK_SPEED, ATTACK_SPEED_ID, 3.0);
            set(p, Attributes.SAFE_FALL_DISTANCE, SAFE_FALL_ID, 6.0);
            if (dmg > 0) set(p, Attributes.ATTACK_DAMAGE, ATTACK_DAMAGE_ID, dmg);
            else remove(p, Attributes.ATTACK_DAMAGE, ATTACK_DAMAGE_ID);
        } else {
            remove(p, Attributes.STEP_HEIGHT, STEP_ID);
            remove(p, Attributes.ATTACK_SPEED, ATTACK_SPEED_ID);
            remove(p, Attributes.SAFE_FALL_DISTANCE, SAFE_FALL_ID);
            remove(p, Attributes.ATTACK_DAMAGE, ATTACK_DAMAGE_ID);
        }
    }

    private static void set(Player p, Holder<Attribute> attribute, ResourceLocation id, double amount) {
        AttributeInstance inst = p.getAttribute(attribute);
        if (inst == null) return;
        AttributeModifier current = inst.getModifier(id);
        if (current == null || current.amount() != amount) {
            inst.addOrUpdateTransientModifier(new AttributeModifier(id, amount, AttributeModifier.Operation.ADD_VALUE));
        }
    }

    private static void remove(Player p, Holder<Attribute> attribute, ResourceLocation id) {
        AttributeInstance inst = p.getAttribute(attribute);
        if (inst != null && inst.getModifier(id) != null) inst.removeModifier(id);
    }

    /** Mobs get shoved aside, items scatter, grass is torn up. */
    private static void worldInteraction(ServerPlayer p, SpeedData d, Vec3 prev, Vec3 pos) {
        ServerLevel level = p.serverLevel();
        Vec3 motion = new Vec3(pos.x - prev.x, 0, pos.z - prev.z);
        if (motion.lengthSqr() < 1e-6) return;
        motion = motion.normalize();
        for (Entity e : level.getEntities(p, p.getBoundingBox().inflate(1.6, 0.5, 1.6),
                e -> e instanceof ItemEntity || (e instanceof LivingEntity && !(e instanceof Player)
                        && !(e instanceof TamableAnimal t && t.isTame()) && !e.isAlliedTo(p)))) {
            Vec3 away = e.position().subtract(p.position());
            Vec3 side = away.subtract(motion.scale(away.dot(motion))).multiply(1, 0, 1);
            if (side.lengthSqr() < 1e-4) side = new Vec3(-motion.z, 0, motion.x);
            side = side.normalize().scale(0.35 + d.serverSpeed * 0.05);
            e.push(side.x, 0.2, side.z);
            e.hurtMarked = true;
        }
        if (Config.BREAK_PLANTS.get() && d.serverSpeed > 2.0 && !d.phasing) {
            double dist = prev.distanceTo(pos);
            int steps = (int) Math.min(20, Math.ceil(dist));
            for (int i = 0; i <= steps; i++) {
                Vec3 q = prev.lerp(pos, steps == 0 ? 1 : i / (double) steps);
                BlockPos bp = BlockPos.containing(q.x, q.y + 0.1, q.z);
                BlockState s = level.getBlockState(bp);
                if (s.is(Blocks.SHORT_GRASS) || s.is(Blocks.TALL_GRASS) || s.is(Blocks.FERN) || s.is(Blocks.LARGE_FERN) || s.is(Blocks.DEAD_BUSH)) {
                    level.destroyBlock(bp, false);
                }
            }
        }
    }

    private static void soundBarrier(ServerPlayer p, SpeedData d) {
        if (!d.soundBarrier && d.serverSpeed >= SpeedMath.SOUND_BARRIER_BT) {
            d.soundBarrier = true;
            ServerLevel level = p.serverLevel();
            level.sendParticles(ParticleTypes.SONIC_BOOM, p.getX(), p.getY() + 1, p.getZ(), 1, 0, 0, 0, 0);
            ServerFx.ring(level, p.position().add(0, 1, 0), 3.0, 0xFFFFFF, 40);
            level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 3.0f, 0.8f);
            PacketDistributor.sendToPlayer(p, new FxPayload(FxPayload.BOOM, p.getId(), 1f));
            p.displayClientMessage(Component.literal("\u26A1 SOUND BARRIER BROKEN").withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD), true);
        } else if (d.soundBarrier && d.serverSpeed < SpeedMath.SOUND_BARRIER_BT * 0.8) {
            d.soundBarrier = false;
        }
    }

    private static void wraiths(ServerPlayer p, SpeedData d) {
        d.instability = Math.max(0f, d.instability - 0.01f);
        if (!Config.TIME_WRAITHS.get() || d.instability < 100f || d.wraithCooldown > 0) return;
        ServerLevel level = p.serverLevel();
        int count = 1 + p.getRandom().nextInt(2);
        for (int i = 0; i < count; i++) {
            TimeWraithEntity wraith = ModEntities.TIME_WRAITH.get().create(level);
            if (wraith == null) continue;
            double a = p.getRandom().nextDouble() * Math.PI * 2;
            wraith.moveTo(p.getX() + Math.cos(a) * 14, p.getY() + 4, p.getZ() + Math.sin(a) * 14, 0, 0);
            wraith.setTarget(p);
            level.addFreshEntity(wraith);
            level.sendParticles(ParticleTypes.SOUL, wraith.getX(), wraith.getY() + 1, wraith.getZ(), 30, 0.5, 1, 0.5, 0.05);
        }
        level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.WARDEN_EMERGE, SoundSource.HOSTILE, 1.0f, 1.5f);
        p.sendSystemMessage(Component.translatable("message.speedforce.wraiths").withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.ITALIC));
        d.instability = 55f;
        d.wraithCooldown = 1200;
    }

    private static void residue(ServerPlayer p, SpeedData d) {
        int per = Config.RESIDUE_DISTANCE.get();
        if (per <= 0 || d.serverSpeed <= 2.0) return;
        d.residueDistance += (float) d.serverSpeed;
        if (d.residueDistance >= per) {
            d.residueDistance -= per;
            ItemStack stack = new ItemStack(ModItems.SPEED_FORCE_RESIDUE.get());
            if (!p.getInventory().add(stack)) p.drop(stack, false);
            p.displayClientMessage(Component.literal("\u26A1 Your body sheds Speed Force residue").withStyle(ChatFormatting.YELLOW), true);
        }
    }

    private static void training(ServerPlayer p, SpeedData d) {
        if (!d.trainingActive) return;
        if (d.serverSpeed >= 5.0) Training.complete(p, d, Training.REACH_100);
        if (d.phasing && !p.level().noCollision(p)) Training.complete(p, d, Training.PHASE_WALL);
        boolean onWater = p.level().getFluidState(BlockPos.containing(p.getX(), p.getY() - 0.3, p.getZ())).is(FluidTags.WATER)
                && !p.isInWater() && d.serverSpeed > 0.5;
        d.waterRunTicks = onWater ? d.waterRunTicks + 1 : 0;
        if (d.waterRunTicks >= 60) Training.complete(p, d, Training.WATER_RUN);
    }

    private static void sync(ServerPlayer p, SpeedData d) {
        if (!d.hasPower && d.v9Ticks <= 0 && !d.dirty) return;
        d.syncTimer++;
        if (d.dirty || d.syncTimer >= 40) {
            SpeedSync.sync(p, d, true);
            d.dirty = false;
            d.syncTimer = 0;
        } else if (d.syncTimer % 5 == 0) {
            SpeedSync.sync(p, d, false);
        }
    }
}
