# ⚡ The Flash: Speed Force — NeoForge 1.21.1

A full speedster mod: Speed Force origins, momentum running, speed levels 1–10, lightning, phasing,
speed perception, water/wall running, tornadoes, Mass Punch, 8 suits + Speedster Ring, rival speedster
bosses, Time Wraiths, races and the Speed Force dimension.

> **Java Edition only.** This is a NeoForge mod — it runs on PC (Windows/Mac/Linux), not on Bedrock or mobile.

---

## Building (needs a PC)

1. Install **JDK 21** (e.g. Temurin 21).
2. Unzip this project, open a terminal in the folder.
3. Run `gradlew build` (Windows) or `./gradlew build` (Mac/Linux). First run downloads Minecraft + NeoForge (~5–10 min).
4. The mod jar is in `build/libs/speedforce-1.0.0.jar`.
5. Put it in the `mods` folder of a **NeoForge 21.1.x / Minecraft 1.21.1** instance.

To test straight from the project: `gradlew runClient`.

### Easiest on Windows
Install Java 21 (Temurin JDK), then double-click **`BUILD-MRPACK.bat`**. When it finishes,
`speedforce-1.0.0.mrpack` appears in the project folder.

### Modrinth modpack (.mrpack)
`gradlew mrpack` builds `build/mrpack/speedforce-1.0.0.mrpack`. It installs Minecraft 1.21.1 + NeoForge
21.1.251 and includes the mod. Import it in the Modrinth App, Prism Launcher, or a mobile Java launcher
that supports .mrpack import.

### No PC? Build on GitHub
1. On github.com: **New repository** (public or private).
2. **Add file → Upload files** → upload this project's `.zip` as-is → Commit.
3. **Add file → Create new file** → name it `.github/workflows/build.yml` → paste the contents of
   `build.yml` (included next to this zip, and at `.github/workflows/build.yml` inside it) → Commit.
4. Open the **Actions** tab. The build takes ~5–10 minutes.
5. Green check → **Releases** → download `speedforce-1.0.0.mrpack` (the `.jar` is there too).
6. Red X → open the failed step, copy the error lines, and send them over for fixes.

**Heads-up:** this code was written without access to the Minecraft/NeoForge jars, so it has never been
compiled. It was syntax-checked and cross-checked, but expect a handful of small compile errors on first
build (a renamed method, a wrong import). Paste the error output back and they're quick fixes.

---

## Becoming a speedster

| Route | How |
|---|---|
| **Particle Accelerator** (story route) | Craft an Empty Dark-Matter Vial. Hold it up to the open sky in a thunderstorm (or stand near a natural lightning strike) to get a **Dark-Matter Vial**. Build the accelerator structure, insert the vial, stand within 5 blocks. 9-second storm → lightning → **SPEED FORCE ONLINE**. |
| **Speed Force Core** (crafted) | Blaze powder + gold + diamond + Dark-Matter Vial. Right-click to connect instantly. |
| **V-9 Serum** (temporary) | Swiftness potion + Dark-Matter Vial + sugar + glowstone. 60 seconds of blue-lightning speed for anyone. Hurts you, crashes hard, double doses are dangerous. |

**Accelerator structure** (one layer, accelerator in the middle, lightning rod on top of it):
```
R C R      R = Redstone Block
C A C      C = any Copper Block (not slabs/stairs)
R C R      A = Particle Accelerator
```
Right-click the accelerator with an empty hand to see what's missing.

---

## Controls (rebind in Options → Controls → Speed Force)

| Key | Power |
|---|---|
| **Sprint + W** | Run. You build momentum — release to coast, sneak to brake. Steering gets heavier the faster you go. |
| **Alt + Scroll** or **= / -** | Speed level 1–10 |
| **N** | Toggle powers on/off |
| **R** | Lightning throw (tap) · hold to charge · **Sneak + R** lightning burst |
| **Z** | Phase through walls (Space/Sneak to move up/down) · **Sneak + Z** vibrate so attacks pass through you |
| **C** | Speed perception (world slows around you, projectiles freeze mid-air) |
| **V** | Speed steal (look at a target) |
| **B** | Dash |
| **G** (hold while running) | Mass Punch — build velocity, release to launch |
| **H** (hold) | Tornado. Aim at a mob first → Speed Vortex that traps and then blasts it |
| **P** | Break into / leave the Speed Force (level 9+, running 150 m/s) |
| **J** | Forever Force (stop the world) · **Sneak + J** Snap shockwave |
| **Y** | Suit ability (full suit required) |

Automatic: supersonic punches (hit while running), water running (level 6+), wall running and wall
climbing (level 7+), sonic boom at 343 m/s, reduced fall damage, projectile dodging at level 8+.

Phase = **Z** and Tornado = **H** (instead of F/T) so they don't clash with vanilla keys.

### Speed levels (top speed)
| 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
|---|---|---|---|---|---|---|---|---|---|
| 8 | 15 | 25 | 40 | 60 | 90 | 130 | 180 | 250 | 350 m/s |

Energy drains while running and using powers and recharges when you stop. At 0 you're capped at level 3.
Running burns hunger — at 3 drumsticks or less you can barely jog.

---

## Suits (stored and deployed with the Speedster Ring)

| Suit | Stats | [Y] Ability |
|---|---|---|
| Flash | balanced, cheaper running | Lightning Barrage (3 bolts) |
| Wally West | +15% top speed, +20% accel | Overdrive (10 s boost) |
| Jay Garrick | slower, tanky, +2 punch | Iron Will (resistance + strength) |
| Kid Flash | fast accel, best steering | Blitz (free dashes 6 s) |
| Reverse-Flash | Negative Speed Force, red lightning | Negative Surge (chain lightning) |
| Zoom | +10% speed, cheap perception | Time Freeze (huge perception bubble) |
| Godspeed | +20% speed | Speed Clones (2 allies) |
| Savitar | slow, heavy armor, shockwave punches | Armored Charge (invulnerable ram) |

**Speedster Ring:** wear a full suit → use ring to store it. Use again to deploy. Sneak-use to cycle.
Villain suits need Temporal Residue to craft.

---

## Enemies & trophies

| Enemy | How to meet it | Drops |
|---|---|---|
| Reverse-Flash | Speedster Signal / spawn egg / `/speedforce boss` | Negative Speed Force Core (converts you) |
| Zoom | same | Forever Force Fragment (unlocks J) |
| Godspeed | same | White Speed Core (white lightning, +10% speed) |
| Time Wraiths | Abuse time (perception, Forever Force, dimension travel) | Temporal Residue |

Bosses orbit you, dash through walls, throw lightning, dodge hits, and use a signature power. They follow
you into the Speed Force.

---

## Races
Place **Race Gates**. Sneak-use to set the index: 0 = start/finish, 1–15 = checkpoints in order.
Run through gate 0 to start, hit every checkpoint in order, cross gate 0 again. Timer on screen,
top-10 leaderboard per course (use gate 0 to view it).

## Speed Force dimension
Speed level 9+, run at 150 m/s, press **P**. Floating golden islands with a yellow sky.
Distances inside are 1:8 — run there, press P again, and you come out 8× further in the overworld.

## Training
Craft the **Speed Training Device** and use it: six short drills (100 m/s, lightning hit, phase through
a wall, water run, perception dodge, supersonic punch). Finishing all six gives Speed Force Residue.
Residue also drops from your body as you run long distances.

---

## Commands (`/speedforce`, op level 2)
`grant [speed|negative]` · `revoke` · `level <1-10>` · `lightning <yellow|red|blue|white|orange|purple|green|gold|black|#RRGGBB|reset>`
· `suit <name>` · `boss <reverse_flash|zoom|godspeed|time_wraith|speed_clone>` · `dimension` · `energy <0-100>`
· `unlock <forever|white>` · `give` (starter kit)

## Config
- `config/speedforce-common.toml` — speed multiplier, max speed cap (blocks/tick), water/wall/travel levels,
  energy and hunger drain, collision damage, Mass Punch craters (off by default), plant trampling,
  boss health, Time Wraiths, dimension toggle, residue distance.
- `config/speedforce-client.toml` (also in-game: Mods → The Flash: Speed Force → Config) — HUD on/position/scale/auto-hide,
  dynamic FOV + strength, camera shake, wall-run tilt, particle density, wind sound.

## Servers
- Set `allow-flight=true` in `server.properties`. Phasing upward and long wall runs look like flying to vanilla's anti-cheat.
- The "moved too quickly" kick is already bypassed for active speedsters.
- On weaker servers lower `maxBlocksPerTick` (default 18 = 360 m/s) — chunk loading is the real limit at top speed.

---

## Honest limitations
- **Never compiled** (see Building). Logic and APIs were checked carefully but a first build may need fixes.
- **Textures are original placeholders** (no DC logos). Swap in your own PNGs under `src/main/resources/assets/speedforce/textures/`.
- **Sounds are vanilla** (elytra wind, warden sonic boom, thunder). No custom audio.
- **Afterimages are particle streaks**, not ghost copies of your model. Lightning is particle-based.
- **Bosses use the player model** with custom skins; Time Wraiths use a scaled vex model. No GeckoLib animations.
- **No real time travel** — the Speed Force dimension + 1:8 fast travel stands in for it.
- The Speed Force dimension uses vanilla's floating-islands generator recoloured by its biome.

## v2 additions
- **4 new suits**: Impulse (Reckless Rush), Max Mercury (Zen Focus), Jesse Quick (Velocity Burst), Inertia (Momentum Drain) — own stats, lightning colour, ability, recipes.
- **2 new bosses**: Savitar (armoured, leaping ground-slam, summons Time Wraiths) and Black Flash (teleport Death Touch, wither + energy drain). `/speedforce boss savitar|black_flash`, spawn eggs, Speedster Signal can summon them.
- **Smarter boss AI**: 3 stages by health (enrage at 55% / 25%, faster + harder), predictive lightning aim, telegraphed dash chains, teleport flank behind you, sidesteps incoming projectiles, weighted attack choice based on distance / your speed / line of sight, strafe reversals, Godspeed clone waves on stage-up.
- **Map**: S.T.A.R. Labs (overworld structure with Particle Accelerator, containment cell, loot chests), Speedster Training Tracks (90-block track with finish-line loot), Speed Force dimension now has crystal + gold veins, lightning-rod and end-rod gardens, and Time Wraith spawns.
- **Advancements**: 17-step tree from Lightning in a Bottle to Blacker Than Black.

## v2.1
- All 12 suit abilities reworked (bigger AoE, chains, shockwaves, cleanses, clone waves, status effects, VFX).
- All suit armor textures and icons redrawn by hand: separate cowl/chest/leg/boot colours, emblem badge, belt, bracers, per-suit cowl style (cowl / helmet / mask / horned / hood).

## v2.2
- Boss textures (Zoom, Savitar, Reverse-Flash, Godspeed) and the Flash, Wally West, Zoom, Savitar, Reverse-Flash and Godspeed suit armor + icons are built from Nero's own uploaded skins.
