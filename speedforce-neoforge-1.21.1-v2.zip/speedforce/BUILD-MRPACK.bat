@echo off
title The Flash: Speed Force - building .mrpack
cd /d "%~dp0"

where java >nul 2>nul
if errorlevel 1 (
  echo Java is not installed.
  echo Install "Temurin 21 JDK" from https://adoptium.net  ^(tick "Set JAVA_HOME"^), then run this again.
  pause
  exit /b 1
)

echo Building The Flash: Speed Force...
echo First run downloads Minecraft + NeoForge. This can take 5-10 minutes.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "& '.\gradlew.bat' mrpack --no-daemon 2>&1 | Tee-Object -FilePath build-log.txt; exit $LASTEXITCODE"
if errorlevel 1 (
  echo.
  echo ================= BUILD FAILED =================
  findstr /C:"error:" build-log.txt
  echo ================================================
  echo Send the error lines above ^(full log: build-log.txt^) to get them fixed.
  pause
  exit /b 1
)

copy /y "build\mrpack\*.mrpack" "%~dp0" >nul
echo.
echo DONE: speedforce-1.0.0.mrpack is in this folder.
echo Import it in Modrinth App ^(+ ^> Import from file^) or Prism Launcher ^(Add Instance ^> Import^).
explorer "%~dp0"
pause
